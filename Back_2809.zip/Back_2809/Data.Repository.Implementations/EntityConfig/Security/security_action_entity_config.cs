using Data.Repository.Interfaces.Entities.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Data.Repository.Implementations.EntityConfig.Security
{
    internal class security_action_entity_config
    {
        public static void SetEntityBuilder(EntityTypeBuilder<security_action_entity> entityTypeBuilder)
        {
            entityTypeBuilder.ToTable("security_action");
            entityTypeBuilder.HasKey(q => q.action_id);
            entityTypeBuilder.Property(q => q.action_id).IsRequired();
            entityTypeBuilder.Property(q => q.code).HasMaxLength(80).IsRequired();
            entityTypeBuilder.Property(q => q.name).HasMaxLength(80).IsRequired();
            entityTypeBuilder.Property(q => q.description_alt).HasMaxLength(150);
            entityTypeBuilder.Property(q => q.is_active).IsRequired();
            entityTypeBuilder.Property(q => q.row_status).IsRequired();
            entityTypeBuilder.Property(q => q.created_by).IsRequired();
            entityTypeBuilder.Property(q => q.created_date).IsRequired().HasColumnType("timestamp without time zone");
            entityTypeBuilder.Property(q => q.modified_date).HasColumnType("timestamp without time zone");

            entityTypeBuilder.HasIndex(q => q.code).IsUnique();
        }
    }
}
