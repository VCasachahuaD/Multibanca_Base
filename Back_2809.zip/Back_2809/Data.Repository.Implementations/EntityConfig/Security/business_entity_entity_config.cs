using Data.Repository.Interfaces.Entities.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Data.Repository.Implementations.EntityConfig.Security
{
    internal class business_entity_entity_config
    {
        public static void SetEntityBuilder(EntityTypeBuilder<business_entity_entity> entityTypeBuilder)
        {
            entityTypeBuilder.ToTable("business_entity");
            entityTypeBuilder.HasKey(q => q.business_entity_id);
            entityTypeBuilder.Property(q => q.business_entity_id).IsRequired();
            entityTypeBuilder.Property(q => q.code).HasMaxLength(120).IsRequired();
            entityTypeBuilder.Property(q => q.name).HasMaxLength(120).IsRequired();
            entityTypeBuilder.Property(q => q.description_alt).HasMaxLength(200);
            entityTypeBuilder.Property(q => q.is_active).IsRequired();
            entityTypeBuilder.Property(q => q.row_status).IsRequired();
            entityTypeBuilder.Property(q => q.created_by).IsRequired();
            entityTypeBuilder.Property(q => q.created_date).IsRequired().HasColumnType("timestamp without time zone");
            entityTypeBuilder.Property(q => q.modified_date).HasColumnType("timestamp without time zone");

            entityTypeBuilder.HasIndex(q => q.code).IsUnique();
        }
    }
}
