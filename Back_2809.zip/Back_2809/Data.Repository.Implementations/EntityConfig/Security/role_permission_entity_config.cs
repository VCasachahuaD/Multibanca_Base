using Data.Repository.Interfaces.Entities.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Data.Repository.Implementations.EntityConfig.Security
{
    internal class role_permission_entity_config
    {
        public static void SetEntityBuilder(EntityTypeBuilder<role_permission_entity> entityTypeBuilder)
        {
            entityTypeBuilder.ToTable("role_permission");
            entityTypeBuilder.HasKey(q => q.role_permission_id);
            entityTypeBuilder.Property(q => q.role_permission_id).IsRequired();
            entityTypeBuilder.Property(q => q.role_id).IsRequired();
            entityTypeBuilder.Property(q => q.permission_id).IsRequired();
            entityTypeBuilder.Property(q => q.is_active).IsRequired();
            entityTypeBuilder.Property(q => q.row_status).IsRequired();
            entityTypeBuilder.Property(q => q.created_by).IsRequired();
            entityTypeBuilder.Property(q => q.created_date).IsRequired().HasColumnType("timestamp without time zone");
            entityTypeBuilder.Property(q => q.modified_date).HasColumnType("timestamp without time zone");

            entityTypeBuilder.HasIndex(q => q.role_id);
            entityTypeBuilder.HasIndex(q => q.permission_id);
            entityTypeBuilder.HasIndex(q => new { q.role_id, q.permission_id }).IsUnique();

            entityTypeBuilder.HasOne(q => q.role).WithMany(q => q.role_permissions).HasForeignKey(q => q.role_id);
            entityTypeBuilder.HasOne(q => q.permission).WithMany(q => q.role_permissions).HasForeignKey(q => q.permission_id);
        }
    }
}
