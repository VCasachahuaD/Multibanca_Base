using Data.Repository.Interfaces.Entities.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Data.Repository.Implementations.EntityConfig.Security
{
    internal class permission_entity_config
    {
        public static void SetEntityBuilder(EntityTypeBuilder<permission_entity> entityTypeBuilder)
        {
            entityTypeBuilder.ToTable("permission");
            entityTypeBuilder.HasKey(q => q.permission_id);
            entityTypeBuilder.Property(q => q.permission_id).IsRequired();
            entityTypeBuilder.Property(q => q.business_entity_id).IsRequired();
            entityTypeBuilder.Property(q => q.action_id).IsRequired();
            entityTypeBuilder.Property(q => q.code).HasMaxLength(180).IsRequired();
            entityTypeBuilder.Property(q => q.description).HasMaxLength(200).IsRequired();
            entityTypeBuilder.Property(q => q.is_active).IsRequired();
            entityTypeBuilder.Property(q => q.row_status).IsRequired();
            entityTypeBuilder.Property(q => q.created_by).IsRequired();
            entityTypeBuilder.Property(q => q.created_date).IsRequired().HasColumnType("timestamp without time zone");
            entityTypeBuilder.Property(q => q.modified_date).HasColumnType("timestamp without time zone");

            entityTypeBuilder.HasIndex(q => q.code).IsUnique();
            entityTypeBuilder.HasIndex(q => q.action_id);
            entityTypeBuilder.HasIndex(q => q.business_entity_id);
            entityTypeBuilder.HasIndex(q => new { q.business_entity_id, q.action_id }).IsUnique();

            entityTypeBuilder.HasOne(q => q.business_entity).WithMany(q => q.permissions).HasForeignKey(q => q.business_entity_id);
            entityTypeBuilder.HasOne(q => q.security_action).WithMany(q => q.permissions).HasForeignKey(q => q.action_id);
        }
    }
}
