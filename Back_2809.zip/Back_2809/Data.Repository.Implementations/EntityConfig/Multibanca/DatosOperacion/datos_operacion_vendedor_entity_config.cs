using Data.Repository.Interfaces.Entities.Multibanca.DatosOperacion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Data.Repository.Implementations.EntityConfig.Multibanca.DatosOperacion
{
    internal class datos_operacion_vendedor_entity_config
    {
        public static void SetEntityBuilder(EntityTypeBuilder<datos_operacion_vendedor_entity> entityTypeBuilder)
        {
            entityTypeBuilder.ToTable("datos_operacion_vendedor");

            entityTypeBuilder.HasKey(q => q.id_datos_operacion_vendedor);

            entityTypeBuilder.Property(q => q.id_datos_operacion_vendedor)
                .HasColumnName("id_datos_operacion_vendedor").IsRequired();

            entityTypeBuilder.Property(q => q.id_datos_operacion)
                .HasColumnName("id_datos_operacion").IsRequired();

            entityTypeBuilder.Property(q => q.id_carga_operacion_banco_antecedente_vendedor)
                .HasColumnName("id_carga_operacion_banco_antecedente_vendedor")
                .IsRequired(false);

            entityTypeBuilder.Property(q => q.id_expediente)
                .HasColumnName("id_expediente").IsRequired();

            entityTypeBuilder.Property(q => q.direccion_env_esc).HasColumnName("direccion_env_esc").HasMaxLength(250);
            entityTypeBuilder.Property(q => q.region_env_esc).HasColumnName("region_env_esc").HasMaxLength(50);
            entityTypeBuilder.Property(q => q.comuna_env_esc).HasColumnName("comuna_env_esc").HasMaxLength(50);
            entityTypeBuilder.Property(q => q.telefono_comercial).HasColumnName("telefono_comercial").HasMaxLength(50);
            entityTypeBuilder.Property(q => q.telefono_movil).HasColumnName("telefono_movil").HasMaxLength(50);
            entityTypeBuilder.Property(q => q.email2).HasColumnName("email2").HasMaxLength(150);
            entityTypeBuilder.Property(q => q.is_active).HasColumnName("is_active").IsRequired();
            entityTypeBuilder.Property(q => q.row_status).HasColumnName("row_status").IsRequired();
            entityTypeBuilder.Property(q => q.created_by).HasColumnName("created_by").IsRequired();
            entityTypeBuilder.Property(q => q.created_date)
                .HasColumnName("created_date").HasColumnType("timestamp without time zone").IsRequired();
            entityTypeBuilder.Property(q => q.modified_by).HasColumnName("modified_by");
            entityTypeBuilder.Property(q => q.modified_date)
                .HasColumnName("modified_date").HasColumnType("timestamp without time zone");
            entityTypeBuilder.HasIndex(q => q.id_expediente);
            entityTypeBuilder.HasIndex(q => q.id_datos_operacion);
            entityTypeBuilder.HasIndex(q => q.id_carga_operacion_banco_antecedente_vendedor);
        }
    }
}
