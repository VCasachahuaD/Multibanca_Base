using Data.Extensions.Repository;
using Data.Repository.Interfaces.Entities.Security;
using Data.Repository.Interfaces.Repositories.Security;
using Microsoft.EntityFrameworkCore;
using Multibanca.DTO.Security;
using System.Data;
using System.Data.Common;

namespace Data.Repository.Implementations.Repositories.Security
{
    public class PermissionRepository : MultibancaGenericRepository<permission_entity>, IPermissionRepository
    {
        private readonly MultibancaDBContext MultibancaDBContext;

        public PermissionRepository(MultibancaDBContext _multibancaDBContext) : base(_multibancaDBContext)
        {
            MultibancaDBContext = _multibancaDBContext;
        }

        public async Task<List<permission_item_DTO>> GetPermissions()
        {
            List<permission_item_DTO> list = new List<permission_item_DTO>();

            using (DbCommand command = MultibancaDBContext.Database.GetDbConnection().CreateCommand())
            {
                try
                {
                    MultibancaDBContext.Database.OpenConnection();

                    command.CommandText = @"SELECT
                                                permission_id,
                                                business_entity_id,
                                                business_entity_code,
                                                business_entity_name,
                                                action_id,
                                                action_code,
                                                action_name,
                                                code,
                                                description,
                                                is_active,
                                                row_status,
                                                is_assigned
                                            FROM public.usp_get_permissions();";
                    command.CommandType = CommandType.Text;

                    DbDataReader reader = await command.ExecuteReaderAsync();

                    list = reader.MapToListDomain<permission_item_DTO>() ?? list;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message, ex);
                }
                finally
                {
                    MultibancaDBContext.Database.CloseConnection();
                }
            }

            return list;
        }

        public async Task<List<permission_item_DTO>> GetPermissionByRole(int role_id)
        {
            List<permission_item_DTO> list = new List<permission_item_DTO>();

            object data = new
            {
                p_role_id = role_id
            };

            using (DbCommand command = MultibancaDBContext.Database.GetDbConnection().CreateCommand())
            {
                try
                {
                    MultibancaDBContext.Database.OpenConnection();

                    command.CommandText = @"SELECT
                                                permission_id,
                                                business_entity_id,
                                                business_entity_code,
                                                business_entity_name,
                                                action_id,
                                                action_code,
                                                action_name,
                                                code,
                                                description,
                                                is_active,
                                                row_status,
                                                is_assigned
                                            FROM public.usp_get_permission_by_role(@p_role_id);";
                    command.CommandType = CommandType.Text;
                    command.Parameters.ToArray(data);

                    DbDataReader reader = await command.ExecuteReaderAsync();

                    list = reader.MapToListDomain<permission_item_DTO>() ?? list;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message, ex);
                }
                finally
                {
                    MultibancaDBContext.Database.CloseConnection();
                }
            }

            return list;
        }

        public async Task<List<string>> GetActivePermissionCodesByRole(int role_id)
        {
            List<string> list = new List<string>();

            object data = new
            {
                p_role_id = role_id
            };

            using (DbCommand command = MultibancaDBContext.Database.GetDbConnection().CreateCommand())
            {
                try
                {
                    MultibancaDBContext.Database.OpenConnection();

                    command.CommandText = @"SELECT permission_code
                                            FROM public.usp_get_active_permission_codes_by_role(@p_role_id);";
                    command.CommandType = CommandType.Text;
                    command.Parameters.ToArray(data);

                    DbDataReader reader = await command.ExecuteReaderAsync();

                    while (await reader.ReadAsync())
                    {
                        if (!reader.IsDBNull(0))
                            list.Add(reader.GetString(0));
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message, ex);
                }
                finally
                {
                    MultibancaDBContext.Database.CloseConnection();
                }
            }

            return list.Distinct().ToList();
        }
    }
}
