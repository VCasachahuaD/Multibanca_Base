using Data.Extensions.Repository;
using Data.Repository.Interfaces.Entities.Security;
using Data.Repository.Interfaces.Repositories.Security;
using Microsoft.EntityFrameworkCore;
using Multibanca.DTO.Common;
using System.Data;
using System.Data.Common;

namespace Data.Repository.Implementations.Repositories.Security
{
    public class BusinessEntityRepository : MultibancaGenericRepository<business_entity_entity>, IBusinessEntityRepository
    {
        private readonly MultibancaDBContext MultibancaDBContext;

        public BusinessEntityRepository(MultibancaDBContext _multibancaDBContext) : base(_multibancaDBContext)
        {
            MultibancaDBContext = _multibancaDBContext;
        }

        public async Task<List<ControlBaseDTO>> GetControlBusinessEntity()
        {
            List<ControlBaseDTO> list = new List<ControlBaseDTO>();

            using (DbCommand command = MultibancaDBContext.Database.GetDbConnection().CreateCommand())
            {
                try
                {
                    MultibancaDBContext.Database.OpenConnection();

                    command.CommandText = @"SELECT id, description
                                            FROM public.usp_get_control_business_entity();";
                    command.CommandType = CommandType.Text;

                    DbDataReader reader = await command.ExecuteReaderAsync();

                    list = reader.MapToListDomain<ControlBaseDTO>() ?? list;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message, ex);
                }
                finally
                {
                    MultibancaDBContext.Database.CloseConnection();
                }
            }

            return list;
        }
    }
}
