using Data.Extensions.Repository;
using Data.Repository.Interfaces.Entities.Security;
using Data.Repository.Interfaces.Repositories.Security;
using Microsoft.EntityFrameworkCore;
using Multibanca.DTO.Security;
using Npgsql;
using System.Data;
using System.Data.Common;

namespace Data.Repository.Implementations.Repositories.Security
{
    public class MenuRepository : MultibancaGenericRepository<menus_entity>, IMenuRepository
    {
        private readonly MultibancaDBContext MultibancaDBContext;

        public MenuRepository(MultibancaDBContext _multibancaDBContext) : base(_multibancaDBContext)
        {
            MultibancaDBContext = _multibancaDBContext;
        }

        public async Task<List<MenuItemDTO>> GetMenuJerarquico()
        {
            List<MenuItemDTO> list = new();

            using (DbCommand command = MultibancaDBContext.Database.GetDbConnection().CreateCommand())
            {
                try
                {
                    MultibancaDBContext.Database.OpenConnection();

                    command.CommandText = @"
                        SELECT
                            menu_id,
                            name,
                            menu_url,
                            menu_padre_id,
                            icon_name,
                            disabled,
                            is_active
                        FROM public.usp_get_menu_jerarquico();";

                    command.CommandType = CommandType.Text;

                    DbDataReader reader = await command.ExecuteReaderAsync();
                    list = reader.MapToListDomain<MenuItemDTO>() ?? list;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message, ex);
                }
                finally
                {
                    MultibancaDBContext.Database.CloseConnection();
                }
            }

            return BuildTree(list);
        }

        public async Task<List<MenuItemDTO>> GetMenuByUserId(int user_id)
        {
            // Método histórico. No usar para Multibanca porque los menús se resuelven por rol.
            List<MenuItemDTO> list = new();
            object data = new
            {
                p_user_id = user_id
            };

            using (DbCommand command = MultibancaDBContext.Database.GetDbConnection().CreateCommand())
            {
                try
                {
                    MultibancaDBContext.Database.OpenConnection();

                    command.CommandText = "SELECT * FROM public.usp_get_menu_by_user(@p_user_id);";
                    command.CommandType = CommandType.Text;
                    command.Parameters.ToArray(data);

                    DbDataReader reader = await command.ExecuteReaderAsync();
                    list = reader.MapToListDomain<MenuItemDTO>() ?? list;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message, ex);
                }
                finally
                {
                    MultibancaDBContext.Database.CloseConnection();
                }
            }

            return BuildTree(list);
        }

        public async Task<List<MenuItemDTO>> GetMenuByRole(int role_id)
        {
            List<MenuItemDTO> list = new();
            object data = new
            {
                p_role_id = role_id
            };

            using (DbCommand command = MultibancaDBContext.Database.GetDbConnection().CreateCommand())
            {
                try
                {
                    MultibancaDBContext.Database.OpenConnection();

                    command.CommandText = @"
                        SELECT
                            menu_id,
                            name,
                            menu_url,
                            menu_padre_id,
                            icon_name,
                            disabled,
                            is_active
                        FROM public.usp_get_menu_by_role(@p_role_id);";

                    command.CommandType = CommandType.Text;
                    command.Parameters.ToArray(data);

                    DbDataReader reader = await command.ExecuteReaderAsync();
                    list = reader.MapToListDomain<MenuItemDTO>() ?? list;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message, ex);
                }
                finally
                {
                    MultibancaDBContext.Database.CloseConnection();
                }
            }

            return BuildTree(list);
        }

        public async Task<List<MenuItemDTO>> GetMenuByRoleId(int role_id)
        {
            return await GetMenuByRole(role_id);
        }

        public async Task<bool> SaveRoleMenu(int role_id, List<int> menu_ids, int user_id)
        {
            using (DbCommand command = MultibancaDBContext.Database.GetDbConnection().CreateCommand())
            {
                try
                {
                    MultibancaDBContext.Database.OpenConnection();

                    command.CommandText = "SELECT public.usp_save_role_menu(@p_role_id, @p_menu_ids, @p_user_id);";
                    command.CommandType = CommandType.Text;

                    command.Parameters.Add(new NpgsqlParameter("@p_role_id", role_id));
                    command.Parameters.Add(new NpgsqlParameter("@p_menu_ids", menu_ids?.ToArray() ?? Array.Empty<int>()));
                    command.Parameters.Add(new NpgsqlParameter("@p_user_id", user_id));

                    object? result = await command.ExecuteScalarAsync();

                    return result != null && result != DBNull.Value && Convert.ToBoolean(result);
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message, ex);
                }
                finally
                {
                    MultibancaDBContext.Database.CloseConnection();
                }
            }
        }

        private List<MenuItemDTO> BuildTree(List<MenuItemDTO> planos)
        {
            Dictionary<int, MenuItemDTO> map = planos
                .GroupBy(m => m.menu_id)
                .Select(g => g.First())
                .ToDictionary(m => m.menu_id, m => new MenuItemDTO
                {
                    menu_id = m.menu_id,
                    name = m.name,
                    menu_url = m.menu_url,
                    menu_padre_id = m.menu_padre_id,
                    icon_name = string.IsNullOrWhiteSpace(m.icon_name) ? "pi pi-circle" : m.icon_name,
                    is_active = m.is_active,
                    disabled = m.disabled,
                    children = new List<MenuItemDTO>()
                });

            List<MenuItemDTO> raiz = new();

            foreach (MenuItemDTO item in map.Values)
            {
                if (item.menu_padre_id.HasValue && map.ContainsKey(item.menu_padre_id.Value))
                {
                    map[item.menu_padre_id.Value].children.Add(item);
                }
                else
                {
                    raiz.Add(item);
                }
            }

            return raiz;
        }
    }
}
