﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Data.Repository.Implementations.Migrations
{
    /// <inheritdoc />
    public partial class DatosOperacionCompradorIdAntcedentes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "apellido_materno",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "apellido_paterno",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "comuna",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "direccion",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "email",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "estado_civil",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "fecha_nacimiento",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "genero",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "nacionalidad",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "nombres",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "profesion",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "razon_social",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "region",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "relacion_titular",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "rut",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "telefono",
                table: "datos_operacion_comprador");

            migrationBuilder.DropColumn(
                name: "tipo_persona",
                table: "datos_operacion_comprador");

            migrationBuilder.AddColumn<int>(
                name: "id_carga_operacion_banco_antecedente_comprador",
                table: "datos_operacion_comprador",
                type: "integer",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_carga_operacion_banco_antecedente_comprador",
                table: "datos_operacion_comprador");

            migrationBuilder.AddColumn<string>(
                name: "apellido_materno",
                table: "datos_operacion_comprador",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "apellido_paterno",
                table: "datos_operacion_comprador",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "comuna",
                table: "datos_operacion_comprador",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "direccion",
                table: "datos_operacion_comprador",
                type: "character varying(250)",
                maxLength: 250,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "email",
                table: "datos_operacion_comprador",
                type: "character varying(150)",
                maxLength: 150,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "estado_civil",
                table: "datos_operacion_comprador",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "fecha_nacimiento",
                table: "datos_operacion_comprador",
                type: "timestamp without time zone",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "genero",
                table: "datos_operacion_comprador",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "nacionalidad",
                table: "datos_operacion_comprador",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "nombres",
                table: "datos_operacion_comprador",
                type: "character varying(150)",
                maxLength: 150,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "profesion",
                table: "datos_operacion_comprador",
                type: "character varying(150)",
                maxLength: 150,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "razon_social",
                table: "datos_operacion_comprador",
                type: "character varying(250)",
                maxLength: 250,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "region",
                table: "datos_operacion_comprador",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "relacion_titular",
                table: "datos_operacion_comprador",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "rut",
                table: "datos_operacion_comprador",
                type: "character varying(20)",
                maxLength: 20,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "telefono",
                table: "datos_operacion_comprador",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "tipo_persona",
                table: "datos_operacion_comprador",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);
        }
    }
}
