﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Data.Repository.Implementations.Migrations
{
    /// <inheritdoc />
    public partial class CorreccionNroHabitanteDatosPropiedad : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // PostgreSQL NO tiene cast de asignación de varchar a integer: sin USING, el
            // ALTER COLUMN falla con 42804. El NULLIF convierte los vacíos en NULL.
            migrationBuilder.Sql(@"
                ALTER TABLE revisar_datos_operacion_propiedad
                  ALTER COLUMN numero_casa_habitantes TYPE integer
                  USING NULLIF(TRIM(numero_casa_habitantes), '')::integer;");

            migrationBuilder.Sql(@"
                ALTER TABLE datos_operacion_propiedad
                  ALTER COLUMN numero_casa_habitantes TYPE integer
                  USING NULLIF(TRIM(numero_casa_habitantes), '')::integer;");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Vuelve al varchar(50) original. Acá el cast sí es de asignación (int → texto),
            // pero se deja explícito para que no dependa de esa regla.
            migrationBuilder.Sql(@"
                ALTER TABLE revisar_datos_operacion_propiedad
                  ALTER COLUMN numero_casa_habitantes TYPE varchar(50)
                  USING numero_casa_habitantes::varchar(50);");

            migrationBuilder.Sql(@"
                ALTER TABLE datos_operacion_propiedad
                  ALTER COLUMN numero_casa_habitantes TYPE varchar(50)
                  USING numero_casa_habitantes::varchar(50);");
        }
    }
}