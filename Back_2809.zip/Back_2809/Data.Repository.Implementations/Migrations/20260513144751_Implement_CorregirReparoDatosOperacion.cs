using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Data.Repository.Implementations.Migrations
{
    /// <inheritdoc />
    public partial class Implement_CorregirReparoDatosOperacion : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
            ALTER TABLE public.corregir_reparo_datos_operacion
                ALTER COLUMN observaciones TYPE character varying(2000);

            ALTER TABLE public.corregir_reparo_datos_operacion
                DROP COLUMN IF EXISTS id_usuario_solicitante;

            ALTER TABLE public.corregir_reparo_datos_operacion
                DROP COLUMN IF EXISTS is_subsanar;
            ");

            migrationBuilder.CreateTable(
                name: "reparo_datos_operacion_detalle",
                columns: table => new
                {
                    id_reparo_datos_operacion = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    id_expediente = table.Column<long>(type: "bigint", nullable: false),
                    solicitante = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: true),
                    observaciones = table.Column<string>(type: "character varying(2000)", maxLength: 2000, nullable: true),
                    fecha_ingreso = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    subsanar = table.Column<bool>(type: "boolean", nullable: false, defaultValue: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    row_status = table.Column<bool>(type: "boolean", nullable: false),
                    created_by = table.Column<int>(type: "integer", nullable: false),
                    created_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    modified_by = table.Column<int>(type: "integer", nullable: true),
                    modified_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_reparo_datos_operacion_detalle", x => x.id_reparo_datos_operacion);
                });

            migrationBuilder.CreateIndex(
                name: "ix_reparo_datos_operacion_detalle_expediente",
                table: "reparo_datos_operacion_detalle",
                column: "id_expediente");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

            migrationBuilder.DropTable(
                name: "reparo_datos_operacion_detalle");

            migrationBuilder.Sql(@"
            ALTER TABLE public.corregir_reparo_datos_operacion
                ADD COLUMN IF NOT EXISTS id_usuario_solicitante integer NOT NULL DEFAULT 0;

            ALTER TABLE public.corregir_reparo_datos_operacion
                ADD COLUMN IF NOT EXISTS is_subsanar boolean NOT NULL DEFAULT false;

            ALTER TABLE public.corregir_reparo_datos_operacion
                ALTER COLUMN observaciones TYPE character varying(1000);
            ");
        }
    }
}
