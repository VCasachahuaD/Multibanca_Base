﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Data.Repository.Implementations.Migrations
{
    /// <inheritdoc />
    public partial class AddRevisarDatosOperacion : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "revisar_datos_operacion",
                columns: table => new
                {
                    id_revisar_datos_operacion = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    id_expediente = table.Column<long>(type: "bigint", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    row_status = table.Column<bool>(type: "boolean", nullable: false),
                    created_by = table.Column<int>(type: "integer", nullable: false),
                    created_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    modified_by = table.Column<int>(type: "integer", nullable: true),
                    modified_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_revisar_datos_operacion", x => x.id_revisar_datos_operacion);
                });

            migrationBuilder.CreateTable(
                name: "revisar_datos_operacion_propiedad",
                columns: table => new
                {
                    id_revisar_datos_operacion_propiedad = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    id_revisar_datos_operacion = table.Column<int>(type: "integer", nullable: false),
                    id_expediente = table.Column<long>(type: "bigint", nullable: false),
                    tipo_propiedad = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    estado = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    tipo_venta = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    tipo_construccion = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    tipo_direccion = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    direccion = table.Column<string>(type: "character varying(250)", maxLength: 250, nullable: true),
                    villa_condominio = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: true),
                    numero = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    numero_casa_habitantes = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    conjunto = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    manzana = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    lote = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    region = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    comuna = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    existe_rol_avaluo = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    rol_avaluo_1 = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    rol_avaluo_2 = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    valor_avaluo_pesos = table.Column<decimal>(type: "numeric(18,2)", nullable: true),
                    enviar_reparo = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    observaciones = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    row_status = table.Column<bool>(type: "boolean", nullable: false),
                    created_by = table.Column<int>(type: "integer", nullable: false),
                    created_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    modified_by = table.Column<int>(type: "integer", nullable: true),
                    modified_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_revisar_datos_operacion_propiedad", x => x.id_revisar_datos_operacion_propiedad);
                });

            migrationBuilder.CreateIndex(
                name: "IX_revisar_datos_operacion_id_expediente",
                table: "revisar_datos_operacion",
                column: "id_expediente");

            migrationBuilder.CreateIndex(
                name: "IX_revisar_datos_operacion_propiedad_id_expediente",
                table: "revisar_datos_operacion_propiedad",
                column: "id_expediente");

            migrationBuilder.CreateIndex(
                name: "IX_revisar_datos_operacion_propiedad_id_revisar_datos_operacion",
                table: "revisar_datos_operacion_propiedad",
                column: "id_revisar_datos_operacion");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "revisar_datos_operacion");

            migrationBuilder.DropTable(
                name: "revisar_datos_operacion_propiedad");
        }
    }
}
