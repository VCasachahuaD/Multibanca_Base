﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Data.Repository.Implementations.Migrations
{
    /// <inheritdoc />
    public partial class CorrecionCOAntecedenteCredito : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // text -> numeric NO es cast automático en PostgreSQL: requiere USING.
            // El CASE convierte los valores no numéricos (ej. 'UF') a NULL en la misma
            // migración, así no falla por datos y no hace falta un UPDATE previo.
            migrationBuilder.Sql(@"
                ALTER TABLE carga_operacion_banco_antecedente_credito
                    ALTER COLUMN precio_venta_moneda_original TYPE numeric(18, 6)
                    USING CASE
                            WHEN btrim(precio_venta_moneda_original) ~ '^[0-9]+(\.[0-9]+)?$'
                              THEN btrim(precio_venta_moneda_original)::numeric(18, 6)
                            ELSE NULL
                          END;
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                ALTER TABLE carga_operacion_banco_antecedente_credito
                    ALTER COLUMN precio_venta_moneda_original TYPE character varying(100)
                    USING precio_venta_moneda_original::character varying(100);
            ");
        }
    }
}
