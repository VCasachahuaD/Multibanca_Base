﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Data.Repository.Implementations.Migrations
{
    /// <inheritdoc />
    public partial class CorreccionDatosOperacionDatosCredito : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "inmobiliaria",
                table: "datos_operacion_datos_credito");

            migrationBuilder.DropColumn(
                name: "monto_credito_afecto_impuesto",
                table: "datos_operacion_datos_credito");

            migrationBuilder.DropColumn(
                name: "nombre_proyecto",
                table: "datos_operacion_datos_credito");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "inmobiliaria",
                table: "datos_operacion_datos_credito",
                type: "character varying(250)",
                maxLength: 250,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "monto_credito_afecto_impuesto",
                table: "datos_operacion_datos_credito",
                type: "numeric(18,2)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "nombre_proyecto",
                table: "datos_operacion_datos_credito",
                type: "character varying(250)",
                maxLength: 250,
                nullable: true);
        }
    }
}
