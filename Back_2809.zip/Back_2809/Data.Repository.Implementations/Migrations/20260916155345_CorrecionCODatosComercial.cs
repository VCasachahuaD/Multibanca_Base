﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Data.Repository.Implementations.Migrations
{
    /// <inheritdoc />
    public partial class CorrecionCODatosComercial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "rut_ejecutivo_curse",
                table: "carga_operacion_banco_datos_comercial",
                type: "character varying(12)",
                maxLength: 12,
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "rut_ejecutivo",
                table: "carga_operacion_banco_datos_comercial",
                type: "character varying(12)",
                maxLength: 12,
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "rut_banco",
                table: "carga_operacion_banco_datos_comercial",
                type: "character varying(12)",
                maxLength: 12,
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "rut_ejecutivo_curse",
                table: "carga_operacion_banco_datos_comercial",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(12)",
                oldMaxLength: 12,
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "rut_ejecutivo",
                table: "carga_operacion_banco_datos_comercial",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(12)",
                oldMaxLength: 12,
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "rut_banco",
                table: "carga_operacion_banco_datos_comercial",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(12)",
                oldMaxLength: 12,
                oldNullable: true);
        }
    }
}
