import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import { InputText } from 'primereact/inputtext';

import type { ControlesDatosComercial } from '../models/catalogo';
import type { CargaOperacionBancoDatosComercial } from '../models/carga_operacion_banco';

interface DatosComercialSectionProps {
  value: CargaOperacionBancoDatosComercial;
  disabled: boolean;
  controles: ControlesDatosComercial;
  loadingControles?: boolean;
  onChange: <K extends keyof CargaOperacionBancoDatosComercial>(
    field: K,
    value: CargaOperacionBancoDatosComercial[K],
  ) => void;
}

const emptyMessage = 'Sin resultados';

export default function DatosComercialSection({
  value,
  disabled,
  controles,
  loadingControles = false,
  onChange,
}: DatosComercialSectionProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Código Ejecutivo</label>
        <InputNumber
          value={value.codigo_ejecutivo ?? null}
          onValueChange={(e) => onChange('codigo_ejecutivo', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese código"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Login Ejecutivo</label>
        <InputText
          value={value.login_ejecutivo ?? ''}
          onChange={(e) => onChange('login_ejecutivo', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese login"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Nombre Ejecutivo</label>
        <InputText
          value={value.nombre_ejecutivo ?? ''}
          onChange={(e) => onChange('nombre_ejecutivo', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese nombre"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">RUT Ejecutivo</label>
        <InputNumber
          value={value.rut_ejecutivo ?? null}
          onValueChange={(e) => onChange('rut_ejecutivo', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese RUT"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Código Oficina</label>
        <InputNumber
          value={value.codigo_oficina ?? null}
          onValueChange={(e) => onChange('codigo_oficina', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese código"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Nombre Oficina</label>
        <InputText
          value={value.nombre_oficina ?? ''}
          onChange={(e) => onChange('nombre_oficina', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese oficina"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Código Curse</label>
        <InputNumber
          value={value.codigo_curse ?? null}
          onValueChange={(e) => onChange('codigo_curse', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese código"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Glosa Curse</label>
        <InputText
          value={value.glosa_curse ?? ''}
          onChange={(e) => onChange('glosa_curse', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese glosa"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Código Ejecutivo Curse</label>
        <InputNumber
          value={value.codigo_ejecutivo_curse ?? null}
          onValueChange={(e) => onChange('codigo_ejecutivo_curse', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese código"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Login Ejecutivo Curse</label>
        <InputText
          value={value.login_ejecutivo_curse ?? ''}
          onChange={(e) => onChange('login_ejecutivo_curse', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese login"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Nombre Ejecutivo Curse</label>
        <InputText
          value={value.nombre_ejecutivo_curse ?? ''}
          onChange={(e) => onChange('nombre_ejecutivo_curse', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese nombre"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">RUT Ejecutivo Curse</label>
        <InputNumber
          value={value.rut_ejecutivo_curse ?? null}
          onValueChange={(e) => onChange('rut_ejecutivo_curse', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese RUT"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">RUT Banco</label>
        <InputNumber
          value={value.rut_banco ?? null}
          onValueChange={(e) => onChange('rut_banco', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese RUT banco"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Renovación Urbana</label>
        <InputText
          value={value.renovacion_urbana ?? ''}
          onChange={(e) => onChange('renovacion_urbana', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese renovación urbana"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Nombre Banco</label>
        <InputText
          value={value.nombre_banco ?? ''}
          onChange={(e) => onChange('nombre_banco', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese banco"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tipo Hipoteca *</label>
        <Dropdown
          value={value.tipo_hipoteca ?? null}
          options={controles.tipo_hipoteca}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('tipo_hipoteca', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
          filter
        />
      </div>
    </div>
  );
}
