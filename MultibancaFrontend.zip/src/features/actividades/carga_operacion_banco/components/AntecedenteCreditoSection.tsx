import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import { InputText } from 'primereact/inputtext';

import type { ControlesAntecedenteCredito } from '../models/catalogo';
import type { CargaOperacionBancoAntecedenteCredito } from '../models/carga_operacion_banco';

interface AntecedenteCreditoSectionProps {
  value: CargaOperacionBancoAntecedenteCredito;
  disabled: boolean;
  controles: ControlesAntecedenteCredito;
  loadingControles?: boolean;
  onChange: <K extends keyof CargaOperacionBancoAntecedenteCredito>(
    field: K,
    value: CargaOperacionBancoAntecedenteCredito[K],
  ) => void;
}

const emptyMessage = 'Sin resultados';

const toDate = (value?: string | null): Date | null => {
  if (!value) return null;

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const toIsoDate = (value: Date | null | undefined): string | null => {
  if (!value) return null;
  return value.toISOString();
};

export default function AntecedenteCreditoSection({
  value,
  disabled,
  controles,
  loadingControles = false,
  onChange,
}: AntecedenteCreditoSectionProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tipo Préstamo *</label>
        <Dropdown
          value={value.tipo_prestamo ?? null}
          options={controles.tipo_prestamo}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('tipo_prestamo', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
          filter
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Factor Conversión UF</label>
        <InputNumber
          value={value.factor_conversion_uf ?? null}
          onValueChange={(e) => onChange('factor_conversion_uf', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={6}
          placeholder="Ingrese factor"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Destino Crédito *</label>
        <Dropdown
          value={value.destino_credito ?? null}
          options={controles.destino_credito}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('destino_credito', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
          filter
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Monto Solicitado</label>
        <InputNumber
          value={value.monto_solicitado ?? null}
          onValueChange={(e) => onChange('monto_solicitado', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese monto"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tipo Tasa *</label>
        <Dropdown
          value={value.tipo_tasa ?? null}
          options={controles.tipo_tasa}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('tipo_tasa', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tasa</label>
        <InputNumber
          value={value.tasa ?? null}
          onValueChange={(e) => onChange('tasa', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={6}
          placeholder="Ingrese tasa"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Plazo</label>
        <InputNumber
          value={value.plazo ?? null}
          onValueChange={(e) => onChange('plazo', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese plazo"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Fecha Inicio</label>
        <Calendar
          value={toDate(value.fecha_inicio)}
          onChange={(e) => onChange('fecha_inicio', toIsoDate(e.value as Date | null))}
          className="form-input-presto w-full"
          disabled={disabled}
          dateFormat="dd/mm/yy"
          showIcon
          placeholder="Seleccione fecha"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Monto Nominal</label>
        <InputNumber
          value={value.monto_nominal ?? null}
          onValueChange={(e) => onChange('monto_nominal', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese monto nominal"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Monto Residual</label>
        <InputNumber
          value={value.monto_residual ?? null}
          onValueChange={(e) => onChange('monto_residual', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese monto residual"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Plazo Primer Periodo</label>
        <InputNumber
          value={value.plazo_primer_periodo ?? null}
          onValueChange={(e) => onChange('plazo_primer_periodo', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese plazo"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Periodo Gracia</label>
        <InputNumber
          value={value.periodo_gracia ?? null}
          onValueChange={(e) => onChange('periodo_gracia', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese periodo"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Comisión</label>
        <InputNumber
          value={value.comision ?? null}
          onValueChange={(e) => onChange('comision', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese comisión"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Plazo Segundo Periodo</label>
        <InputNumber
          value={value.plazo_segundo_periodo ?? null}
          onValueChange={(e) => onChange('plazo_segundo_periodo', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese plazo"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tasa Primer Periodo</label>
        <InputNumber
          value={value.tasa_primer_periodo ?? null}
          onValueChange={(e) => onChange('tasa_primer_periodo', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={6}
          placeholder="Ingrese tasa"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Meses Sabáticos</label>
        <InputNumber
          value={value.meses_sabaticos ?? null}
          onValueChange={(e) => onChange('meses_sabaticos', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese meses"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Variabilidad Tasa</label>
        <InputText
          value={value.variabilidad_tasa ?? ''}
          onChange={(e) => onChange('variabilidad_tasa', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese variabilidad"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tasa Segundo Periodo</label>
        <InputNumber
          value={value.tasa_segundo_periodo ?? null}
          onValueChange={(e) => onChange('tasa_segundo_periodo', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={6}
          placeholder="Ingrese tasa"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Moneda *</label>
        <Dropdown
          value={value.moneda ?? null}
          options={controles.moneda}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('moneda', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tipo Tasa Mixta Prod. Com.</label>
        <InputText
          value={value.tipo_tasa_mixta_prod_com ?? ''}
          onChange={(e) => onChange('tipo_tasa_mixta_prod_com', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese tipo tasa mixta"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tasa Máxima</label>
        <InputNumber
          value={value.tasa_maxima ?? null}
          onValueChange={(e) => onChange('tasa_maxima', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={6}
          placeholder="Ingrese tasa máxima"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Código Producto Cartera</label>
        <InputText
          value={value.codigo_producto_cartera ?? ''}
          onChange={(e) => onChange('codigo_producto_cartera', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese código"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Indicador Segunda Vivienda</label>
        <InputText
          value={value.indicador_segunda_vivienda ?? ''}
          onChange={(e) => onChange('indicador_segunda_vivienda', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese indicador"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tipo Financiamiento *</label>
        <Dropdown
          value={value.tipo_financiamiento ?? null}
          options={controles.tipo_financiamiento}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('tipo_financiamiento', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
          filter
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Precio Venta Pesos</label>
        <InputNumber
          value={value.precio_venta_pesos ?? null}
          onValueChange={(e) => onChange('precio_venta_pesos', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese precio"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Precio Venta Moneda Original</label>
        <InputText
          value={value.precio_venta_moneda_original ?? ''}
          onChange={(e) => onChange('precio_venta_moneda_original', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese moneda original"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Cantidad Meses Sin Vencimiento</label>
        <InputNumber
          value={value.cantidad_meses_sin_vencimiento ?? null}
          onValueChange={(e) => onChange('cantidad_meses_sin_vencimiento', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese cantidad"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Indicador Cred. Comp.</label>
        <InputNumber
          value={value.indicador_cred_comp ?? null}
          onValueChange={(e) => onChange('indicador_cred_comp', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese indicador"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Indicador PAC</label>
        <InputText
          value={value.indicador_pac ?? ''}
          onChange={(e) => onChange('indicador_pac', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese indicador PAC"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tipo Tasa Aplic. Contab.</label>
        <InputText
          value={value.tipo_tasa_aplic_contab ?? ''}
          onChange={(e) => onChange('tipo_tasa_aplic_contab', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese tipo tasa"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">N° Cuenta Gastos</label>
        <InputNumber
          value={value.numero_cuenta_gastos ?? null}
          onValueChange={(e) => onChange('numero_cuenta_gastos', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese cuenta"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Préstamo Máximo</label>
        <InputNumber
          value={value.prestamo_maximo ?? null}
          onValueChange={(e) => onChange('prestamo_maximo', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese préstamo máximo"
        />
      </div>
    </div>
  );
}
