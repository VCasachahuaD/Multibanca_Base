import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import { InputText } from 'primereact/inputtext';

import type { CatalogoOption } from '../models/catalogo';
import type { CargaOperacionBancoDatosOperacion } from '../models/carga_operacion_banco';

interface DatosOperacionSectionProps {
  value: CargaOperacionBancoDatosOperacion;
  disabled: boolean;
  catalogos: {
    tipo_operacion: CatalogoOption[];
    segmento: CatalogoOption[];
    canal_venta: CatalogoOption[];
    modelo_operacion: CatalogoOption[];
    tipo_carpeta: CatalogoOption[];
    inmobiliaria: CatalogoOption[];
    glosa_producto: CatalogoOption[];
    codigo_producto_comercial: CatalogoOption[];
    banco_alzante: CatalogoOption[];
  };
  loadingCatalogos?: boolean;
  onChange: <K extends keyof CargaOperacionBancoDatosOperacion>(
    field: K,
    value: CargaOperacionBancoDatosOperacion[K],
  ) => void;
}

const emptyMessage = 'Sin resultados';

export default function DatosOperacionSection({
  value,
  disabled,
  catalogos,
  loadingCatalogos = false,
  onChange,
}: DatosOperacionSectionProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">N° Mutuo *</label>
        <InputNumber
          value={value.nro_mutuo ?? null}
          onValueChange={(e) => onChange('nro_mutuo', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese N° Mutuo"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tipo Operación *</label>
        <Dropdown
          value={value.tipo_operacion ?? null}
          options={catalogos.tipo_operacion}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('tipo_operacion', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingCatalogos}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
          filter
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">N° Registro *</label>
        <InputNumber
          value={value.nro_registro ?? null}
          onValueChange={(e) => onChange('nro_registro', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese N° Registro"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Ult. Clasif. al *</label>
        <InputText
          value={value.ult_clasif_al ?? ''}
          onChange={(e) => onChange('ult_clasif_al', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese clasificación"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Segmento *</label>
        <Dropdown
          value={value.segmento ?? null}
          options={catalogos.segmento}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('segmento', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingCatalogos}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Canal de Venta *</label>
        <Dropdown
          value={value.canal_venta ?? null}
          options={catalogos.canal_venta}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('canal_venta', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingCatalogos}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">N° Op. Cartera *</label>
        <InputNumber
          value={value.nro_op_cartera ?? null}
          onValueChange={(e) => onChange('nro_op_cartera', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese N° Op. Cartera"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Modelo de Operación *</label>
        <Dropdown
          value={value.modelo_operacion ?? null}
          options={catalogos.modelo_operacion}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('modelo_operacion', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingCatalogos}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Tipo Carpeta *</label>
        <Dropdown
          value={value.tipo_carpeta ?? null}
          options={catalogos.tipo_carpeta}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('tipo_carpeta', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingCatalogos}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Propietario *</label>
        <InputText
          value={value.propietario ?? ''}
          onChange={(e) => onChange('propietario', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese propietario"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Inmobiliaria *</label>
        <Dropdown
          value={value.inmobiliaria ?? null}
          options={catalogos.inmobiliaria}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('inmobiliaria', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingCatalogos}
          placeholder="Seleccione o busque"
          emptyMessage={emptyMessage}
          showClear
          filter
          resetFilterOnHide
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Glosa Producto *</label>
        <Dropdown
          value={value.glosa_producto ?? null}
          options={catalogos.glosa_producto}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('glosa_producto', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingCatalogos}
          placeholder="Seleccione o busque"
          emptyMessage={emptyMessage}
          showClear
          filter
          resetFilterOnHide
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Código Producto Comercial *</label>
        <Dropdown
          value={value.codigo_producto_comercial ?? null}
          options={catalogos.codigo_producto_comercial}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('codigo_producto_comercial', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingCatalogos}
          placeholder="Seleccione o busque"
          emptyMessage={emptyMessage}
          showClear
          filter
          resetFilterOnHide
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">N° Piloto</label>
        <InputNumber
          value={value.nro_piloto ?? null}
          onValueChange={(e) => onChange('nro_piloto', e.value ?? null)}
          className="form-input-presto w-full"
          inputClassName="w-full"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese N° Piloto"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Banco Alzante</label>
        <Dropdown
          value={value.banco_alzante ?? null}
          options={catalogos.banco_alzante}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('banco_alzante', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingCatalogos}
          placeholder="Seleccione o busque"
          emptyMessage={emptyMessage}
          showClear
          filter
          resetFilterOnHide
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="font-semibold text-sm">Nombre Proyecto</label>
        <InputText
          value={value.nombre_proyecto ?? ''}
          onChange={(e) => onChange('nombre_proyecto', e.target.value)}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese nombre de proyecto"
        />
      </div>
    </div>
  );
}
