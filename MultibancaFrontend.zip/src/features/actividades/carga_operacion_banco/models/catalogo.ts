export interface CatalogoOption {
  code?: string | null;
  description?: string | null;
}

export interface ControlesDatosOperacion {
  tipo_operacion: CatalogoOption[];
  segmento: CatalogoOption[];
  canal_venta: CatalogoOption[];
  modelo_operacion: CatalogoOption[];
  tipo_carpeta: CatalogoOption[];
  inmobiliaria: CatalogoOption[];
  glosa_producto: CatalogoOption[];
  codigo_producto_comercial: CatalogoOption[];
  banco_alzante: CatalogoOption[];
}

export interface ControlesAntecedenteComprador {
  tipo_comprador: CatalogoOption[];
  genero: CatalogoOption[];
  estado_civil: CatalogoOption[];
  relacion_titular: CatalogoOption[];
  region: CatalogoOption[];
  comuna: CatalogoOption[];
  nacionalidad: CatalogoOption[];
}

export interface ControlesAntecedenteVendedor {
  tipo_vendedor: CatalogoOption[];
  genero: CatalogoOption[];
  estado_civil: CatalogoOption[];
  relacion_titular: CatalogoOption[];
  region: CatalogoOption[];
  comuna: CatalogoOption[];
  nacionalidad: CatalogoOption[];
}


export interface ControlesAntecedenteCredito {
  tipo_prestamo: CatalogoOption[];
  destino_credito: CatalogoOption[];
  tipo_tasa: CatalogoOption[];
  moneda: CatalogoOption[];
  tipo_financiamiento: CatalogoOption[];
}

export interface ControlesDatosComercial {
  tipo_hipoteca: CatalogoOption[];
}

export const EMPTY_CONTROLES_DATOS_OPERACION: ControlesDatosOperacion = {
  tipo_operacion: [],
  segmento: [],
  canal_venta: [],
  modelo_operacion: [],
  tipo_carpeta: [],
  inmobiliaria: [],
  glosa_producto: [],
  codigo_producto_comercial: [],
  banco_alzante: [],
};

export const EMPTY_CONTROLES_ANTECEDENTE_COMPRADOR: ControlesAntecedenteComprador = {
  tipo_comprador: [],
  genero: [],
  estado_civil: [],
  relacion_titular: [],
  region: [],
  comuna: [],
  nacionalidad: [],
};

export const EMPTY_CONTROLES_ANTECEDENTE_VENDEDOR: ControlesAntecedenteVendedor = {
  tipo_vendedor: [],
  genero: [],
  estado_civil: [],
  relacion_titular: [],
  region: [],
  comuna: [],
  nacionalidad: [],
};

export const EMPTY_CONTROLES_ANTECEDENTE_CREDITO: ControlesAntecedenteCredito = {
  tipo_prestamo: [],
  destino_credito: [],
  tipo_tasa: [],
  moneda: [],
  tipo_financiamiento: [],
};

export const EMPTY_CONTROLES_DATOS_COMERCIAL: ControlesDatosComercial = {
  tipo_hipoteca: [],
};
