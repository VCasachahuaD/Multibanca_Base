import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import { Toast } from 'primereact/toast';

import EncabezadoActividad from '@/features/encabezado/pages/EncabezadoActividad';
import FuncionesTransversales from '@/features/funciones_transversales/pages/FuncionesTransversales';
import AntecedenteCreditoSection from '../components/AntecedenteCreditoSection';
import AntecedentesCompradorSection from '../components/AntecedentesCompradorSection';
import AntecedentesVendedorSection from '../components/AntecedentesVendedorSection';
import DatosComercialSection from '../components/DatosComercialSection';
import DatosOperacionSection from '../components/DatosOperacionSection';
import { useAvanzarCargaOperacionBanco } from '../hooks/useAvanzarCargaOperacionBanco';
import { useCargaOperacionBanco } from '../hooks/useCargaOperacionBanco';
import { useControlesAntecedenteComprador } from '../hooks/useControlesAntecedenteComprador';
import { useControlesAntecedenteCredito } from '../hooks/useControlesAntecedenteCredito';
import { useControlesAntecedenteVendedor } from '../hooks/useControlesAntecedenteVendedor';
import { useControlesDatosComercial } from '../hooks/useControlesDatosComercial';
import { useControlesDatosOperacion } from '../hooks/useControlesDatosOperacion';
import { useUpsertCargaOperacionBanco } from '../hooks/useUpsertCargaOperacionBanco';
import {
  EMPTY_CONTROLES_ANTECEDENTE_COMPRADOR,
  EMPTY_CONTROLES_ANTECEDENTE_CREDITO,
  EMPTY_CONTROLES_ANTECEDENTE_VENDEDOR,
  EMPTY_CONTROLES_DATOS_COMERCIAL,
  EMPTY_CONTROLES_DATOS_OPERACION,
  type ControlesAntecedenteComprador,
  type ControlesAntecedenteCredito,
  type ControlesAntecedenteVendedor,
  type ControlesDatosComercial,
  type ControlesDatosOperacion,
} from '../models/catalogo';
import type {
  CargaOperacionBanco,
  CargaOperacionBancoAntecedenteComprador,
  CargaOperacionBancoAntecedenteCredito,
  CargaOperacionBancoAntecedenteVendedor,
  CargaOperacionBancoDatosComercial,
  CargaOperacionBancoDatosOperacion,
} from '../models/carga_operacion_banco';

/**
 * TODO:
 * Reemplazar por el id real de la actividad 3.1 Carga Operación Banco
 * cuando esté configurado en el workflow.
 */
const ACTIVITY_ID = '_4X3k8H6kEeeGvo3jOJ1wYw';

const now = () => new Date().toISOString();

const buildDatosOperacionInitialState = (
  id_expediente: number,
): CargaOperacionBancoDatosOperacion => ({
  id_carga_operacion_banco_datos_operacion: 0,
  id_carga_operacion_banco: 0,
  id_expediente,
  nro_mutuo: null,
  tipo_operacion: null,
  nro_registro: null,
  ult_clasif_al: '',
  segmento: null,
  canal_venta: null,
  nro_op_cartera: null,
  modelo_operacion: null,
  tipo_carpeta: null,
  propietario: '',
  inmobiliaria: null,
  glosa_producto: null,
  codigo_producto_comercial: null,
  nro_piloto: null,
  banco_alzante: null,
  nombre_proyecto: '',
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const buildCompradorInitialState = (
  id_expediente: number,
  id_carga_operacion_banco = 0,
): CargaOperacionBancoAntecedenteComprador => ({
  id_carga_operacion_banco_antecedente_comprador: 0,
  id_carga_operacion_banco,
  id_expediente,
  rut: '',
  tipo_comprador: null,
  razon_social: '',
  nombres: '',
  apellido_paterno: '',
  apellido_materno: '',
  fecha_nacimiento: null,
  genero: null,
  estado_civil: null,
  relacion_titular: null,
  direccion: '',
  region: null,
  comuna: null,
  telefono: '',
  email: '',
  nacionalidad: null,
  profesion: '',
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const buildVendedorInitialState = (
  id_expediente: number,
  id_carga_operacion_banco = 0,
): CargaOperacionBancoAntecedenteVendedor => ({
  id_carga_operacion_banco_antecedente_vendedor: 0,
  id_carga_operacion_banco,
  id_expediente,
  rut: '',
  tipo_vendedor: null,
  razon_social: '',
  nombres: '',
  apellido_paterno: '',
  apellido_materno: '',
  fecha_nacimiento: null,
  genero: null,
  estado_civil: null,
  relacion_titular: null,
  direccion: '',
  region: null,
  comuna: null,
  telefono: '',
  email: '',
  nacionalidad: null,
  profesion: '',
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const buildAntecedenteCreditoInitialState = (
  id_expediente: number,
  id_carga_operacion_banco = 0,
): CargaOperacionBancoAntecedenteCredito => ({
  id_carga_operacion_banco_antecedente_credito: 0,
  id_carga_operacion_banco,
  id_expediente,
  tipo_prestamo: null,
  factor_conversion_uf: null,
  destino_credito: null,
  monto_solicitado: null,
  tipo_tasa: null,
  tasa: null,
  plazo: null,
  fecha_inicio: null,
  monto_nominal: null,
  monto_residual: null,
  plazo_primer_periodo: null,
  periodo_gracia: null,
  comision: null,
  plazo_segundo_periodo: null,
  tasa_primer_periodo: null,
  meses_sabaticos: null,
  variabilidad_tasa: '',
  tasa_segundo_periodo: null,
  moneda: null,
  tipo_tasa_mixta_prod_com: '',
  tasa_maxima: null,
  codigo_producto_cartera: '',
  indicador_segunda_vivienda: '',
  tipo_financiamiento: null,
  precio_venta_pesos: null,
  precio_venta_moneda_original: '',
  cantidad_meses_sin_vencimiento: null,
  indicador_cred_comp: null,
  indicador_pac: '',
  tipo_tasa_aplic_contab: '',
  numero_cuenta_gastos: null,
  prestamo_maximo: null,
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const buildDatosComercialInitialState = (
  id_expediente: number,
  id_carga_operacion_banco = 0,
): CargaOperacionBancoDatosComercial => ({
  id_carga_operacion_banco_datos_comercial: 0,
  id_carga_operacion_banco,
  id_expediente,
  codigo_ejecutivo: null,
  login_ejecutivo: '',
  nombre_ejecutivo: '',
  rut_ejecutivo: null,
  codigo_oficina: null,
  nombre_oficina: '',
  codigo_curse: null,
  glosa_curse: '',
  codigo_ejecutivo_curse: null,
  login_ejecutivo_curse: '',
  nombre_ejecutivo_curse: '',
  rut_ejecutivo_curse: null,
  rut_banco: null,
  renovacion_urbana: '',
  nombre_banco: '',
  tipo_hipoteca: null,
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const buildInitialState = (id_expediente: number): CargaOperacionBanco => ({
  id_carga_operacion_banco: 0,
  id_expediente,
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
  datos_operacion: buildDatosOperacionInitialState(id_expediente),
  antecedentes_comprador: [],
  antecedentes_vendedor: [],
  antecedente_credito: buildAntecedenteCreditoInitialState(id_expediente),
  datos_comercial: buildDatosComercialInitialState(id_expediente),
});

const normalizeDatosOperacion = (
  source: Partial<CargaOperacionBancoDatosOperacion> | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoDatosOperacion => ({
  id_carga_operacion_banco_datos_operacion: Number(
    source?.id_carga_operacion_banco_datos_operacion ?? 0,
  ),
  id_carga_operacion_banco: Number(
    source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
  nro_mutuo:
    source?.nro_mutuo === undefined || source?.nro_mutuo === null
      ? null
      : Number(source.nro_mutuo),
  tipo_operacion: source?.tipo_operacion ?? null,
  nro_registro:
    source?.nro_registro === undefined || source?.nro_registro === null
      ? null
      : Number(source.nro_registro),
  ult_clasif_al: source?.ult_clasif_al ?? '',
  segmento: source?.segmento ?? null,
  canal_venta: source?.canal_venta ?? null,
  nro_op_cartera:
    source?.nro_op_cartera === undefined || source?.nro_op_cartera === null
      ? null
      : Number(source.nro_op_cartera),
  modelo_operacion: source?.modelo_operacion ?? null,
  tipo_carpeta: source?.tipo_carpeta ?? null,
  propietario: source?.propietario ?? '',
  inmobiliaria: source?.inmobiliaria ?? null,
  glosa_producto: source?.glosa_producto ?? null,
  codigo_producto_comercial: source?.codigo_producto_comercial ?? null,
  nro_piloto:
    source?.nro_piloto === undefined || source?.nro_piloto === null
      ? null
      : Number(source.nro_piloto),
  banco_alzante: source?.banco_alzante ?? null,
  nombre_proyecto: source?.nombre_proyecto ?? '',
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? now(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const normalizeAntecedenteComprador = (
  source: Partial<CargaOperacionBancoAntecedenteComprador> | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoAntecedenteComprador => ({
  ...buildCompradorInitialState(
    Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    Number(source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0),
  ),
  id_carga_operacion_banco_antecedente_comprador: Number(
    source?.id_carga_operacion_banco_antecedente_comprador ?? 0,
  ),
  id_carga_operacion_banco: Number(
    source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
  rut: source?.rut ?? '',
  tipo_comprador: source?.tipo_comprador ?? null,
  razon_social: source?.razon_social ?? '',
  nombres: source?.nombres ?? '',
  apellido_paterno: source?.apellido_paterno ?? '',
  apellido_materno: source?.apellido_materno ?? '',
  fecha_nacimiento: source?.fecha_nacimiento ?? null,
  genero: source?.genero ?? null,
  estado_civil: source?.estado_civil ?? null,
  relacion_titular: source?.relacion_titular ?? null,
  direccion: source?.direccion ?? '',
  region: source?.region ?? null,
  comuna: source?.comuna ?? null,
  telefono: source?.telefono ?? '',
  email: source?.email ?? '',
  nacionalidad: source?.nacionalidad ?? null,
  profesion: source?.profesion ?? '',
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? now(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const normalizeAntecedenteVendedor = (
  source: Partial<CargaOperacionBancoAntecedenteVendedor> | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoAntecedenteVendedor => ({
  ...buildVendedorInitialState(
    Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    Number(source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0),
  ),
  id_carga_operacion_banco_antecedente_vendedor: Number(
    source?.id_carga_operacion_banco_antecedente_vendedor ?? 0,
  ),
  id_carga_operacion_banco: Number(
    source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
  rut: source?.rut ?? '',
  tipo_vendedor: source?.tipo_vendedor ?? null,
  razon_social: source?.razon_social ?? '',
  nombres: source?.nombres ?? '',
  apellido_paterno: source?.apellido_paterno ?? '',
  apellido_materno: source?.apellido_materno ?? '',
  fecha_nacimiento: source?.fecha_nacimiento ?? null,
  genero: source?.genero ?? null,
  estado_civil: source?.estado_civil ?? null,
  relacion_titular: source?.relacion_titular ?? null,
  direccion: source?.direccion ?? '',
  region: source?.region ?? null,
  comuna: source?.comuna ?? null,
  telefono: source?.telefono ?? '',
  email: source?.email ?? '',
  nacionalidad: source?.nacionalidad ?? null,
  profesion: source?.profesion ?? '',
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? now(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const normalizeAntecedentesComprador = (
  source: Partial<CargaOperacionBancoAntecedenteComprador>[] | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoAntecedenteComprador[] =>
  (source ?? []).map((comprador) =>
    normalizeAntecedenteComprador(
      comprador,
      id_expediente_fallback,
      id_carga_operacion_banco_fallback,
    ),
  );

const normalizeAntecedentesVendedor = (
  source: Partial<CargaOperacionBancoAntecedenteVendedor>[] | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoAntecedenteVendedor[] =>
  (source ?? []).map((vendedor) =>
    normalizeAntecedenteVendedor(
      vendedor,
      id_expediente_fallback,
      id_carga_operacion_banco_fallback,
    ),
  );

const normalizeAntecedenteCredito = (
  source: Partial<CargaOperacionBancoAntecedenteCredito> | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoAntecedenteCredito => ({
  ...buildAntecedenteCreditoInitialState(
    Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    Number(source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0),
  ),
  id_carga_operacion_banco_antecedente_credito: Number(
    source?.id_carga_operacion_banco_antecedente_credito ?? 0,
  ),
  id_carga_operacion_banco: Number(
    source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
  tipo_prestamo: source?.tipo_prestamo ?? null,
  factor_conversion_uf:
    source?.factor_conversion_uf === undefined || source?.factor_conversion_uf === null
      ? null
      : Number(source.factor_conversion_uf),
  destino_credito: source?.destino_credito ?? null,
  monto_solicitado:
    source?.monto_solicitado === undefined || source?.monto_solicitado === null
      ? null
      : Number(source.monto_solicitado),
  tipo_tasa: source?.tipo_tasa ?? null,
  tasa: source?.tasa === undefined || source?.tasa === null ? null : Number(source.tasa),
  plazo: source?.plazo === undefined || source?.plazo === null ? null : Number(source.plazo),
  fecha_inicio: source?.fecha_inicio ?? null,
  monto_nominal:
    source?.monto_nominal === undefined || source?.monto_nominal === null
      ? null
      : Number(source.monto_nominal),
  monto_residual:
    source?.monto_residual === undefined || source?.monto_residual === null
      ? null
      : Number(source.monto_residual),
  plazo_primer_periodo:
    source?.plazo_primer_periodo === undefined || source?.plazo_primer_periodo === null
      ? null
      : Number(source.plazo_primer_periodo),
  periodo_gracia:
    source?.periodo_gracia === undefined || source?.periodo_gracia === null
      ? null
      : Number(source.periodo_gracia),
  comision:
    source?.comision === undefined || source?.comision === null
      ? null
      : Number(source.comision),
  plazo_segundo_periodo:
    source?.plazo_segundo_periodo === undefined || source?.plazo_segundo_periodo === null
      ? null
      : Number(source.plazo_segundo_periodo),
  tasa_primer_periodo:
    source?.tasa_primer_periodo === undefined || source?.tasa_primer_periodo === null
      ? null
      : Number(source.tasa_primer_periodo),
  meses_sabaticos:
    source?.meses_sabaticos === undefined || source?.meses_sabaticos === null
      ? null
      : Number(source.meses_sabaticos),
  variabilidad_tasa: source?.variabilidad_tasa ?? '',
  tasa_segundo_periodo:
    source?.tasa_segundo_periodo === undefined || source?.tasa_segundo_periodo === null
      ? null
      : Number(source.tasa_segundo_periodo),
  moneda: source?.moneda ?? null,
  tipo_tasa_mixta_prod_com: source?.tipo_tasa_mixta_prod_com ?? '',
  tasa_maxima:
    source?.tasa_maxima === undefined || source?.tasa_maxima === null
      ? null
      : Number(source.tasa_maxima),
  codigo_producto_cartera: source?.codigo_producto_cartera ?? '',
  indicador_segunda_vivienda: source?.indicador_segunda_vivienda ?? '',
  tipo_financiamiento: source?.tipo_financiamiento ?? null,
  precio_venta_pesos:
    source?.precio_venta_pesos === undefined || source?.precio_venta_pesos === null
      ? null
      : Number(source.precio_venta_pesos),
  precio_venta_moneda_original: source?.precio_venta_moneda_original ?? '',
  cantidad_meses_sin_vencimiento:
    source?.cantidad_meses_sin_vencimiento === undefined ||
    source?.cantidad_meses_sin_vencimiento === null
      ? null
      : Number(source.cantidad_meses_sin_vencimiento),
  indicador_cred_comp:
    source?.indicador_cred_comp === undefined || source?.indicador_cred_comp === null
      ? null
      : Number(source.indicador_cred_comp),
  indicador_pac: source?.indicador_pac ?? '',
  tipo_tasa_aplic_contab: source?.tipo_tasa_aplic_contab ?? '',
  numero_cuenta_gastos:
    source?.numero_cuenta_gastos === undefined || source?.numero_cuenta_gastos === null
      ? null
      : Number(source.numero_cuenta_gastos),
  prestamo_maximo:
    source?.prestamo_maximo === undefined || source?.prestamo_maximo === null
      ? null
      : Number(source.prestamo_maximo),
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? now(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const normalizeDatosComercial = (
  source: Partial<CargaOperacionBancoDatosComercial> | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoDatosComercial => ({
  ...buildDatosComercialInitialState(
    Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    Number(source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0),
  ),
  id_carga_operacion_banco_datos_comercial: Number(
    source?.id_carga_operacion_banco_datos_comercial ?? 0,
  ),
  id_carga_operacion_banco: Number(
    source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
  codigo_ejecutivo:
    source?.codigo_ejecutivo === undefined || source?.codigo_ejecutivo === null
      ? null
      : Number(source.codigo_ejecutivo),
  login_ejecutivo: source?.login_ejecutivo ?? '',
  nombre_ejecutivo: source?.nombre_ejecutivo ?? '',
  rut_ejecutivo:
    source?.rut_ejecutivo === undefined || source?.rut_ejecutivo === null
      ? null
      : Number(source.rut_ejecutivo),
  codigo_oficina:
    source?.codigo_oficina === undefined || source?.codigo_oficina === null
      ? null
      : Number(source.codigo_oficina),
  nombre_oficina: source?.nombre_oficina ?? '',
  codigo_curse:
    source?.codigo_curse === undefined || source?.codigo_curse === null
      ? null
      : Number(source.codigo_curse),
  glosa_curse: source?.glosa_curse ?? '',
  codigo_ejecutivo_curse:
    source?.codigo_ejecutivo_curse === undefined || source?.codigo_ejecutivo_curse === null
      ? null
      : Number(source.codigo_ejecutivo_curse),
  login_ejecutivo_curse: source?.login_ejecutivo_curse ?? '',
  nombre_ejecutivo_curse: source?.nombre_ejecutivo_curse ?? '',
  rut_ejecutivo_curse:
    source?.rut_ejecutivo_curse === undefined || source?.rut_ejecutivo_curse === null
      ? null
      : Number(source.rut_ejecutivo_curse),
  rut_banco:
    source?.rut_banco === undefined || source?.rut_banco === null
      ? null
      : Number(source.rut_banco),
  renovacion_urbana: source?.renovacion_urbana ?? '',
  nombre_banco: source?.nombre_banco ?? '',
  tipo_hipoteca: source?.tipo_hipoteca ?? null,
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? now(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const normalizeCargaOperacionBanco = (
  source: Partial<CargaOperacionBanco> | null | undefined,
  id_expediente_fallback: number,
): CargaOperacionBanco => {
  const idCargaOperacionBanco = Number(source?.id_carga_operacion_banco ?? 0);
  const idExpediente = Number(source?.id_expediente ?? id_expediente_fallback ?? 0);

  return {
    id_carga_operacion_banco: idCargaOperacionBanco,
    id_expediente: idExpediente,
    is_active: source?.is_active ?? true,
    row_status: source?.row_status ?? true,
    created_by: Number(source?.created_by ?? 0),
    created_date: source?.created_date ?? now(),
    modified_by: source?.modified_by ?? null,
    modified_date: source?.modified_date ?? null,
    datos_operacion: normalizeDatosOperacion(
      source?.datos_operacion,
      idExpediente,
      idCargaOperacionBanco,
    ),
    antecedentes_comprador: normalizeAntecedentesComprador(
      source?.antecedentes_comprador,
      idExpediente,
      idCargaOperacionBanco,
    ),
    antecedentes_vendedor: normalizeAntecedentesVendedor(
      source?.antecedentes_vendedor,
      idExpediente,
      idCargaOperacionBanco,
    ),
    antecedente_credito: normalizeAntecedenteCredito(
      source?.antecedente_credito,
      idExpediente,
      idCargaOperacionBanco,
    ),
    datos_comercial: normalizeDatosComercial(
      source?.datos_comercial,
      idExpediente,
      idCargaOperacionBanco,
    ),
  };
};

export default function CargaOperacionBancoPage() {
  const toast = useRef<Toast>(null);

  const navigate = useNavigate();
  const { id_expediente: idExpedienteParam } = useParams();

  const id_expediente = Number(idExpedienteParam ?? 0);

  const [form, setForm] = useState<CargaOperacionBanco>(
    buildInitialState(id_expediente),
  );
  const [isDisabled, setIsDisabled] = useState(true);
  const [canAdvance, setCanAdvance] = useState(false);
  const [isBusy, setIsBusy] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef<number>(id_expediente);

  const idemKeyRef = useRef<string | null>(null);

  const { data, isLoading } = useCargaOperacionBanco(id_expediente);
  const saveMutation = useUpsertCargaOperacionBanco();
  const avanzarMutation = useAvanzarCargaOperacionBanco();

  const controlesDatosOperacionQuery = useControlesDatosOperacion();
  const controlesAntecedenteCompradorQuery = useControlesAntecedenteComprador();
  const controlesAntecedenteCreditoQuery = useControlesAntecedenteCredito();
  const controlesAntecedenteVendedorQuery = useControlesAntecedenteVendedor();
  const controlesDatosComercialQuery = useControlesDatosComercial();

  const catalogos: ControlesDatosOperacion = useMemo(() => {
    if (!controlesDatosOperacionQuery.data?.status) {
      return EMPTY_CONTROLES_DATOS_OPERACION;
    }

    return (
      controlesDatosOperacionQuery.data.detail ??
      EMPTY_CONTROLES_DATOS_OPERACION
    );
  }, [controlesDatosOperacionQuery.data]);

  const controlesComprador: ControlesAntecedenteComprador = useMemo(() => {
    if (!controlesAntecedenteCompradorQuery.data?.status) {
      return EMPTY_CONTROLES_ANTECEDENTE_COMPRADOR;
    }

    return (
      controlesAntecedenteCompradorQuery.data.detail ??
      EMPTY_CONTROLES_ANTECEDENTE_COMPRADOR
    );
  }, [controlesAntecedenteCompradorQuery.data]);

  const controlesVendedor: ControlesAntecedenteVendedor = useMemo(() => {
    if (!controlesAntecedenteVendedorQuery.data?.status) {
      return EMPTY_CONTROLES_ANTECEDENTE_VENDEDOR;
    }

    return (
      controlesAntecedenteVendedorQuery.data.detail ??
      EMPTY_CONTROLES_ANTECEDENTE_VENDEDOR
    );
  }, [controlesAntecedenteVendedorQuery.data]);

  const controlesCredito: ControlesAntecedenteCredito = useMemo(() => {
    if (!controlesAntecedenteCreditoQuery.data?.status) {
      return EMPTY_CONTROLES_ANTECEDENTE_CREDITO;
    }

    return (
      controlesAntecedenteCreditoQuery.data.detail ??
      EMPTY_CONTROLES_ANTECEDENTE_CREDITO
    );
  }, [controlesAntecedenteCreditoQuery.data]);

  const controlesComercial: ControlesDatosComercial = useMemo(() => {
    if (!controlesDatosComercialQuery.data?.status) {
      return EMPTY_CONTROLES_DATOS_COMERCIAL;
    }

    return (
      controlesDatosComercialQuery.data.detail ??
      EMPTY_CONTROLES_DATOS_COMERCIAL
    );
  }, [controlesDatosComercialQuery.data]);

  const isLoadingCatalogos = controlesDatosOperacionQuery.isLoading;
  const isLoadingControlesComprador =
    controlesAntecedenteCompradorQuery.isLoading;
  const isLoadingControlesVendedor =
    controlesAntecedenteVendedorQuery.isLoading;
  const isLoadingControlesCredito =
    controlesAntecedenteCreditoQuery.isLoading;
  const isLoadingControlesComercial =
    controlesDatosComercialQuery.isLoading;

  useEffect(() => {
    if (currentExpedienteRef.current !== id_expediente) {
      currentExpedienteRef.current = id_expediente;
      hasHydratedRef.current = false;
      setForm(buildInitialState(id_expediente));
      setIsDisabled(true);
      setCanAdvance(false);
      setErrorMessage('');
      setSuccessMessage('');
    }
  }, [id_expediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (!id_expediente || id_expediente <= 0) {
      setForm(buildInitialState(0));
      setIsDisabled(false);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (data?.status && data.detail) {
      setForm(normalizeCargaOperacionBanco(data.detail, id_expediente));
      setIsDisabled(Number(data.detail.id_carga_operacion_banco) > 0);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (data) {
      setForm(buildInitialState(id_expediente));
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
    }
  }, [data, id_expediente]);

  const updateDatosOperacionField = <
    K extends keyof CargaOperacionBancoDatosOperacion,
  >(
    field: K,
    value: CargaOperacionBancoDatosOperacion[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      datos_operacion: {
        ...(prev.datos_operacion ?? buildDatosOperacionInitialState(prev.id_expediente)),
        [field]: value,
      },
    }));
  };

  const updateAntecedenteCreditoField = <
    K extends keyof CargaOperacionBancoAntecedenteCredito,
  >(
    field: K,
    value: CargaOperacionBancoAntecedenteCredito[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      antecedente_credito: {
        ...(prev.antecedente_credito ??
          buildAntecedenteCreditoInitialState(
            prev.id_expediente,
            prev.id_carga_operacion_banco,
          )),
        [field]: value,
      },
    }));
  };

  const updateDatosComercialField = <
    K extends keyof CargaOperacionBancoDatosComercial,
  >(
    field: K,
    value: CargaOperacionBancoDatosComercial[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      datos_comercial: {
        ...(prev.datos_comercial ??
          buildDatosComercialInitialState(
            prev.id_expediente,
            prev.id_carga_operacion_banco,
          )),
        [field]: value,
      },
    }));
  };

  const updateAntecedentesComprador = (
    antecedentes_comprador: CargaOperacionBancoAntecedenteComprador[],
  ) => {
    setForm((prev) => ({
      ...prev,
      antecedentes_comprador: normalizeAntecedentesComprador(
        antecedentes_comprador,
        prev.id_expediente,
        prev.id_carga_operacion_banco,
      ),
    }));
  };

  const updateAntecedentesVendedor = (
    antecedentes_vendedor: CargaOperacionBancoAntecedenteVendedor[],
  ) => {
    setForm((prev) => ({
      ...prev,
      antecedentes_vendedor: normalizeAntecedentesVendedor(
        antecedentes_vendedor,
        prev.id_expediente,
        prev.id_carga_operacion_banco,
      ),
    }));
  };

  const handleEditar = () => {
    setErrorMessage('');
    setSuccessMessage('');
    setIsDisabled(false);
    setCanAdvance(false);
  };

  const validateForm = () => {
    if (id_expediente > 0 && (!form.id_expediente || form.id_expediente <= 0)) {
      return 'No existe un id_expediente válido.';
    }

    const datosOperacion =
      form.datos_operacion ?? buildDatosOperacionInitialState(form.id_expediente);

    if (!datosOperacion.nro_mutuo) return 'Debe ingresar N° Mutuo.';
    if (!datosOperacion.tipo_operacion) return 'Debe seleccionar Tipo Operación.';
    if (!datosOperacion.nro_registro) return 'Debe ingresar N° Registro.';
    if (!datosOperacion.ult_clasif_al?.trim()) {
      return 'Debe ingresar Ult. Clasif. al.';
    }
    if (!datosOperacion.segmento) return 'Debe seleccionar Segmento.';
    if (!datosOperacion.canal_venta) return 'Debe seleccionar Canal de Venta.';
    if (!datosOperacion.nro_op_cartera) return 'Debe ingresar N° Op. Cartera.';
    if (!datosOperacion.modelo_operacion) {
      return 'Debe seleccionar Modelo de Operación.';
    }
    if (!datosOperacion.tipo_carpeta) return 'Debe seleccionar Tipo Carpeta.';
    if (!datosOperacion.propietario?.trim()) return 'Debe ingresar Propietario.';
    if (!datosOperacion.inmobiliaria) return 'Debe seleccionar Inmobiliaria.';
    if (!datosOperacion.glosa_producto) return 'Debe seleccionar Glosa Producto.';
    if (!datosOperacion.codigo_producto_comercial) {
      return 'Debe seleccionar Código Producto Comercial.';
    }

    const compradoresActivos =
      form.antecedentes_comprador?.filter((comprador) => comprador.row_status !== false) ??
      [];

    if (compradoresActivos.length === 0) {
      return 'Debe agregar al menos un comprador.';
    }

    const compradorInvalido = compradoresActivos.find((comprador) => {
      if (!comprador.rut?.trim()) return true;
      if (!comprador.tipo_comprador) return true;

      const tipo = comprador.tipo_comprador.toString().toUpperCase();

      if (tipo === 'JURIDICO' || tipo === 'JURÍDICO' || tipo === '02') {
        return !comprador.razon_social?.trim();
      }

      return !comprador.nombres?.trim() || !comprador.apellido_paterno?.trim();
    });

    if (compradorInvalido) {
      return 'Hay compradores con información obligatoria pendiente.';
    }

    const vendedoresActivos =
      form.antecedentes_vendedor?.filter((vendedor) => vendedor.row_status !== false) ?? [];

    const vendedorInvalido = vendedoresActivos.some((vendedor) => {
      if (!vendedor.rut?.trim()) return true;
      if (!vendedor.tipo_vendedor) return true;

      const tipo = vendedor.tipo_vendedor?.toString().toUpperCase();

      if (tipo === 'JURIDICO' || tipo === 'JURÍDICO' || tipo === '02') {
        return !vendedor.razon_social?.trim();
      }

      return !vendedor.nombres?.trim() || !vendedor.apellido_paterno?.trim();
    });

    if (vendedorInvalido) {
      return 'Hay vendedores con información obligatoria pendiente.';
    }

    const antecedenteCredito =
      form.antecedente_credito ??
      buildAntecedenteCreditoInitialState(
        form.id_expediente,
        form.id_carga_operacion_banco,
      );

    if (!antecedenteCredito.tipo_prestamo) {
      return 'Debe seleccionar Tipo Préstamo.';
    }
    if (!antecedenteCredito.destino_credito) {
      return 'Debe seleccionar Destino Crédito.';
    }
    if (!antecedenteCredito.tipo_tasa) {
      return 'Debe seleccionar Tipo Tasa.';
    }
    if (!antecedenteCredito.moneda) {
      return 'Debe seleccionar Moneda.';
    }
    if (!antecedenteCredito.tipo_financiamiento) {
      return 'Debe seleccionar Tipo Financiamiento.';
    }

    const datosComercial =
      form.datos_comercial ??
      buildDatosComercialInitialState(
        form.id_expediente,
        form.id_carga_operacion_banco,
      );

    if (!datosComercial.tipo_hipoteca) {
      return 'Debe seleccionar Tipo Hipoteca.';
    }

    return '';
  };

  const buildPayload = () => {
    const expedienteId = Number(form.id_expediente || id_expediente || 0);
    const idCargaOperacionBanco = Number(form.id_carga_operacion_banco ?? 0);

    return normalizeCargaOperacionBanco(
      {
        ...form,
        id_expediente: expedienteId,
        datos_operacion: normalizeDatosOperacion(
          form.datos_operacion,
          expedienteId,
          idCargaOperacionBanco,
        ),
        antecedentes_comprador: normalizeAntecedentesComprador(
          form.antecedentes_comprador,
          expedienteId,
          idCargaOperacionBanco,
        ),
        antecedentes_vendedor: normalizeAntecedentesVendedor(
          form.antecedentes_vendedor,
          expedienteId,
          idCargaOperacionBanco,
        ),
        antecedente_credito: normalizeAntecedenteCredito(
          form.antecedente_credito,
          expedienteId,
          idCargaOperacionBanco,
        ),
        datos_comercial: normalizeDatosComercial(
          form.datos_comercial,
          expedienteId,
          idCargaOperacionBanco,
        ),
      },
      expedienteId,
    );
  };

  const handleGuardar = async () => {
    setErrorMessage('');
    setSuccessMessage('');

    const validationMessage = validateForm();

    if (validationMessage) {
      toast.current?.show({
        severity: 'warn',
        summary: 'Validación',
        detail: validationMessage,
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);

      const payload = buildPayload();
      const guardarKey = crypto.randomUUID();

      const response = await saveMutation.mutateAsync({
        payload,
        idempotencyKey: guardarKey,
      });

      if (response.status) {
        const savedEntity = normalizeCargaOperacionBanco(
          response.detail ?? payload,
          payload.id_expediente,
        );

        setForm(savedEntity);
        setIsDisabled(true);
        setCanAdvance(true);
        hasHydratedRef.current = true;

        toast.current?.show({
          severity: 'success',
          summary: 'Éxito',
          detail: 'Carga Operación Banco guardada correctamente.',
          life: 3000,
        });
      } else {
        toast.current?.show({
          severity: 'warn',
          summary: 'Atención',
          detail: response.message || 'No se pudo guardar.',
          life: 3000,
        });
      }
    } catch (error) {
      console.error('ERROR GUARDAR CARGA OPERACION BANCO', error);

      toast.current?.show({
        severity: 'error',
        summary: 'Error',
        detail: 'Ocurrió un error al guardar.',
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleAvanzar = async () => {
    // Dedupe guard: evitar re-despachar si ya hay una petición en vuelo.
    if (saveMutation.isPending || avanzarMutation.isPending) {
      return;
    }

    setErrorMessage('');
    setSuccessMessage('');

    const validationMessage = validateForm();

    if (validationMessage) {
      toast.current?.show({
        severity: 'warn',
        summary: 'Validación',
        detail: validationMessage,
        life: 3000,
      });
      return;
    }

    // Generar clave de idempotencia una sola vez por intento de avance.
    // Se reutiliza en save + avanzar para que el backend pueda detectar reintentos.
    if (idemKeyRef.current === null) {
      idemKeyRef.current = crypto.randomUUID();
    }
    const currentIdemKey = idemKeyRef.current;

    try {
      setIsBusy(true);

      const payload = buildPayload();

      const saveResponse = await saveMutation.mutateAsync({
        payload,
        idempotencyKey: currentIdemKey,
      });

      if (!saveResponse.status) {
        toast.current?.show({
          severity: 'warn',
          summary: 'Atención',
          detail: saveResponse.message || 'No se pudo guardar antes de avanzar.',
          life: 3000,
        });
        return;
      }

      const savedEntity = normalizeCargaOperacionBanco(
        saveResponse.detail ?? payload,
        payload.id_expediente,
      );

      setForm(savedEntity);

      const expedienteId = Number(savedEntity.id_expediente ?? 0);

      if (!expedienteId || expedienteId <= 0) {
        toast.current?.show({
          severity: 'warn',
          summary: 'Validación',
          detail: 'No existe un id_expediente válido para avanzar.',
          life: 3000,
        });
        return;
      }

      const response = await avanzarMutation.mutateAsync(expedienteId);

      if (response.status) {
        // Resetear la clave para habilitar un nuevo intento fresco si el usuario
        // inicia otra operación desde la misma sesión de pantalla.
        idemKeyRef.current = null;

        toast.current?.show({
          severity: 'success',
          summary: 'Éxito',
          detail: 'Actividad avanzada correctamente.',
          life: 2000,
        });

        navigate('/home/bandeja');
      } else {
        toast.current?.show({
          severity: 'warn',
          summary: 'Atención',
          detail: response.message || 'No se pudo avanzar la actividad.',
          life: 3000,
        });
      }
    } catch (error) {
      console.error('ERROR AVANZAR CARGA OPERACION BANCO', error);

      toast.current?.show({
        severity: 'error',
        summary: 'Error',
        detail: 'Ocurrió un error al avanzar.',
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleSalir = () => {
    navigate('/home/bandeja');
  };

  const canEditAntecedentesComprador = !isDisabled && !isBusy;
  const canEditAntecedentesVendedor = !isDisabled && !isBusy;

  return (
    <>
      <Toast ref={toast} />

      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Carga Operación Banco
      </h2>

      <Accordion activeIndex={[0, 2]} multiple>
        <AccordionTab
          disabled={!id_expediente || id_expediente <= 0}
          header="Información del Expediente"
        >
          <EncabezadoActividad
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            activityID={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab
          header="Funciones Transversales"
          disabled={!id_expediente || id_expediente <= 0}
        >
          <FuncionesTransversales
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            idActividad={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header="Carga Operación Banco">
          <Card className="w-full shadow-md card-presto-form mb-6">
            {isLoading && id_expediente > 0 && (
              <div className="mb-4 text-sm text-blue-600">
                Cargando información...
              </div>
            )}

            {errorMessage && (
              <div className="mb-4 rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                {errorMessage}
              </div>
            )}

            {successMessage && (
              <div className="mb-4 rounded-md border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
                {successMessage}
              </div>
            )}

            <div className="mb-5">
              <h3 className="text-lg font-semibold text-gray-800">
                Sección: Datos de la Operación
              </h3>
            </div>

            <DatosOperacionSection
              value={
                form.datos_operacion ??
                buildDatosOperacionInitialState(form.id_expediente)
              }
              disabled={isDisabled || isBusy}
              catalogos={catalogos}
              loadingCatalogos={isLoadingCatalogos}
              onChange={updateDatosOperacionField}
            />

            <div className="my-8 border-t border-gray-200" />

            <AntecedentesCompradorSection
              key={`antecedentes-comprador-${canEditAntecedentesComprador ? 'edit' : 'view'}`}
              value={form.antecedentes_comprador ?? []}
              idExpediente={Number(form.id_expediente || id_expediente || 0)}
              idCargaOperacionBanco={Number(form.id_carga_operacion_banco ?? 0)}
              disabled={isDisabled || isBusy}
              canEdit={canEditAntecedentesComprador}
              controles={controlesComprador}
              loadingControles={isLoadingControlesComprador}
              onChange={updateAntecedentesComprador}
              onWarn={(message) =>
                toast.current?.show({
                  severity: 'warn',
                  summary: 'Validación',
                  detail: message,
                  life: 3000,
                })
              }
            />

            <div className="my-8 border-t border-gray-200" />

            <AntecedentesVendedorSection
              key={`antecedentes-vendedor-${canEditAntecedentesVendedor ? 'edit' : 'view'}`}
              value={form.antecedentes_vendedor ?? []}
              idExpediente={Number(form.id_expediente || id_expediente || 0)}
              idCargaOperacionBanco={Number(form.id_carga_operacion_banco ?? 0)}
              disabled={isDisabled || isBusy}
              canEdit={canEditAntecedentesVendedor}
              controles={controlesVendedor}
              loadingControles={isLoadingControlesVendedor}
              onChange={updateAntecedentesVendedor}
              onWarn={(message) =>
                toast.current?.show({
                  severity: 'warn',
                  summary: 'Validación',
                  detail: message,
                  life: 3000,
                })
              }
            />


            <div className="my-8 border-t border-gray-200" />

            <div className="mb-5">
              <h3 className="text-lg font-semibold text-gray-800">
                Sección: Antecedentes del Crédito
              </h3>
            </div>

            <AntecedenteCreditoSection
              value={
                form.antecedente_credito ??
                buildAntecedenteCreditoInitialState(
                  form.id_expediente,
                  form.id_carga_operacion_banco,
                )
              }
              disabled={isDisabled || isBusy}
              controles={controlesCredito}
              loadingControles={isLoadingControlesCredito}
              onChange={updateAntecedenteCreditoField}
            />

            <div className="my-8 border-t border-gray-200" />

            <div className="mb-5">
              <h3 className="text-lg font-semibold text-gray-800">
                Sección: Datos Comercial
              </h3>
            </div>

            <DatosComercialSection
              value={
                form.datos_comercial ??
                buildDatosComercialInitialState(
                  form.id_expediente,
                  form.id_carga_operacion_banco,
                )
              }
              disabled={isDisabled || isBusy}
              controles={controlesComercial}
              loadingControles={isLoadingControlesComercial}
              onChange={updateDatosComercialField}
            />

            <div className="form-actions">
              <Button
                type="button"
                label="Editar"
                icon="pi pi-pencil"
                severity="info"
                outlined
                onClick={handleEditar}
                disabled={isBusy || !isDisabled}
                className="btn-responsive"
              />

              <Button
                type="button"
                label={saveMutation.isPending ? 'Guardando...' : 'Guardar'}
                icon="pi pi-save"
                severity="success"
                onClick={handleGuardar}
                disabled={isBusy || isDisabled}
                className="btn-responsive"
              />

              <Button
                type="button"
                label={saveMutation.isPending || avanzarMutation.isPending ? 'Procesando...' : 'Avanzar'}
                icon="pi pi-arrow-right"
                severity="warning"
                onClick={handleAvanzar}
                disabled={
                  isBusy ||
                  saveMutation.isPending ||
                  avanzarMutation.isPending ||
                  (!canAdvance && !form.id_carga_operacion_banco)
                }
                className="btn-responsive"
              />

              <Button
                type="button"
                label="Salir"
                icon="pi pi-sign-out"
                severity="secondary"
                outlined
                onClick={handleSalir}
                disabled={isBusy}
                className="btn-responsive"
              />
            </div>
          </Card>
        </AccordionTab>
      </Accordion>
    </>
  );
}
