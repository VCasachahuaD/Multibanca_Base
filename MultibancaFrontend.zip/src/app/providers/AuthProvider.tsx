import { createContext, ReactNode, useContext, useMemo, useState } from "react";
import { authStorage } from "@/core/auth/authStorage";
import type { AuthUser } from "@/features/auth/models/AuthUser";

interface AuthContextType {
  token: string | null;
  user: AuthUser | null;
  isAuthenticated: boolean;
  login: (token: string, user?: AuthUser) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(authStorage.getToken());
  const [user, setUser] = useState<AuthUser | null>(authStorage.getUser());

  const value = useMemo(
    () => ({
      token,
      user,
      isAuthenticated: !!token,
      login: (newToken: string, user?: AuthUser) => {
        authStorage.setToken(newToken);
        if (user) {
          authStorage.setUser(user);
          setUser(user);
        }
        setToken(newToken);
      },
      logout: () => {
        authStorage.clear();
        setToken(null);
        setUser(null);
      },
    }),
    [token]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth debe usarse dentro de AuthProvider");
  }

  return context;
}