﻿using Data.Extensions.Repository;
using Data.Repository.Interfaces.Repositories.Common;
using Framework.WorkFlow.Common.DTO;
using Microsoft.EntityFrameworkCore;
using Multibanca.DTO.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Repository.Implementations.Repositories.Common
{
    public class CommonRepository : ICommonRepository
    {
        private readonly MultibancaDBContext MultibancaDBContext;

        public CommonRepository(MultibancaDBContext _multibancaDBContext)
        {
            MultibancaDBContext = _multibancaDBContext;
        }

        public async Task<FolioDTO> CapturarDatosFolio(long id_expediente, string id_actividad)
        {
            var data = new
            {
                p_id_expediente = id_expediente,
                p_id_actividad = id_actividad
            };

            DbConnection connection = this.MultibancaDBContext.Database.GetDbConnection();
            await using var command = connection.CreateCommand();

            try
            {
                if (connection.State != ConnectionState.Open)
                    await connection.OpenAsync();

                command.CommandText = "SELECT * FROM sp_get_info_folio(@p_id_expediente, @p_id_actividad);";
                command.CommandType = CommandType.Text;
                command.Parameters.ToArray(data);

                await using var reader = await command.ExecuteReaderAsync();
                return reader.MapToDomain<FolioDTO>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al capturar datos del folio para el expediente {id_expediente}.", ex);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    await connection.CloseAsync();
            }
        }

        public async Task<AssignActivityDTO> AsignarActividad(long id_expediente, string id_performer)
        {
            var data = new
            {
                p_id_expediente = id_expediente,
                p_id_performer = id_performer
            };

            DbConnection connection = this.MultibancaDBContext.Database.GetDbConnection();
            await using var command = connection.CreateCommand();

            try
            {
                if (connection.State != ConnectionState.Open)
                    await connection.OpenAsync();

                command.CommandText = "SELECT * FROM usp_select_actividad_asignar(@p_id_expediente, @p_id_performer);";
                command.CommandType = CommandType.Text;
                command.Parameters.ToArray(data);

                await using var reader = await command.ExecuteReaderAsync();
                return reader.MapToDomain<AssignActivityDTO>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al obtener actividad asignada para expediente {id_expediente}.", ex);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    await connection.CloseAsync();
            }
        }

        public async Task<List<ControlBaseDTO>> GetCatalogoByType(string tipo)
        {
            object data = new
            {
                p_type = tipo
            };

            List<ControlBaseDTO> listControlBaseDTO = new List<ControlBaseDTO>();

            using (DbCommand command = MultibancaDBContext.Database.GetDbConnection().CreateCommand())
            {
                try
                {
                    await MultibancaDBContext.Database.OpenConnectionAsync();

                    command.CommandText = @"
                SELECT *
                FROM usp_get_catalogo_by_tipo(
                    @p_type
                );
            ";

                    command.CommandType = CommandType.Text;
                    command.Parameters.ToArray<object>(data);

                    DbDataReader reader = await command.ExecuteReaderAsync();

                    listControlBaseDTO = reader.MapToListDomain<ControlBaseDTO>();
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message, ex);
                }
                finally
                {
                    await MultibancaDBContext.Database.CloseConnectionAsync();
                }

                return listControlBaseDTO;
            }
        }
    }
}
