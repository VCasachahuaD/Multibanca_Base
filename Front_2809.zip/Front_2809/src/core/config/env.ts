const normalize_api_base_url = (value: unknown): string => {
  if (typeof value !== 'string') {
    return '';
  }

  const trimmed_value = value.trim();

  if (!trimmed_value) {
    return '';
  }

  return trimmed_value.replace(/\/+$/, '');
};

export const env = {
  apiUrl: normalize_api_base_url(import.meta.env.VITE_API_BASE_URL),
};
