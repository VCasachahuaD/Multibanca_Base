import { addLocale, locale } from 'primereact/api';

/**
 * Locale español para TODOS los componentes de PrimeReact (calendarios,
 * tablas, filtros, etc.).
 *
 * `addLocale` registra el idioma (se fusiona con el inglés por defecto) y
 * `locale('es')` lo deja como idioma activo de la aplicación. Se llama una
 * sola vez, importando este módulo desde `main.tsx` antes de renderizar.
 *
 * Nota: <Calendar dateFormat="dd/mm/yy" /> ya se pasa explícitamente en las
 * pantallas; acá se define igual como formato por defecto.
 */
addLocale('es', {
  firstDayOfWeek: 1,
  dayNames: [
    'domingo',
    'lunes',
    'martes',
    'miércoles',
    'jueves',
    'viernes',
    'sábado',
  ],
  dayNamesShort: ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'],
  dayNamesMin: ['D', 'L', 'M', 'M', 'J', 'V', 'S'],
  monthNames: [
    'enero',
    'febrero',
    'marzo',
    'abril',
    'mayo',
    'junio',
    'julio',
    'agosto',
    'septiembre',
    'octubre',
    'noviembre',
    'diciembre',
  ],
  monthNamesShort: [
    'ene',
    'feb',
    'mar',
    'abr',
    'may',
    'jun',
    'jul',
    'ago',
    'sep',
    'oct',
    'nov',
    'dic',
  ],
  today: 'Hoy',
  clear: 'Limpiar',
  weekHeader: 'Sem',
  dateFormat: 'dd/mm/yy',
  chooseDate: 'Seleccionar fecha',
  chooseMonth: 'Seleccionar mes',
  chooseYear: 'Seleccionar año',

  // Filtros y mensajes de tablas (DataTable)
  emptyMessage: 'Sin resultados',
  startsWith: 'Comienza con',
  contains: 'Contiene',
  notContains: 'No contiene',
  endsWith: 'Termina con',
  equals: 'Igual a',
  notEquals: 'Distinto de',
  noFilter: 'Sin filtro',
  lt: 'Menor que',
  lte: 'Menor o igual que',
  gt: 'Mayor que',
  gte: 'Mayor o igual que',
  dateIs: 'Fecha igual a',
  dateIsNot: 'Fecha distinta de',
  dateBefore: 'Fecha anterior a',
  dateAfter: 'Fecha posterior a',
  matchAll: 'Cumplir todas',
  matchAny: 'Cumplir alguna',
  addRule: 'Agregar regla',
  removeRule: 'Quitar regla',

  // Acciones genéricas
  accept: 'Sí',
  reject: 'No',
  choose: 'Elegir',
  upload: 'Subir',
  cancel: 'Cancelar',
});

locale('es');
