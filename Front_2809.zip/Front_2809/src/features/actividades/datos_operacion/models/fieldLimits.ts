/**
 * Límites de longitud (maxLength) de los inputs de Datos de Operación (5.4).
 *
 * MAPA POR ACTIVIDAD: tamaños de columna declarados en los EntityConfig del backend:
 *  - 5.4            → Data.Repository.Implementations/EntityConfig/Multibanca/DatosOperacion/*.cs
 *  - 3.1 (los campos que la grilla de personas proyecta desde el antecedente) →
 *    .../EntityConfig/Multibanca/CargaOperacionBanco/carga_operacion_banco_antecedente_*_entity_config.cs
 *
 * Los números de NEGOCIO (RUT, teléfonos, email) NO se definen acá: vienen de
 * `@/shared/utils/fieldLimits` para que sean iguales en todas las actividades.
 *
 * REGLAS
 *  - Ningún componente lleva números: usar `limitOf('campo')` (comprador/vendedor)
 *    o `fiadorLimitOf('campo')` (fiador/garante).
 *  - La clave es el nombre snake_case del campo, igual al `data-field` del JSX.
 *  - Para cambiar un límite basta editar UNA línea de este archivo.
 *  - Los Dropdown (catálogos) y Calendar no tienen límite de caracteres.
 *
 * NOTA: para los campos SIN regla de negocio (texto libre) se aplica el ancho de la
 * columna como techo, para no bloquear un dato que el backend ya acepte.
 *
 * EXCEPCIÓN DOCUMENTADA: `telefono_comercial` y `telefono_fijo` no usan `limitOf()`
 * porque sus inputs son COMPUESTOS (el código de área se muestra aparte del número) y
 * el maxLength aplica a los dígitos, no al total almacenado.
 */

import { EMAIL_MAX_LENGTH } from '@/shared/utils/chileanValidators';
import { RUT_MAX, TELEFONO_MOVIL_MAX } from '@/shared/utils/fieldLimits';

/** Campos que la grilla de comprador/vendedor proyecta desde el antecedente de 3.1 */
export const ANTECEDENTE_LIMITS = {
  rut: RUT_MAX, // varchar(12) - regla de negocio: RUT
  razon_social: 250, // varchar(250)
  nombres: 150, // varchar(150)
  apellido_paterno: 100, // varchar(100)
  apellido_materno: 100, // varchar(100)
  direccion: 250, // varchar(250)
  telefono: TELEFONO_MOVIL_MAX, // varchar(20) - regla de negocio: celular
  email: EMAIL_MAX_LENGTH, // tope de negocio (columna: varchar(150))
  profesion: 150, // varchar(150)
} as const;

/** Campos propios de 5.4 en `datos_operacion_comprador` / `datos_operacion_vendedor` */
export const PERSONA_54_LIMITS = {
  direccion_env_esc: 250, // varchar(250)
  direccion_env_div: 250, // varchar(250)
  telefono_movil: TELEFONO_MOVIL_MAX, // varchar(50) - regla de negocio: celular
  email2: EMAIL_MAX_LENGTH, // tope de negocio (columna: varchar(150))
} as const;

/** Campos propios de 5.4 en `datos_operacion_fiador_garante` */
export const FIADOR_LIMITS = {
  // regla de negocio: RUT con puntos (12.345.678-9). OJO: la columna es varchar(20)
  // en datos_operacion_fiador_garante, pero un RUT nunca llega a 20; se usa 12 para
  // quedar igual que el antecedente de 3.1 y que el resto de las pantallas.
  rut: RUT_MAX,
  nombres: 150, // varchar(150)
  apellido_paterno: 100, // varchar(100)
  apellido_materno: 100, // varchar(100)
  direccion: 250, // varchar(250)
  profesion: 150, // varchar(150)
  // telefono_fijo: input compuesto, limita los dígitos del número (no lleva entrada acá)
  telefono_movil: TELEFONO_MOVIL_MAX, // varchar(50) - regla de negocio: celular
  email: EMAIL_MAX_LENGTH, // tope de negocio (columna: varchar(150))
} as const;

/** Diálogo de personas de `DatosOperacionPersonaGrid` (comprador y vendedor). */
export const PERSONA_FIELD_LIMITS: Record<string, number> = {
  ...ANTECEDENTE_LIMITS,
  ...PERSONA_54_LIMITS,
};

/** Diálogo de `FiadorGaranteSection`. */
export const FIADOR_FIELD_LIMITS: Record<string, number> = {
  ...FIADOR_LIMITS,
};

/** maxLength del campo indicado en el diálogo de comprador/vendedor. */
export function limitOf(field: string): number | undefined {
  return PERSONA_FIELD_LIMITS[field];
}

/** maxLength del campo indicado en el diálogo de fiador/garante. */
export function fiadorLimitOf(field: string): number | undefined {
  return FIADOR_FIELD_LIMITS[field];
}
