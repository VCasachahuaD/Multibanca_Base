import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import { TabPanel, TabView } from 'primereact/tabview';
import { Toast } from 'primereact/toast';

import EncabezadoActividad from '@/features/encabezado/pages/EncabezadoActividad';
import FuncionesTransversales from '@/features/funciones_transversales/pages/FuncionesTransversales';
import RequiredMark from '@/shared/components/RequiredMark';
import BancoAcreedorSection from '../components/BancoAcreedorSection';
import DatosCreditoSection from '../components/DatosCreditoSection';
import DatosOperacionPersonaGrid, {
  getMissingPersonaField,
  getPersonaRutErrorMessage,
} from '../components/DatosOperacionPersonaGrid';
import FiadorGaranteSection, { getTelefonoFijoDigitos } from '../components/FiadorGaranteSection';
import PropiedadSection from '../components/PropiedadSection';
import { useAvanzarDatosOperacion } from '../hooks/useAvanzarDatosOperacion';
import { useControlesBancoAcreedor } from '../hooks/useControlesBancoAcreedor';
import { useControlesComprador } from '../hooks/useControlesComprador';
import { useControlesDatosCredito } from '../hooks/useControlesDatosCredito';
import { useControlesFiadorGarante } from '../hooks/useControlesFiadorGarante';
import { useControlesPropiedad } from '../hooks/useControlesPropiedad';
import { useControlesVendedor } from '../hooks/useControlesVendedor';
import {
  EMPTY_CONTROLES_BANCO_ACREEDOR,
  EMPTY_CONTROLES_COMPRADOR,
  EMPTY_CONTROLES_DATOS_CREDITO,
  EMPTY_CONTROLES_FIADOR_GARANTE,
  EMPTY_CONTROLES_PROPIEDAD,
  EMPTY_CONTROLES_VENDEDOR,
} from '../models/catalogo';
import { useDatosOperacion } from '../hooks/useDatosOperacion';
import { useUpsertDatosOperacion } from '../hooks/useUpsertDatosOperacion';
import { Checkbox } from 'primereact/checkbox';
import { InputTextarea } from 'primereact/inputtextarea';
import {
  buildBancoAcreedorEmpty,
  buildDatosCreditoEmpty,
  buildDatosOperacionEmpty,
  buildPropiedadEmpty,
  type DatosOperacion,
  type DatosOperacionBancoAcreedor,
  type DatosOperacionComprador,
  type DatosOperacionDatosCredito,
  type DatosOperacionFiadorGarante,
  type DatosOperacionPropiedad,
  type DatosOperacionVendedor,
} from '../models/datos_operacion';

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
import { describeRutError, normalizeRut } from '@/shared/utils/rut';
import { focusFieldByKey } from '../utils/fieldFocus';
/**
 * Actividad 5.4 Datos de Operación.
 * Debe coincidir con Constants.Actividades.DatosOperacion en backend/workflow.
 */
const ACTIVITY_ID = '_LCDxkE_wEeWmubI992vDXg';

const isEmptyValue = (value: unknown): boolean =>
  value === null || value === undefined || (typeof value === 'string' && value.trim() === '');

const isMissingBoolean = (value?: boolean | null): boolean =>
  value === null || value === undefined;

type ValidationResult = {
  isValid: boolean;
  tabIndex: number;
  message: string;
  /** Llave snake_case del campo faltante para poder enfocarlo. */
  fieldKey?: string | null;
};

const validResult: ValidationResult = {
  isValid: true,
  tabIndex: 0,
  message: '',
  fieldKey: null,
};


type Props = {
  idExpediente?: number;
  idActividad?: string;
};

export default function DatosOperacionPage({
  idExpediente: idExpedienteProp,
  idActividad = ACTIVITY_ID,
}: Props) {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useRef<Toast>(null);
  const { id_expediente: idParam } = useParams();
  const { fromTracking = false } = location.state || {};

  const idExpediente = Number(idExpedienteProp ?? idParam ?? 0);
  const hasValidExpediente = idExpediente > 0;

  const [activeTabIndex, setActiveTabIndex] = useState(0);
  const [isDisabled, setIsDisabled] = useState(true);
  const [canAdvance, setCanAdvance] = useState(false);
  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef(idExpediente);
  const [form, setForm] = useState<DatosOperacion>(() =>
    buildDatosOperacionEmpty(idExpediente),
  );

  const datosOperacionQuery = useDatosOperacion(idExpediente);
  const saveMutation = useUpsertDatosOperacion();
  const avanzarMutation = useAvanzarDatosOperacion();

  const controlesDatosCreditoQuery = useControlesDatosCredito(hasValidExpediente);
  const controlesCompradorQuery = useControlesComprador(hasValidExpediente);
  const controlesVendedorQuery = useControlesVendedor(hasValidExpediente);
  const controlesFiadorGaranteQuery = useControlesFiadorGarante(hasValidExpediente);
  const controlesBancoAcreedorQuery = useControlesBancoAcreedor(hasValidExpediente);
  const controlesPropiedadQuery = useControlesPropiedad(hasValidExpediente);

  const controlesDatosCredito = controlesDatosCreditoQuery.data?.status
    ? controlesDatosCreditoQuery.data.detail ?? EMPTY_CONTROLES_DATOS_CREDITO
    : EMPTY_CONTROLES_DATOS_CREDITO;

  const controlesComprador = controlesCompradorQuery.data?.status
    ? controlesCompradorQuery.data.detail ?? EMPTY_CONTROLES_COMPRADOR
    : EMPTY_CONTROLES_COMPRADOR;

  const controlesVendedor = controlesVendedorQuery.data?.status
    ? controlesVendedorQuery.data.detail ?? EMPTY_CONTROLES_VENDEDOR
    : EMPTY_CONTROLES_VENDEDOR;

  const controlesCompradorConTipoPersona = useMemo(
    () => ({
      ...controlesComprador,
      tipo_vendedor: controlesVendedor.tipo_vendedor,
    }),
    [controlesComprador, controlesVendedor.tipo_vendedor],
  );

  const controlesFiadorGarante = controlesFiadorGaranteQuery.data?.status
    ? controlesFiadorGaranteQuery.data.detail ?? EMPTY_CONTROLES_FIADOR_GARANTE
    : EMPTY_CONTROLES_FIADOR_GARANTE;

  const controlesBancoAcreedor = controlesBancoAcreedorQuery.data?.status
    ? controlesBancoAcreedorQuery.data.detail ?? EMPTY_CONTROLES_BANCO_ACREEDOR
    : EMPTY_CONTROLES_BANCO_ACREEDOR;

  const controlesPropiedad = controlesPropiedadQuery.data?.status
    ? controlesPropiedadQuery.data.detail ?? EMPTY_CONTROLES_PROPIEDAD
    : EMPTY_CONTROLES_PROPIEDAD;

  const isLoadingControlesDatosCredito = controlesDatosCreditoQuery.isLoading;
  const isLoadingControlesComprador = controlesCompradorQuery.isLoading;
  const isLoadingControlesVendedor = controlesVendedorQuery.isLoading;
  const isLoadingControlesFiadorGarante = controlesFiadorGaranteQuery.isLoading;
  const isLoadingControlesBancoAcreedor = controlesBancoAcreedorQuery.isLoading;
  const isLoadingControlesPropiedad = controlesPropiedadQuery.isLoading;

  const isLoading = datosOperacionQuery.isLoading;
  const isBusy = saveMutation.isPending || avanzarMutation.isPending;
  const canEditSections = !isDisabled && !isBusy;

  const normalizeForm = (data: DatosOperacion | null | undefined): DatosOperacion => {
    const cabecera = data ?? buildDatosOperacionEmpty(idExpediente);
    const idDatosOperacion = cabecera.id_datos_operacion ?? 0;

    return {
      ...buildDatosOperacionEmpty(idExpediente),
      ...cabecera,
      id_expediente: cabecera.id_expediente || idExpediente,
      datos_credito: cabecera.datos_credito
        ? {
            ...cabecera.datos_credito,
            // "Crédito Segunda Vivienda" es obligatorio y debe quedar en SÍ (la validación lo
            // exige), pero el backend puede devolver null/false por defecto en un registro
            // nuevo: se normaliza a true para que el check venga marcado al abrir.
            credito_segunda_vivienda: true,
          }
        : buildDatosCreditoEmpty(idExpediente, idDatosOperacion),
      compradores: cabecera.compradores ?? [],
      vendedores: cabecera.vendedores ?? [],
      fiadores_garantes: cabecera.fiadores_garantes ?? [],
      banco_acreedor:
        cabecera.banco_acreedor ??
        buildBancoAcreedorEmpty(idExpediente, idDatosOperacion),
      propiedad:
        cabecera.propiedad ??
        buildPropiedadEmpty(idExpediente, idDatosOperacion),
    };
  };

  useEffect(() => {
    if (currentExpedienteRef.current !== idExpediente) {
      currentExpedienteRef.current = idExpediente;
      hasHydratedRef.current = false;
      setIsDisabled(true);
      setCanAdvance(false);
    }
  }, [idExpediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (!hasValidExpediente) {
      setForm(buildDatosOperacionEmpty(0));
      hasHydratedRef.current = true;
      return;
    }

    // Sólo se hidrata con datos posteriores al montaje: el caché de react-query puede
    // devolver el payload viejo de una visita anterior (p. ej. `enviar_reparo=true`) y,
    // como el guard hace que se hidrate una sola vez, ese valor quedaba pegado hasta un F5.
    if (!datosOperacionQuery.isFetchedAfterMount) return;

    if (datosOperacionQuery.data?.status) {
      setForm(normalizeForm(datosOperacionQuery.data.detail));
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
    }
  }, [
    datosOperacionQuery.data,
    datosOperacionQuery.isFetchedAfterMount,
    hasValidExpediente,
    idExpediente,
  ]);

  const showToast = (
    severity: 'success' | 'info' | 'warn' | 'error',
    summary: string,
    detail: string,
  ) => {
    toast.current?.show({
      severity,
      summary,
      detail,
      life: 3500,
    });
  };

  const handleEditar = () => {
    if (!hasValidExpediente) {
      showToast('warn', 'Validación', 'El expediente es obligatorio.');
      return;
    }

    setIsDisabled(false);
    setCanAdvance(false);
  };

  const handleSalir = () => {
    navigate('/home/bandeja');
  };

  const normalizeEntityId = (value: number | null | undefined): number => {
    const id = Number(value ?? 0);

    return id > 0 ? id : 0;
  };

  const preparePayload = (): DatosOperacion => {
    const idDatosOperacion = normalizeEntityId(form.id_datos_operacion);
    const idExp = form.id_expediente || idExpediente;

    return {
      ...form,
      id_datos_operacion: idDatosOperacion,
      id_expediente: idExp,
      is_active: form.is_active ?? true,
      row_status: form.row_status ?? true,
      enviar_reparo: form.enviar_reparo ?? false,
      observaciones: form.observaciones ?? '',
      datos_credito: form.datos_credito
        ? {
          ...form.datos_credito,
          id_datos_operacion_datos_credito: normalizeEntityId(
            form.datos_credito.id_datos_operacion_datos_credito,
          ),
          id_datos_operacion: idDatosOperacion,
          id_expediente: idExp,
        }
        : null,
      compradores: (form.compradores ?? []).map((item) => ({
        ...item,
        id_datos_operacion_comprador: normalizeEntityId(item.id_datos_operacion_comprador),
        id_datos_operacion: idDatosOperacion,
        id_carga_operacion_banco_antecedente_comprador: item.id_carga_operacion_banco_antecedente_comprador ?? 0,
        id_expediente: idExp,
      })),
      vendedores: (form.vendedores ?? []).map((item) => ({
        ...item,
        id_datos_operacion_vendedor: normalizeEntityId(item.id_datos_operacion_vendedor),
        id_datos_operacion: idDatosOperacion,
        id_carga_operacion_banco_antecedente_vendedor: item.id_carga_operacion_banco_antecedente_vendedor ?? 0,
        id_expediente: idExp,
      })),
      fiadores_garantes: (form.fiadores_garantes ?? []).map((item) => ({
        ...item,
        id_datos_operacion_fiador_garante: normalizeEntityId(
          item.id_datos_operacion_fiador_garante,
        ),
        id_datos_operacion: idDatosOperacion,
        id_expediente: idExp,
      })),
      banco_acreedor: form.banco_acreedor
        ? {
          ...form.banco_acreedor,
          id_datos_operacion_banco_acreedor: normalizeEntityId(
            form.banco_acreedor.id_datos_operacion_banco_acreedor,
          ),
          id_datos_operacion: idDatosOperacion,
          id_expediente: idExp,
        }
        : null,
      propiedad: form.propiedad
        ? {
          ...form.propiedad,
          // Con "Existe Rol Avalúo" distinto de Sí ('001') no debe guardarse ningún rol ni
          // el valor de avalúo. La sección los limpia al cambiar el selector, pero un
          // registro que ya venía cargado desde la BD se guardaría igual.
          ...(form.propiedad.existe_rol_avaluo === '001'
            ? {}
            : { rol_avaluo_1: null, rol_avaluo_2: null, valor_avaluo_pesos: null }),
          id_datos_operacion_propiedad: normalizeEntityId(
            form.propiedad.id_datos_operacion_propiedad,
          ),
          id_datos_operacion: idDatosOperacion,
          id_expediente: idExp,
        }
        : null,
    };
  };

  const validateDatosCredito = (): ValidationResult => {
  const datosCredito = form.datos_credito;

  if (!datosCredito) {
    return {
      isValid: false,
      tabIndex: 0,
      message: 'Debe completar la pestaña Datos del Crédito.',
    };
  }

  // El orden de estos pasos DEBE ser el ORDEN VISUAL de `DatosCreditoSection`, porque se
  // reporta solo el PRIMERO que falla y `focusFieldByKey` enfoca ese campo:
  //   tarjeta 1 "Datos del Crédito"      → ubicacion, tipo_operacion, fines_generales,
  //                                        nombre_proyecto, credito_segunda_vivienda, inmobiliaria
  //   tarjeta 2 "Condiciones de la Propiedad" → grupo de condiciones, porcentaje_impuesto,
  //                                        monto_credito_afecto_impuesto, impuesto_a_pagar
  const faltante = (value: unknown, label: string, key: string): ValidationResult | null =>
    (typeof value === 'boolean' ? isMissingBoolean(value) : isEmptyValue(value))
      ? {
          isValid: false,
          tabIndex: 0,
          fieldKey: key,
          message: `Debe completar el campo ${label}.`,
        }
      : null;

  const tieneCondicionPropiedad =
    datosCredito.vivienda_social === true ||
    datosCredito.dfl2 === true ||
    datosCredito.propietario_dfl2 === true ||
    datosCredito.recepcion_final_mayor_2_anios === true;

  const pasos: (ValidationResult | null)[] = [
    faltante(datosCredito.ubicacion, 'Ubicación', 'ubicacion'),
    faltante(datosCredito.tipo_operacion, 'Tipo Operación', 'tipo_operacion'),
    faltante(datosCredito.fines_generales, 'Fines Generales', 'fines_generales'),
    faltante(datosCredito.nombre_proyecto, 'Nombre Proyecto', 'nombre_proyecto'),
    // Debe quedar en SÍ: no alcanza con que tenga valor (false también es un valor válido)
    datosCredito.credito_segunda_vivienda === true
      ? null
      : {
          isValid: false,
          tabIndex: 0,
          fieldKey: 'credito_segunda_vivienda',
          message: 'Debe marcar "Crédito Segunda Vivienda" como Sí.',
        },
    faltante(datosCredito.inmobiliaria, 'Inmobiliaria', 'inmobiliaria'),
    // Al menos una de las 4 condiciones de la tabla
    tieneCondicionPropiedad
      ? null
      : {
          isValid: false,
          tabIndex: 0,
          fieldKey: 'vivienda_social',
          message:
            'Debe seleccionar al menos una condición de la propiedad (Vivienda Social, DFL 2, Propietario DFL 2 o Recepción Final Mayor a 2 Años).',
        },
    faltante(datosCredito.porcentaje_impuesto, '% Impuesto', 'porcentaje_impuesto'),
    faltante(
      datosCredito.monto_credito_afecto_impuesto,
      'Monto Crédito Afecto Impuesto',
      'monto_credito_afecto_impuesto',
    ),
    faltante(datosCredito.impuesto_a_pagar, 'Impuesto a Pagar', 'impuesto_a_pagar'),
  ];

  return pasos.find((paso) => paso !== null) ?? validResult;
};

  const validatePersonas = (
    rows: (DatosOperacionComprador | DatosOperacionVendedor)[] | undefined,
    type: 'comprador' | 'vendedor',
    tabIndex: number,
    tabName: string,
    requireAtLeastOne = false,
  ): ValidationResult => {
    const activeRows = (rows ?? []).filter((row) => row.row_status !== false);

    if (requireAtLeastOne && activeRows.length === 0) {
      return {
        isValid: false,
        tabIndex,
        message: `Debe registrar al menos un registro en ${tabName}.`,
      };
    }

    for (let index = 0; index < activeRows.length; index += 1) {
      // RUT: formato y dígito verificador (módulo 11)
      const rutMessage = getPersonaRutErrorMessage(activeRows[index]);

      if (rutMessage) {
        return {
          isValid: false,
          tabIndex,
          message: `${tabName}, registro ${index + 1}: ${rutMessage}`,
        };
      }

      // Mismo validador y MISMO ORDEN que el diálogo (orden visual): una sola fuente.
      const tipoPersonaOptions =
        type === 'comprador'
          ? controlesCompradorConTipoPersona.tipo_comprador
          : controlesVendedor.tipo_vendedor;
      const missingField = getMissingPersonaField(type, activeRows[index], tipoPersonaOptions);

      if (missingField) {
        return {
          isValid: false,
          tabIndex,
          message: `${tabName}, registro ${index + 1}: debe completar el campo ${missingField}.`,
        };
      }
    }

    return validResult;
  };

  const validateFiadoresGarantes = (): ValidationResult => {
    const activeRows = (form.fiadores_garantes ?? []).filter((row) => row.row_status !== false);

    for (let index = 0; index < activeRows.length; index += 1) {
      const row = activeRows[index];
      // Mismo ORDEN VISUAL que el diálogo del fiador (arriba hacia abajo).
      const requiredFields: { value: unknown; label: string }[] = [
        { value: row.rut, label: 'RUT' },
        { value: row.nombres, label: 'Nombres' },
        { value: row.apellido_paterno, label: 'Apellido Paterno' },
        { value: row.apellido_materno, label: 'Apellido Materno' },
        { value: row.fecha_nacimiento, label: 'Fecha Nacimiento' },
        { value: row.genero, label: 'Género' },
        { value: row.estado_civil, label: 'Estado Civil' },
        { value: row.nacionalidad, label: 'Nacionalidad' },
        { value: row.profesion, label: 'Profesión' },
        { value: row.relacion_titular, label: 'Relación Titular' },
        { value: getTelefonoFijoDigitos(row), label: 'Teléfono Fijo' },
        { value: row.telefono_movil, label: 'Teléfono Móvil' },
        { value: row.email, label: 'Email' },
        { value: row.direccion, label: 'Dirección' },
        { value: row.region, label: 'Región' },
        { value: row.comuna, label: 'Comuna' },
      ];

      const missing = requiredFields.find(({ value }) => isEmptyValue(value));

      if (missing) {
        return {
          isValid: false,
          tabIndex: 3,
          message: `Datos del Fiador / Garante, registro ${index + 1}: debe completar el campo ${missing.label}.`,
        };
      }
    }

    return validResult;
  };

  const validateBancoAcreedor = (): ValidationResult => {
    const banco = form.banco_acreedor;

    if (!banco) {
      return {
        isValid: false,
        tabIndex: 4,
        message: 'Debe completar la pestaña Datos del Banco Acreedor.',
      };
    }

    const requiredFields: { value: unknown; label: string; key: string }[] = [
      { value: banco.cuenta_carta_resguardo, label: 'Cuenta Carta de Resguardo', key: 'cuenta_carta_resguardo' },
    ];

    // Institución y RUT del banco sólo son obligatorios cuando HAY carta de resguardo.
    if (banco.cuenta_carta_resguardo === true) {
      requiredFields.push(
        { value: banco.institucion, label: 'Institución', key: 'institucion' },
        { value: banco.rut_banco_acreedor, label: 'RUT Banco Acreedor', key: 'rut_banco_acreedor' },
      );
    }

    const missing = requiredFields.find(({ value }) =>
      typeof value === 'boolean' ? isMissingBoolean(value) : isEmptyValue(value),
    );

    if (missing) {
      return {
        isValid: false,
        tabIndex: 4,
        fieldKey: missing.key,
        message: `Debe completar el campo ${missing.label}.`,
      };
    }

    // El RUT es opcional, pero si se ingresa se valida con la MISMA regla que el resto de
    // los RUT de la pantalla (sin puntos, con guion, cuerpo de 7-8 dígitos y módulo 11).
    // Antes se usaba `isValidRut`, que "limpia" la entrada y por eso aceptaba `123456789`
    // o incluso valores con letras: no frenaba los mismos errores que los demás RUT.
    if (!isEmptyValue(banco.rut_banco_acreedor)) {
      const motivo = describeRutError(normalizeRut(banco.rut_banco_acreedor));
      if (motivo) {
        return {
          isValid: false,
          tabIndex: 4,
          fieldKey: 'rut_banco_acreedor',
          message: `RUT Banco Acreedor. ${motivo}`,
        };
      }
    }

    return validResult;
  };

  const validatePropiedad = (): ValidationResult => {
    const propiedad = form.propiedad;

    if (!propiedad) {
      return {
        isValid: false,
        tabIndex: 5,
        message: 'Debe completar la pestaña Datos de la Propiedad.',
      };
    }

    // El orden de esta lista DEBE ser el orden VISUAL de la sección (`PropiedadSection`):
    // primero la tarjeta "Datos de la Propiedad" y después "Dirección y Rol de Avalúo",
    // donde `valor_avaluo_pesos` va ANTES de rol_avaluo_1 / rol_avaluo_2.
    // Si no coinciden, el mensaje y el foco apuntan a un campo distinto del primero que
    // el usuario ve vacío en pantalla.
    const requiredFields: { value: unknown; label: string; key: string }[] = [
      { value: propiedad.tipo_propiedad, label: 'Tipo Propiedad', key: 'tipo_propiedad' },
      { value: propiedad.estado, label: 'Estado', key: 'estado' },
      { value: propiedad.tipo_venta, label: 'Tipo Venta', key: 'tipo_venta' },
      { value: propiedad.tipo_construccion, label: 'Tipo Construcción', key: 'tipo_construccion' },
      { value: propiedad.tipo_direccion, label: 'Tipo Dirección', key: 'tipo_direccion' },
      { value: propiedad.existe_rol_avaluo, label: 'Existe Rol Avalúo', key: 'existe_rol_avaluo' },
      { value: propiedad.direccion, label: 'Dirección', key: 'direccion' },
      { value: propiedad.villa_condominio, label: 'Villa / Condominio', key: 'villa_condominio' },
      { value: propiedad.numero, label: 'Número', key: 'numero' },
      { value: propiedad.numero_casa_habitantes, label: 'N° Casa Habitantes', key: 'numero_casa_habitantes' },
      { value: propiedad.conjunto, label: 'Conjunto', key: 'conjunto' },
      { value: propiedad.manzana, label: 'Manzana', key: 'manzana' },
      { value: propiedad.lote, label: 'Lote', key: 'lote' },
      { value: propiedad.region, label: 'Región', key: 'region' },
      { value: propiedad.comuna, label: 'Comuna', key: 'comuna' },
    ];

    // El rol y el valor sólo EXISTEN si "Existe Rol Avalúo" = Sí ('001'): con cualquier
    // otro código la sección los deshabilita y los vacía, así que exigirlos dejaba el
    // formulario imposible de avanzar. Se agregan al final, en el mismo orden en que se
    // ven en pantalla (valor primero).
    if (propiedad.existe_rol_avaluo === '001') {
      requiredFields.push(
        { value: propiedad.valor_avaluo_pesos, label: 'Valor Avalúo Pesos', key: 'valor_avaluo_pesos' },
        { value: propiedad.rol_avaluo_1, label: 'Rol Avalúo 1', key: 'rol_avaluo_1' },
        { value: propiedad.rol_avaluo_2, label: 'Rol Avalúo 2', key: 'rol_avaluo_2' },
      );
    }

    const missing = requiredFields.find(({ value }) => isEmptyValue(value));

    if (missing) {
      return {
        isValid: false,
        tabIndex: 5,
        fieldKey: missing.key,
        message: `Debe completar el campo ${missing.label}.`,
      };
    }

    return validResult;
  };

  const validateRequiredFields = (): ValidationResult => {
    const validations = [
      validateDatosCredito(),
      validatePersonas(form.compradores, 'comprador', 1, 'Datos del Comprador', true),
      validatePersonas(form.vendedores, 'vendedor', 2, 'Datos del Vendedor'),
      validateFiadoresGarantes(),
      validateBancoAcreedor(),
      validatePropiedad(),
    ];

    return validations.find((validation) => !validation.isValid) ?? validResult;
  };

  const handleGuardar = async () => {
    if (!hasValidExpediente) {
      showToast('warn', 'Validación', 'El expediente es obligatorio.');
      return;
    }

    if (!form.enviar_reparo) {
      const validation = validateRequiredFields();
      if (!validation.isValid) {
        setActiveTabIndex(validation.tabIndex);
        showToast('warn', 'Validación', validation.message);
        focusFieldByKey(validation.fieldKey);
        return;
      }
    }

    // Las Observaciones están al FINAL de la pantalla (fuera de las pestañas), así que se
    // validan al final: si falta más de un campo, el mensaje y el foco deben apuntar primero
    // al que el usuario ve más arriba.
    if (!form.observaciones || !form.observaciones.trim()) {
      showToast('warn', 'Validación', 'Debe ingresar las Observaciones.');
      focusFieldByKey('observaciones');
      return;
    }

    try {
      const response = await saveMutation.mutateAsync(preparePayload());

      if (!response.status) {
        showToast('error', 'Error', response.message ?? 'No se pudo guardar la actividad.');
        return;
      }

      setForm(normalizeForm(response.detail));
      setIsDisabled(true);
      setCanAdvance(true);
      showToast('success', 'Guardado', response.message ?? 'Datos de Operación guardados correctamente.');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Error inesperado al guardar.';
      showToast('error', 'Error', message);
    }
  };

  const handleAvanzar = async () => {
    if (!hasValidExpediente) {
      showToast('warn', 'Validación', 'El expediente es obligatorio.');
      return;
    }

    if (!canAdvance) {
      showToast('warn', 'Validación', 'Debe guardar los cambios antes de avanzar.');
      return;
    }

    if (!form.enviar_reparo) {
      const validation = validateRequiredFields();
      if (!validation.isValid) {
        setActiveTabIndex(validation.tabIndex);
        showToast('warn', 'Validación', validation.message);
        focusFieldByKey(validation.fieldKey);
        return;
      }
    }

    try {
      const response = await avanzarMutation.mutateAsync(idExpediente);

      if (!response.status) {
        showToast('error', 'Error', response.message ?? 'No se pudo avanzar la actividad.');
        return;
      }

      showToast('success', 'Avance', response.message ?? 'Actividad avanzada correctamente.');
      navigate('/home/bandeja');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Error inesperado al avanzar.';
      showToast('error', 'Error', message);
    }
  };

  const updateDatosCreditoField = <K extends keyof DatosOperacionDatosCredito>(
    field: K,
    value: DatosOperacionDatosCredito[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      datos_credito: {
        ...(prev.datos_credito ?? buildDatosCreditoEmpty(idExpediente, prev.id_datos_operacion)),
        [field]: value,
      },
    }));
  };

  const updateBancoAcreedorField = <K extends keyof DatosOperacionBancoAcreedor>(
    field: K,
    value: DatosOperacionBancoAcreedor[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      banco_acreedor: {
        ...(prev.banco_acreedor ?? buildBancoAcreedorEmpty(idExpediente, prev.id_datos_operacion)),
        [field]: value,
      },
    }));
  };

  const updatePropiedadField = <K extends keyof DatosOperacionPropiedad>(
    field: K,
    value: DatosOperacionPropiedad[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      propiedad: {
        ...(prev.propiedad ?? buildPropiedadEmpty(idExpediente, prev.id_datos_operacion)),
        [field]: value,
      },
    }));
  };

  const updateCompradores = (compradores: DatosOperacionComprador[]) => {
    setForm((prev) => ({
      ...prev,
      compradores,
    }));
  };

  const updateVendedores = (vendedores: DatosOperacionVendedor[]) => {
    setForm((prev) => ({
      ...prev,
      vendedores,
    }));
  };

  const updateFiadoresGarantes = (fiadores_garantes: DatosOperacionFiadorGarante[]) => {
    setForm((prev) => ({
      ...prev,
      fiadores_garantes,
    }));
  };

  const updateField = <K extends keyof DatosOperacion>(
    field: K,
    value: DatosOperacion[K]
  ) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const tabHeader = useMemo(() => {
    if (isLoading) return 'Cargando Datos de Operación...';
    return 'Datos de Operación';
  }, [isLoading]);

  return (
    <div>
      <Toast ref={toast} />

      <Accordion multiple activeIndex={[0, 1, 2]}>
        <AccordionTab header="Información del Expediente" disabled={!hasValidExpediente}>
          <EncabezadoActividad idExpediente={idExpediente} activityID={idActividad || ACTIVITY_ID} />
        </AccordionTab>

        <AccordionTab header="Funciones Transversales" disabled={!hasValidExpediente}>
          <FuncionesTransversales
            idExpediente={idExpediente}
            idActividad={idActividad || ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header={tabHeader} disabled={!hasValidExpediente}>
          {!hasValidExpediente ? (
            <Card>
              <div className="text-center text-600">
                No se recibió un expediente válido para esta actividad.
              </div>
            </Card>
          ) : (
            <div className="rounded-xl border border-gray-200 bg-white p-3 sm:p-4 shadow-sm">
              <div className="mb-4 flex flex-col gap-1 border-b border-gray-100 pb-3">
                <h2 className="text-lg font-semibold text-gray-800">Datos de Operación</h2>
                <p className="text-sm text-gray-500">
                  Complete la información por pestañas. Use el botón general Guardar para persistir toda la actividad.
                </p>
                <p className="text-sm text-gray-500">
                  Los campos marcados con <RequiredMark /> son obligatorios.
                </p>
              </div>

              <TabView
                className="mi-tabview"
                activeIndex={activeTabIndex}
                onTabChange={(e) => setActiveTabIndex(e.index)}
              >
                <TabPanel header="Datos del Crédito">
                  <DatosCreditoSection
                    value={form.datos_credito}
                    disabled={isDisabled || isBusy}
                    controles={controlesDatosCredito}
                    loadingControles={isLoadingControlesDatosCredito}
                    onChange={updateDatosCreditoField}
                  />
                </TabPanel>

                <TabPanel header="Datos del Comprador">
                  <DatosOperacionPersonaGrid
                    title="Datos del Comprador"
                    type="comprador"
                    value={form.compradores ?? []}
                    idExpediente={idExpediente}
                    idDatosOperacion={form.id_datos_operacion ?? 0}
                    disabled={isDisabled || isBusy}
                    canEdit={canEditSections}
                    controles={controlesCompradorConTipoPersona}
                    loadingControles={isLoadingControlesComprador || isLoadingControlesVendedor}
                    onChange={updateCompradores}
                    onWarn={(message) => showToast('warn', 'Validación', message)}
                  />
                </TabPanel>

                <TabPanel header="Datos del Vendedor">
                  <DatosOperacionPersonaGrid
                    title="Datos del Vendedor"
                    type="vendedor"
                    value={form.vendedores ?? []}
                    idExpediente={idExpediente}
                    idDatosOperacion={form.id_datos_operacion ?? 0}
                    disabled={isDisabled || isBusy}
                    canEdit={canEditSections}
                    controles={controlesVendedor}
                    loadingControles={isLoadingControlesVendedor}
                    onChange={updateVendedores}
                    onWarn={(message) => showToast('warn', 'Validación', message)}
                  />
                </TabPanel>

                <TabPanel header="Datos del Fiador / Garante">
                  <FiadorGaranteSection
                    value={form.fiadores_garantes ?? []}
                    idExpediente={idExpediente}
                    idDatosOperacion={form.id_datos_operacion ?? 0}
                    disabled={isDisabled || isBusy}
                    canEdit={canEditSections}
                    controles={controlesFiadorGarante}
                    loadingControles={isLoadingControlesFiadorGarante}
                    onChange={updateFiadoresGarantes}
                    onWarn={(message) => showToast('warn', 'Validación', message)}
                  />
                </TabPanel>

                <TabPanel header="Datos del Banco Acreedor">
                  <BancoAcreedorSection
                    value={form.banco_acreedor}
                    disabled={isDisabled || isBusy}
                    controles={controlesBancoAcreedor}
                    loadingControles={isLoadingControlesBancoAcreedor}
                    onChange={updateBancoAcreedorField}
                  />
                </TabPanel>

                <TabPanel header="Datos de la Propiedad">
                  <PropiedadSection
                    value={form.propiedad}
                    disabled={isDisabled || isBusy}
                    controles={controlesPropiedad}
                    loadingControles={isLoadingControlesPropiedad}
                    onChange={updatePropiedadField}
                  />
                </TabPanel>
              </TabView>

              <div className="mt-6 space-y-6">
                <div>
                  <div className="bg-azul-presto text-white font-bold text-sm px-4 py-2 uppercase rounded mb-4">
                    Estatus de la Actividad
                  </div>
                  <div className="flex items-center gap-2 mb-4 h-10">
                    <Checkbox
                      inputId="enviar_reparo"
                      checked={form.enviar_reparo ?? false}
                      onChange={(e) => updateField("enviar_reparo", e.checked ?? false)}
                      disabled={isDisabled}
                    />
                    <label htmlFor="enviar_reparo" className="font-semibold text-sm">
                      ¿Enviar a Reparo?
                    </label>
                  </div>


                  <div className="flex flex-col gap-1" data-field="observaciones">
                    <label className="font-semibold text-sm">Observaciones<RequiredMark /></label>
                    <InputTextarea
                      id="observaciones"
                      value={form.observaciones ?? ""}
                      onChange={(e) => updateField("observaciones", e.target.value)}
                      rows={3}
                      maxLength={1000}
                      className="form-textarea-presto w-full"
                      placeholder="Ingrese observaciones (máximo 1000 caracteres)"
                      disabled={isDisabled}
                      style={{ resize: "none" }}
                    />
                    <div className="flex justify-end mt-1 text-xs">
                      <span className={
                        (form.observaciones?.length ?? 0) >= 1000 
                          ? "text-red-600" 
                          : (form.observaciones?.length ?? 0) >= 900 
                            ? "text-orange-500" 
                            : "text-gray-500"
                      }>
                        {form.observaciones?.length ?? 0}
                      </span>
                      <span className="mx-1 text-gray-500">/</span>
                      <span className="text-gray-500">1000</span>
                    </div>
                  </div>
                </div>
              </div>

              <ActivityActionBar
                from_tracking={fromTracking}
                is_busy={isBusy}
                is_disabled={isDisabled}
                can_advance={canAdvance}
                is_saving={saveMutation.isPending}
                is_advancing={avanzarMutation.isPending}
                on_edit={handleEditar}
                on_save={handleGuardar}
                on_advance={handleAvanzar}
                on_exit={handleSalir}
              />
            </div>
          )}
        </AccordionTab>
      </Accordion>
    </div>
  );
}