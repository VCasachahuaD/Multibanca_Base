import { Checkbox } from 'primereact/checkbox';
import { Dropdown } from 'primereact/dropdown';

import RequiredMark from '@/shared/components/RequiredMark';
import { InputNumber } from 'primereact/inputnumber';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';

import type { DatosOperacionDatosCredito } from '../models/datos_operacion';
import {
  EMPTY_CONTROLES_DATOS_CREDITO,
  type ControlesDatosCredito,
} from '../models/catalogo';
import { RadioButton } from 'primereact/radiobutton';
import { useEffect } from 'react';

type Props = {
  value: DatosOperacionDatosCredito | null | undefined;
  disabled: boolean;
  controles?: ControlesDatosCredito;
  loadingControles?: boolean;
  onChange: <K extends keyof DatosOperacionDatosCredito>(
    field: K,
    value: DatosOperacionDatosCredito[K],
  ) => void;
};

// NOTA: los campos booleanos de esta sección (ubicacion, fines_generales, etc.) se
// renderizan con Checkbox y se guardan como boolean: NO usan el catálogo
// DATOS_OPERACION_SI_NO (cuyos códigos son '01' = Sí y '02' = No).
// No reintroducir helpers de traducción booleano ↔ código de catálogo acá.

const fieldClass = 'flex flex-col gap-1';
const labelClass = 'font-semibold text-sm text-gray-700';
const inputClass = 'form-input-presto w-full';
const dropdownClass = 'form-dropdown-presto w-full';

export default function DatosCreditoSection({
  value,
  disabled,
  controles = EMPTY_CONTROLES_DATOS_CREDITO,
  loadingControles = false,
  onChange,
}: Props) {
  const controlDisabled = disabled || loadingControles;

  const handleRadioChange = (field: keyof DatosOperacionDatosCredito, val: boolean) => {
    onChange(field, val);

    if (val === true) {
      if (field === 'vivienda_social') {
        const fieldsToReset: (keyof DatosOperacionDatosCredito)[] = [
          'dfl2',
          'propietario_dfl2',
          'recepcion_final_mayor_2_anios',
        ];
        fieldsToReset.forEach((f) => {
          onChange(f, false);
        });
      } else if (field === 'dfl2') {
        onChange('vivienda_social', false);
      } else if (field === 'propietario_dfl2') {
        onChange('vivienda_social', false);
      } else if (field === 'recepcion_final_mayor_2_anios') {
        onChange('vivienda_social', false);
      }
    }
  };

  useEffect(() => {
    if (!value) return;

    const viviendaSocial = value.vivienda_social ?? false;
    const dfl2 = value.dfl2 ?? false;
    const propietarioDfl2 = value.propietario_dfl2 ?? false;
    const recepcion = value.recepcion_final_mayor_2_anios ?? false;

    let porcentaje: number | null = null;

    if (viviendaSocial) {
      porcentaje = 0;
    } else if (dfl2 && !propietarioDfl2 && !recepcion) {
      porcentaje = 0.2;
    } else if (propietarioDfl2 && !dfl2 && !recepcion) {
      porcentaje = 0.2;
    } else if (dfl2 && recepcion && !propietarioDfl2) {
      porcentaje = 0.8;
    } else if (propietarioDfl2 && recepcion && !dfl2) {
      porcentaje = 0.8;
    } else if (dfl2 && propietarioDfl2 && recepcion) {
      porcentaje = 0.8;
    } else if (!viviendaSocial && !dfl2 && !propietarioDfl2 && !recepcion) {
      porcentaje = null;
    }

    const montoCredito = value.monto_credito_afecto_impuesto ?? 0;
    let impuestoAPagar: number | null = null;

    if (porcentaje !== null && montoCredito > 0) {
      impuestoAPagar = porcentaje * montoCredito;
    }

    if (porcentaje !== value.porcentaje_impuesto) {
      onChange('porcentaje_impuesto', porcentaje);
    }

    if (impuestoAPagar !== value.impuesto_a_pagar) {
      onChange('impuesto_a_pagar', impuestoAPagar);
    }
  }, [
    value?.vivienda_social,
    value?.dfl2,
    value?.propietario_dfl2,
    value?.recepcion_final_mayor_2_anios,
    value?.monto_credito_afecto_impuesto,
    onChange,
    value,
  ]);

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-gray-200 bg-white p-4 sm:p-5 shadow-sm">
        <div className="mb-4 border-b border-gray-100 pb-3">
          <h3 className="text-base font-semibold text-gray-800">Datos del Crédito</h3>
          <p className="text-sm text-gray-500">Información general del crédito asociado al expediente.</p>
        </div>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
          <div className={fieldClass} data-field="ubicacion">
            <label className={labelClass}>Ubicación<RequiredMark /></label>

            <div className="flex flex-col gap-3 py-2">
              <div className="flex items-center gap-2">
                <RadioButton
                  className="form-radio-presto"
                  inputId="ubicacion_santiago"
                  checked={value?.ubicacion === true}
                  disabled={disabled}
                  onChange={() => onChange('ubicacion', true)}
                />

                <label
                  htmlFor="ubicacion_santiago"
                  className="text-sm text-gray-700"
                >
                  Santiago
                </label>
              </div>

              <div className="flex items-center gap-2">
                <RadioButton
                  className="form-radio-presto"
                  inputId="ubicacion_regiones"
                  checked={value?.ubicacion === false}
                  disabled={disabled}
                  onChange={() => onChange('ubicacion', false)}
                />

                <label
                  htmlFor="ubicacion_regiones"
                  className="text-sm text-gray-700"
                >
                  Regiones
                </label>
              </div>
            </div>
          </div>

          <div className={fieldClass} data-field="tipo_operacion">
            <label className={labelClass}>Tipo Operación<RequiredMark /></label>
            <Dropdown
              value={value?.tipo_operacion ?? null}
              options={controles.tipo_operacion}
              optionLabel="description"
              optionValue="code"
              disabled={controlDisabled}
              className={dropdownClass}
              placeholder="Seleccione"
              onChange={(e) => onChange('tipo_operacion', e.value)}
              showClear
            />
          </div>

          <div className={fieldClass} data-field="fines_generales">
            <label className={labelClass}>Fines Generales<RequiredMark /></label>

            <div className="flex items-center gap-6 h-10">
              <div className="flex items-center gap-2">
                <RadioButton
                  className="form-radio-presto"
                  inputId="fines_generales_si"
                  checked={value?.fines_generales === true}
                  disabled={disabled}
                  onChange={() => onChange('fines_generales', true)}
                />

                <label
                  htmlFor="fines_generales_si"
                  className="text-sm text-gray-700"
                >
                  Sí
                </label>
              </div>

              <div className="flex items-center gap-2">
                <RadioButton
                  className="form-radio-presto"
                  inputId="fines_generales_no"
                  checked={value?.fines_generales === false}
                  disabled={disabled}
                  onChange={() => onChange('fines_generales', false)}
                />

                <label
                  htmlFor="fines_generales_no"
                  className="text-sm text-gray-700"
                >
                  No
                </label>
              </div>
            </div>
          </div>

          <div className={fieldClass} data-field="nombre_proyecto">
            <label className={labelClass}>Nombre Proyecto<RequiredMark /></label>
            <InputText
              value={value?.nombre_proyecto ?? ''}
              disabled={disabled}
              readOnly={true}
              className={inputClass}
            />
          </div>

          <div className={fieldClass} data-field="credito_segunda_vivienda">
            <label className={labelClass}>
              Crédito Segunda Vivienda<RequiredMark />
            </label>

            <div className="flex items-center h-10">
              <div className="flex items-center gap-2">
                <Checkbox
                  inputId="credito_segunda_vivienda"
                  className="form-checkbox-presto"
                  checked={value?.credito_segunda_vivienda === true}
                  // Condición obligatoria del crédito: siempre marcado y NO desmarcable.
                  // `normalizeForm` lo fuerza a true al abrir la actividad y la validación
                  // lo exige igual, como red de seguridad.
                  disabled
                />

                <label
                  htmlFor="credito_segunda_vivienda"
                  className="text-sm text-gray-700"
                >
                  Sí
                </label>
              </div>
            </div>
          </div>

          <div className={fieldClass} data-field="inmobiliaria">
            <label className={labelClass}>Inmobiliaria<RequiredMark /></label>
            <InputText
              value={value?.inmobiliaria ?? ''}
              disabled={disabled}
              readOnly={true}
              className={inputClass}
            />
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-gray-200 bg-white p-4 sm:p-5 shadow-sm">
        <div className="mb-4 border-b border-gray-100 pb-3">
          <h3 className="text-base font-semibold text-gray-800">Condiciones de la Propiedad</h3>
          <p className="text-sm text-gray-500">Indicadores y datos tributarios del crédito.</p>
        </div>

        <div className="reparo-table-container">
          <table className="reparo-table">
            <thead>
              <tr className="bg-azul-presto text-white">
                <th className="border border-gray-300 px-3 py-2 text-left">
                  Descripción
                </th>

                <th className="border border-gray-300 px-3 py-2 text-center">
                  Sí
                </th>

                <th className="border border-gray-300 px-3 py-2 text-center">
                  No
                </th>
              </tr>
            </thead>

            <tbody>
              <tr data-field="vivienda_social">
                <td data-label="Descripción" className="border border-gray-300 px-3 py-2">
                  Propiedad adquirida es Vivienda Social
                </td>

                <td data-label="Sí" className="border border-gray-300 text-center">
                  <RadioButton
                    aria-label="sí"
                    className="form-radio-presto"
                    inputId="vivienda_social_si"
                    checked={value?.vivienda_social === true}
                    disabled={disabled}
                    onChange={() => handleRadioChange('vivienda_social', true)}
                  />
                </td>

                <td data-label="No" className="border border-gray-300 text-center">
                  <RadioButton
                    className="form-radio-presto"
                    inputId="vivienda_social_no"
                    checked={value?.vivienda_social === false}
                    disabled={disabled}
                    onChange={() => handleRadioChange('vivienda_social', false)}
                  />
                </td>
              </tr>

              <tr data-field="dfl2">
                <td data-label="Descripción" className="border border-gray-300 px-3 py-2">
                  Propiedad adquirida es DFL 2
                </td>

                <td data-label="Sí" className="border border-gray-300 text-center">
                  <RadioButton
                    className="form-radio-presto"
                    inputId="dfl2_si"
                    checked={value?.dfl2 === true}
                    disabled={disabled}
                    onChange={() => handleRadioChange('dfl2', true)}
                  />
                </td>

                <td data-label="No" className="border border-gray-300 text-center">
                  <RadioButton
                    className="form-radio-presto"
                    inputId="dfl2_no"
                    checked={value?.dfl2 === false}
                    disabled={disabled}
                    onChange={() => handleRadioChange('dfl2', false)}
                  />
                </td>
              </tr>

              <tr data-field="propietario_dfl2">
                <td data-label="Descripción" className="border border-gray-300 px-3 py-2">
                  Comprador propietario 0 ó 1 vivienda DFL 2
                </td>

                <td data-label="Sí" className="border border-gray-300 text-center">
                  <RadioButton
                    className="form-radio-presto"
                    inputId="propietario_dfl2_si"
                    checked={value?.propietario_dfl2 === true}
                    disabled={disabled}
                    onChange={() => handleRadioChange('propietario_dfl2', true)}
                  />
                </td>

                <td data-label="No" className="border border-gray-300 text-center">
                  <RadioButton
                    className="form-radio-presto"
                    inputId="propietario_dfl2_no"
                    checked={value?.propietario_dfl2 === false}
                    disabled={disabled}
                    onChange={() => handleRadioChange('propietario_dfl2', false)}
                  />
                </td>
              </tr>

              <tr data-field="recepcion_final_mayor_2_anios">
                <td data-label="Descripción" className="border border-gray-300 px-3 py-2">
                  Recepción Final Mayor a 2 Años
                </td>

                <td data-label="Sí" className="border border-gray-300 text-center">
                  <RadioButton
                    className="form-radio-presto"
                    inputId="recepcion_si"
                    checked={value?.recepcion_final_mayor_2_anios === true}
                    disabled={disabled}
                    onChange={() =>
                      handleRadioChange('recepcion_final_mayor_2_anios', true)
                    }
                  />
                </td>

                <td data-label="No" className="border border-gray-300 text-center">
                  <RadioButton
                    className="form-radio-presto"
                    inputId="recepcion_no"
                    checked={value?.recepcion_final_mayor_2_anios === false}
                    disabled={disabled}
                    onChange={() =>
                      handleRadioChange('recepcion_final_mayor_2_anios', false)
                    }
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
          <div className={fieldClass} data-field="porcentaje_impuesto">
            <label className={labelClass}>% Impuesto<RequiredMark /></label>
            <InputNumber
              value={value?.porcentaje_impuesto ?? null}
              disabled={disabled}
              readOnly={true}
              className={inputClass}
              inputClassName="w-full"
              mode="decimal"
              minFractionDigits={0}
              maxFractionDigits={6}
            />
          </div>

          <div className={fieldClass} data-field="monto_credito_afecto_impuesto">
            <label className={labelClass}>Monto Crédito Afecto Impuesto<RequiredMark /></label>
            <InputNumber
              value={value?.monto_credito_afecto_impuesto ?? null}
              disabled={disabled}
              readOnly={true}
              className={inputClass}
              inputClassName="w-full"
              mode="decimal"
              minFractionDigits={0}
              maxFractionDigits={6}
            />
          </div>

          <div className={fieldClass} data-field="impuesto_a_pagar">
            <label className={labelClass}>Impuesto a Pagar<RequiredMark /></label>
            <InputNumber
              value={value?.impuesto_a_pagar ?? null}
              disabled={disabled}
              readOnly={true}
              className={inputClass}
              inputClassName="w-full"
              mode="decimal"
              minFractionDigits={0}
              maxFractionDigits={6}
            />
          </div>
        </div>
      </div>
    </div>
  );
}