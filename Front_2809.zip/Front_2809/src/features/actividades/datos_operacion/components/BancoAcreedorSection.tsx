import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';

import RequiredMark from '@/shared/components/RequiredMark';
import { RUT_MAX } from '@/shared/utils/fieldLimits';
import { formatRutSinPuntos } from '@/shared/utils/rut';

import type { DatosOperacionBancoAcreedor } from '../models/datos_operacion';
import {
  EMPTY_CONTROLES_BANCO_ACREEDOR,
  type ControlesBancoAcreedor,
} from '../models/catalogo';

type Props = {
  value: DatosOperacionBancoAcreedor | null | undefined;
  disabled: boolean;
  controles?: ControlesBancoAcreedor;
  loadingControles?: boolean;
  /** Nombres de campos que no se pueden editar (solo lectura). */
  readOnlyFields?: string[];
  onChange: <K extends keyof DatosOperacionBancoAcreedor>(
    field: K,
    value: DatosOperacionBancoAcreedor[K],
  ) => void;
};

const boolToCatalogCode = (value?: boolean | null) => {
  if (value === null || value === undefined) return null;
  return value ? '01' : '02';
};

const catalogCodeToBool = (value?: string | null) => {
  if (!value) return null;
  return ['001', '01', '1', 'S'].includes(value);
};

const fieldClass = 'flex flex-col gap-1';
const labelClass = 'font-semibold text-sm text-gray-700';
const inputClass = 'form-input-presto w-full';
const dropdownClass = 'form-dropdown-presto w-full';

export default function BancoAcreedorSection({
  value,
  disabled,
  controles = EMPTY_CONTROLES_BANCO_ACREEDOR,
  loadingControles = false,
  readOnlyFields,
  onChange,
}: Props) {
  const controlDisabled = disabled || loadingControles;
  const isFieldReadOnly = (field: string): boolean =>
    (readOnlyFields ?? []).includes(field);

  // Si no hay carta de resguardo, la institución y su RUT NO son obligatorios.
  const requiereDatosBanco = value?.cuenta_carta_resguardo === true;
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4 sm:p-5 shadow-sm">
      <div className="mb-4 border-b border-gray-100 pb-3">
        <h3 className="text-base font-semibold text-gray-800">Datos del Banco Acreedor</h3>
        <p className="text-sm text-gray-500">Información asociada a carta de resguardo, institución y reparos.</p>
      </div>

      <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
        <div className={fieldClass} data-field="cuenta_carta_resguardo">
          <label className={labelClass}>Cuenta Carta de Resguardo<RequiredMark /></label>
          <Dropdown
            value={boolToCatalogCode(value?.cuenta_carta_resguardo)}
            options={controles.si_no}
            optionLabel="description"
            optionValue="code"
            disabled={disabled || isFieldReadOnly('cuenta_carta_resguardo')}
            className={dropdownClass}
            placeholder="Seleccione"
            onChange={(e) => onChange('cuenta_carta_resguardo', catalogCodeToBool(e.value))}
            showClear
          />
        </div>

        <div className={fieldClass} data-field="institucion">
          <label className={labelClass}>Institución{requiereDatosBanco && <RequiredMark />}</label>
          <Dropdown
            value={value?.institucion ?? null}
            options={controles.banco_acreedor_institucion}
            optionLabel="description"
            optionValue="code"
            disabled={disabled || isFieldReadOnly('institucion')}
            className={dropdownClass}
            placeholder="Seleccione"
            onChange={(e) => onChange('institucion', e.value)}
            showClear
            filter
          />
        </div>

        <div className={fieldClass} data-field="rut_banco_acreedor">
          <label className={labelClass}>RUT Banco Acreedor{requiereDatosBanco && <RequiredMark />}</label>
          <InputText
            value={value?.rut_banco_acreedor ?? ''}
            disabled={disabled || isFieldReadOnly('rut_banco_acreedor')}
            className={inputClass}
            placeholder="12345678-9"
            maxLength={RUT_MAX}
            onChange={(e) => onChange('rut_banco_acreedor', formatRutSinPuntos(e.target.value))}
          />
        </div>
      </div>
    </div>
  );
}
