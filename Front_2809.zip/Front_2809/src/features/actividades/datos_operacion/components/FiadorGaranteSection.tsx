import type { ReactNode } from 'react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { Card } from 'primereact/card';
import { Column } from 'primereact/column';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { DataTable } from 'primereact/datatable';
import { Dialog } from 'primereact/dialog';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';

import RequiredMark from '@/shared/components/RequiredMark';

import type { DatosOperacionFiadorGarante } from '../models/datos_operacion';
import { buildFiadorGaranteEmpty } from '../models/datos_operacion';
import { fiadorLimitOf } from '../models/fieldLimits';
import {
  TELEFONO_MOVIL_PLACEHOLDER,
  telefonoFijoDigitos,
  telefonoFijoPlaceholder,
} from '@/shared/utils/fieldLimits';
import { formatRutSinPuntos } from '@/shared/utils/rut';
import {
  EMPTY_CONTROLES_FIADOR_GARANTE,
  type CatalogoOption,
  type ControlesFiadorGarante,
} from '../models/catalogo';
import { focusFieldByKey } from '../utils/fieldFocus';
import {
  maxFechaNacimiento,
  minFechaNacimiento,
  viewDateNacimiento,
  yearRangeNacimiento,
} from '@/shared/utils/dateCoherence';
import {
  describeEmailError,
  EMAIL_PLACEHOLDER,
  sanitizePhone,
} from '@/shared/utils/chileanValidators';
import {
  describeDireccionError,
  describeNombrePersonaError,
  sanitizeDireccion,
  sanitizeNombrePersona,
} from '@/shared/utils/textValidators';

const renderResponsiveCell = (value: ReactNode, titulo: string) => <div data-titulo={titulo}>{value ?? ""}</div>;

type DialogMode = 'view' | 'edit' | 'create';

type Props = {
  value: DatosOperacionFiadorGarante[];
  idExpediente: number;
  idDatosOperacion: number;
  disabled: boolean;
  canEdit: boolean;
  controles?: ControlesFiadorGarante;
  loadingControles?: boolean;
  /** Nombres de campos que no se pueden editar (solo lectura). */
  readOnlyFields?: string[];
  /** Permite agregar filas. */
  allowAdd?: boolean;
  /** Permite eliminar filas. */
  allowDelete?: boolean;
  onChange: (rows: DatosOperacionFiadorGarante[]) => void;
  onWarn?: (message: string) => void;
};

const parseDate = (value?: string | null): Date | null => {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const toIso = (value: Date | null | undefined): string | null =>
  value ? value.toISOString() : null;

const getName = (row: DatosOperacionFiadorGarante) =>
  [row.nombres, row.apellido_paterno, row.apellido_materno]
    .filter(Boolean)
    .join(' ')
    .trim() || row.rut || 'Registro';

const isEmptyValue = (value: unknown): boolean =>
  value === null || value === undefined || (typeof value === 'string' && value.trim() === '');

const normalizeCatalogCode = (value: unknown): string =>
  value === null || value === undefined ? '' : String(value).trim();

const getCatalogDescription = (options: CatalogoOption[], value: unknown): string => {
  const normalizedValue = normalizeCatalogCode(value);
  if (!normalizedValue) return '';

  const option = options.find((item) => {
    const normalizedCode = normalizeCatalogCode(item.code);
    return (
      normalizedCode === normalizedValue ||
      normalizedCode.replace(/^0+/, '') === normalizedValue.replace(/^0+/, '')
    );
  });

  return option?.description ?? option?.code ?? normalizedValue;
};

/**
 * Campos obligatorios del fiador/garante, en el ORDEN VISUAL del diálogo.
 *
 * Se reporta y se enfoca sólo el PRIMER faltante, así que el orden debe ir de arriba
 * hacia abajo igual que el JSX (rut → nombres y apellidos → fecha de nacimiento, género,
 * estado civil y nacionalidad → profesión → relación titular → teléfonos → email →
 * dirección, región y comuna).
 */
const requiredFiadorFields: { field: keyof DatosOperacionFiadorGarante; label: string }[] = [
  { field: 'rut', label: 'RUT' },
  { field: 'nombres', label: 'Nombres' },
  { field: 'apellido_paterno', label: 'Apellido Paterno' },
  { field: 'apellido_materno', label: 'Apellido Materno' },
  { field: 'fecha_nacimiento', label: 'Fecha Nacimiento' },
  { field: 'genero', label: 'Género' },
  { field: 'estado_civil', label: 'Estado Civil' },
  { field: 'nacionalidad', label: 'Nacionalidad' },
  { field: 'profesion', label: 'Profesión' },
  { field: 'relacion_titular', label: 'Relación Titular' },
  { field: 'telefono_fijo', label: 'Teléfono Fijo' },
  { field: 'telefono_movil', label: 'Teléfono Móvil' },
  { field: 'email', label: 'Email' },
  { field: 'direccion', label: 'Dirección' },
  { field: 'region', label: 'Región' },
  { field: 'comuna', label: 'Comuna' },
];

export const getMissingFiadorField = (row: DatosOperacionFiadorGarante): string | null => {
  const missing = requiredFiadorFields.find(({ field }) => esObligatorioFaltante(row, field));
  return missing?.label ?? null;
};

export const getMissingFiadorFieldKey = (row: DatosOperacionFiadorGarante): string | null => {
  const missing = requiredFiadorFields.find(({ field }) => esObligatorioFaltante(row, field));
  return missing?.field ?? null;
};

const getAreaCode = (regionCode: string | null | undefined, comunaCode: string | null | undefined): string | null => {
  if (!regionCode) return null;
  const r = String(regionCode).trim();
  const c = String(comunaCode ?? '').trim();
  switch (r) {
    case '07': return '2'; case '08': return '72'; case '10': return '42';
    case '12': return '45'; case '13': return '63'; case '15': return '67'; case '16': return '61';
    case '06': if (c === '06-18' || c === '06-32') return '34'; if (c === '06-23' || c === '06-26') return '33'; return null;
    case '09': if (c === '09-10' || c === '09-01') return '73'; if (c === '09-06' || c === '09-26') return '75'; return null;
    case '11': if (c === '11-07') return '41'; return null;
    case '14': if (c === '14-16') return '64'; if (c === '14-13') return '65'; return null;
    default: return null;
  }
};

/** Códigos de área de Chile: 1 dígito en RM, 2 en regiones. */
const AREA_CODES_KNOWN = ['2', '33', '34', '41', '42', '45', '61', '63', '64', '65', '67', '72', '73', '75'];

/**
 * Separa un teléfono FIJO (input compuesto) en código de área + dígitos locales.
 * El código puede venir ya guardado en el valor (dato existente) o deducirse de la
 * región/comuna mientras el usuario escribe; la caja del input muestra `digits`.
 */
const splitTelefonoFijo = (
  value: unknown,
  region: string | null | undefined,
  comuna: string | null | undefined,
): { code: string | null; digits: string } => {
  const val = String(value ?? '').trim();
  const matchedCode = AREA_CODES_KNOWN.find((c) => val.startsWith(c));
  const regionCode = getAreaCode(region, comuna);
  const code = matchedCode ?? regionCode ?? null;
  const digits = matchedCode ? val.slice(matchedCode.length) : regionCode ? '' : val;
  return { code, digits };
};

/**
 * Dígitos locales del Teléfono Fijo (sin el código de área).
 * El valor guardado INCLUYE el código, así que "tener valor" no es "teléfono completo":
 * un campo con sólo `2` se ve VACÍO en pantalla —la caja muestra los dígitos y el `(2)`
 * se dibuja aparte— y por eso la validación de obligatorio lo daba por lleno.
 */
export const getTelefonoFijoDigitos = (row: DatosOperacionFiadorGarante): string =>
  splitTelefonoFijo(row.telefono_fijo, row.region, row.comuna).digits;

/** Igual que el resto de los obligatorios, pero el teléfono compuesto exige DÍGITOS. */
const esObligatorioFaltante = (
  row: DatosOperacionFiadorGarante,
  field: keyof DatosOperacionFiadorGarante,
): boolean =>
  field === 'telefono_fijo' ? getTelefonoFijoDigitos(row) === '' : isEmptyValue(row[field]);

export default function FiadorGaranteSection({
  value,
  idExpediente,
  idDatosOperacion,
  disabled,
  canEdit,
  controles = EMPTY_CONTROLES_FIADOR_GARANTE,
  loadingControles = false,
  readOnlyFields,
  allowAdd = true,
  allowDelete = true,
  onChange,
  onWarn,
}: Props) {
  const generoOptions = controles.genero;
  const estadoCivilOptions = controles.estado_civil;
  const nacionalidadOptions = controles.nacionalidad;
  const relacionTitularOptions = controles.relacion_titular;
  const regionOptions = controles.region;
  const comunaOptions = controles.comuna;
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogMode, setDialogMode] = useState<DialogMode>('view');
  const [selected, setSelected] = useState<DatosOperacionFiadorGarante | null>(null);
  const dialogContentRef = useRef<HTMLDivElement>(null);

  const filteredComunaOptions = useMemo(() => {
    const regionCode = String(selected?.region ?? '').trim();
    if (!regionCode) return comunaOptions;
    return comunaOptions.filter((c) => {
      const code = String(c.code ?? '');
      return code === regionCode || code.startsWith(regionCode + '-');
    });
  }, [comunaOptions, selected?.region]);

  useEffect(() => {
    if (!selected?.region) return;
    const regionCode = String(selected.region).trim();
    if (!regionCode) return;
    const comunaVal = String(selected.comuna ?? '').trim();
    if (comunaVal && !comunaVal.startsWith(regionCode + '-') && comunaVal !== regionCode) {
      setSelected((prev) => prev ? { ...prev, comuna: null } : prev);
    }
  }, [selected?.region]);

  const canEditActions = canEdit && !disabled;
  const rows = useMemo(() => value?.filter((item) => item.row_status !== false) ?? [], [value]);

  const openCreate = () => {
    if (!canEditActions) return;
    setSelected(buildFiadorGaranteEmpty(idExpediente, idDatosOperacion));
    setDialogMode('create');
    setDialogVisible(true);
  };

  const openView = (row: DatosOperacionFiadorGarante) => {
    setSelected({ ...row });
    setDialogMode('view');
    setDialogVisible(true);
  };

  const openEdit = (row: DatosOperacionFiadorGarante) => {
    if (!canEditActions) return;
    setSelected({ ...row });
    setDialogMode('edit');
    setDialogVisible(true);
  };

  const closeDialog = () => {
    setDialogVisible(false);
    setSelected(null);
  };

  const updateField = <K extends keyof DatosOperacionFiadorGarante>(
    field: K,
    fieldValue: DatosOperacionFiadorGarante[K],
  ) => {
    setSelected((prev) => {
      if (!prev) return prev;
      return { ...prev, [field]: fieldValue };
    });
  };

  useEffect(() => {
    if (!selected) return;
    const areaCode = getAreaCode(selected.region, selected.comuna);
    if (!areaCode) return;

    const currentValue = String(selected.telefono_fijo ?? '').trim();
    const matchedCode = AREA_CODES_KNOWN.find((code) => currentValue.startsWith(code));

    // Sin código no hay nada que re-basar (el prefijo `(código)` se dibuja igual desde
    // la región/comuna). Y si el valor es SÓLO el código de área se limpia: era un
    // valor fantasma que hacía pasar la validación de obligatorio a un campo que en
    // pantalla se ve vacío.
    const digits = matchedCode ? currentValue.slice(matchedCode.length) : '';
    const newValue = matchedCode && digits ? areaCode + digits : '';

    if (newValue === currentValue) return;

    setSelected((prev) => (prev ? { ...prev, telefono_fijo: newValue } : prev));
  }, [selected?.region, selected?.comuna]);

  const saveRow = () => {
    if (!selected) return;

    const missingField = getMissingFiadorField(selected);
    if (missingField) {
      onWarn?.(`Debe completar el campo ${missingField}.`);
      focusFieldByKey(getMissingFiadorFieldKey(selected), dialogContentRef.current, 80);
      return;
    }

    // UX-007: el email se valida por formato cuando tiene valor.
    const emailError = describeEmailError(selected.email);
    if (emailError) {
      onWarn?.(`Email. ${emailError}`);
      focusFieldByKey('email', dialogContentRef.current, 80);
      return;
    }

    // UX-009: caracteres permitidos en los campos de texto libre.
    const textoError =
      describeNombrePersonaError(selected.nombres, 'Nombres. ') ??
      describeNombrePersonaError(selected.apellido_paterno, 'Apellido Paterno. ') ??
      describeNombrePersonaError(selected.apellido_materno, 'Apellido Materno. ') ??
      describeDireccionError(selected.direccion, 'Dirección. ');
    if (textoError) {
      onWarn?.(textoError);
      focusFieldByKey(
        describeNombrePersonaError(selected.nombres)
          ? 'nombres'
          : describeNombrePersonaError(selected.apellido_paterno)
            ? 'apellido_paterno'
            : describeNombrePersonaError(selected.apellido_materno)
              ? 'apellido_materno'
              : 'direccion',
        dialogContentRef.current,
        80,
      );
      return;
    }

    const normalized: DatosOperacionFiadorGarante = {
      ...selected,
      id_datos_operacion: idDatosOperacion,
      id_expediente: idExpediente,
      is_active: true,
      row_status: true,
    };

    if (dialogMode === 'create' || normalized.id_datos_operacion_fiador_garante <= 0) {
      onChange([
        ...value,
        {
          ...normalized,
          id_datos_operacion_fiador_garante:
            normalized.id_datos_operacion_fiador_garante < 0
              ? normalized.id_datos_operacion_fiador_garante
              : -Date.now(),
        },
      ]);
      closeDialog();
      return;
    }

    onChange(
      value.map((item) =>
        item.id_datos_operacion_fiador_garante === normalized.id_datos_operacion_fiador_garante
          ? normalized
          : item,
      ),
    );
    closeDialog();
  };

  const deleteRow = (row: DatosOperacionFiadorGarante) => {
    const id = row.id_datos_operacion_fiador_garante;

    if (id <= 0) {
      onChange(value.filter((item) => item.id_datos_operacion_fiador_garante !== id));
      return;
    }

    onChange(
      value.map((item) =>
        item.id_datos_operacion_fiador_garante === id
          ? { ...item, is_active: false, row_status: false }
          : item,
      ),
    );
  };

  const confirmDelete = (row: DatosOperacionFiadorGarante) => {
    if (!canEditActions) return;

    confirmDialog({
      message: `¿Está seguro de querer eliminar ${getName(row)}?`,
      header: 'Confirmar eliminación',
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: 'Sí, eliminar',
      rejectLabel: 'Cancelar',
      acceptClassName: 'p-button-danger',
      accept: () => deleteRow(row),
    });
  };

  const actionsTemplate = (row: DatosOperacionFiadorGarante) => (
    <div className="flex align-items-center justify-content-center gap-2">
      <Button type="button" icon="pi pi-eye" rounded text severity="info" onClick={() => openView(row)} />
      <Button type="button" icon="pi pi-pencil" rounded text severity="warning" disabled={!canEditActions} onClick={() => openEdit(row)} />
      {allowDelete && (
        <Button type="button" icon="pi pi-trash" rounded text severity="danger" disabled={!canEditActions} onClick={() => confirmDelete(row)} />
      )}
    </div>
  );

  const readOnlyDialog = dialogMode === 'view' || !canEditActions;
  const controlDisabled = readOnlyDialog || loadingControles;
  const isFieldReadOnly = (field: string): boolean =>
    (readOnlyFields ?? []).includes(field);

  const footer = (
    <div className="flex justify-end gap-2">
      <Button
        type="button"
        label={dialogMode === 'view' ? 'Cerrar' : 'Cancelar'}
        icon="pi pi-times"
        severity="secondary"
        outlined
        onClick={closeDialog}
      />
      {dialogMode !== 'view' && (
        <Button
          type="button"
          label="Aceptar"
          icon="pi pi-check"
          severity="success"
          onClick={saveRow}
        />
      )}
    </div>
  );

  return (
    <Card title="Datos del Fiador / Garante" className="shadow-sm border border-gray-200 rounded-xl">
      <ConfirmDialog />
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-3">
        <span className="text-sm text-gray-500">Registros asociados al expediente.</span>
        {allowAdd && (
          <Button
            type="button"
            label="Agregar"
            icon="pi pi-plus"
            severity="success"
            outlined
            disabled={!canEditActions}
            onClick={openCreate}
            className="btn-responsive"
          />
        )}
      </div>

      <DataTable
        key={`fiador-${canEditActions ? 'edit' : 'view'}`}
        value={rows}
        emptyMessage="No existen registros."
        paginator={rows.length > 5}
        rows={5}
        stripedRows
        rowHover
        className="text-sm datatable-presto"
          size="small"
      >
        <Column field="rut" header="RUT" body={(row) => renderResponsiveCell(row.rut, "RUT: ")} />
        <Column header="Nombre" body={(row) => renderResponsiveCell(getName(row), "Nombre: ")} />
        <Column header="Relación Titular" body={(row) => renderResponsiveCell(getCatalogDescription(relacionTitularOptions, row.relacion_titular), "Relación Titular: ")} />
        <Column field="telefono_movil" header="Teléfono Móvil" body={(row) => renderResponsiveCell(row.telefono_movil, "Teléfono Móvil: ")} />
        <Column field="email" header="Email" body={(row) => renderResponsiveCell(row.email, "Email: ")} />
        <Column key={`acciones-fiador-${canEditActions ? 'edit' : 'view'}`} header="Acciones" body={(row) => renderResponsiveCell(actionsTemplate(row), "Acciones: ")} style={{ width: '11rem', textAlign: 'center' }} />
      </DataTable>

      <Dialog
        header={`${dialogMode === 'view' ? 'Detalle' : dialogMode === 'edit' ? 'Editar' : 'Nuevo'} Fiador / Garante`}
        visible={dialogVisible}
        modal
        className="w-full md:w-10/12 lg:w-8/12"
        footer={footer}
        onHide={closeDialog}
      >
        <div ref={dialogContentRef}>
        {selected && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="flex flex-col gap-1" data-field="rut">
              <label className="font-semibold text-sm">RUT<RequiredMark /></label>
              <InputText className="form-input-presto w-full" maxLength={fiadorLimitOf('rut')} value={selected.rut ?? ''} disabled={controlDisabled || isFieldReadOnly('rut')} placeholder="12345678-9" onChange={(e) => updateField('rut', formatRutSinPuntos(e.target.value))} />
            </div>
            <div className="flex flex-col gap-1" data-field="nombres">
              <label className="font-semibold text-sm">Nombres<RequiredMark /></label>
              <InputText className="form-input-presto w-full" maxLength={fiadorLimitOf('nombres')} value={selected.nombres ?? ''} disabled={controlDisabled || isFieldReadOnly('nombres')} onChange={(e) => updateField('nombres', sanitizeNombrePersona(e.target.value))} />
            </div>
            <div className="flex flex-col gap-1" data-field="apellido_paterno">
              <label className="font-semibold text-sm">Apellido Paterno<RequiredMark /></label>
              <InputText className="form-input-presto w-full" maxLength={fiadorLimitOf('apellido_paterno')} value={selected.apellido_paterno ?? ''} disabled={controlDisabled || isFieldReadOnly('apellido_paterno')} onChange={(e) => updateField('apellido_paterno', sanitizeNombrePersona(e.target.value))} />
            </div>
            <div className="flex flex-col gap-1" data-field="apellido_materno">
              <label className="font-semibold text-sm">Apellido Materno<RequiredMark /></label>
              <InputText className="form-input-presto w-full" maxLength={fiadorLimitOf('apellido_materno')} value={selected.apellido_materno ?? ''} disabled={controlDisabled || isFieldReadOnly('apellido_materno')} onChange={(e) => updateField('apellido_materno', sanitizeNombrePersona(e.target.value))} />
            </div>
            <div className="flex flex-col gap-1" data-field="fecha_nacimiento">
              <label className="font-semibold text-sm">Fecha Nacimiento<RequiredMark /></label>
              <Calendar className="calendar-presto" value={parseDate(selected.fecha_nacimiento)} disabled={controlDisabled || isFieldReadOnly('fecha_nacimiento')} showIcon dateFormat="dd/mm/yy" minDate={minFechaNacimiento()} maxDate={maxFechaNacimiento()} yearRange={yearRangeNacimiento()} viewDate={viewDateNacimiento(selected.fecha_nacimiento)} onChange={(e) => updateField('fecha_nacimiento', toIso(e.value as Date | null))} />
            </div>
            <div className="flex flex-col gap-1" data-field="genero">
              <label className="font-semibold text-sm">Género<RequiredMark /></label>
              <Dropdown className="form-dropdown-presto w-full" value={selected.genero ?? null} options={generoOptions} optionLabel="description" optionValue="code" disabled={controlDisabled || isFieldReadOnly('genero')} placeholder="Seleccione" onChange={(e) => updateField('genero', e.value)} />
            </div>
            <div className="flex flex-col gap-1" data-field="estado_civil">
              <label className="font-semibold text-sm">Estado Civil<RequiredMark /></label>
              <Dropdown className="form-dropdown-presto w-full" value={selected.estado_civil ?? null} options={estadoCivilOptions} optionLabel="description" optionValue="code" disabled={controlDisabled || isFieldReadOnly('estado_civil')} placeholder="Seleccione" onChange={(e) => updateField('estado_civil', e.value)} />
            </div>
            <div className="flex flex-col gap-1" data-field="nacionalidad">
              <label className="font-semibold text-sm">Nacionalidad<RequiredMark /></label>
              <Dropdown className="form-dropdown-presto w-full" value={selected.nacionalidad ?? null} options={nacionalidadOptions} optionLabel="description" optionValue="code" disabled={controlDisabled || isFieldReadOnly('nacionalidad')} placeholder="Seleccione" onChange={(e) => updateField('nacionalidad', e.value)} />
            </div>
            <div className="flex flex-col gap-1" data-field="profesion">
              <label className="font-semibold text-sm">Profesión<RequiredMark /></label>
              <InputText className="form-input-presto w-full" maxLength={fiadorLimitOf('profesion')} value={selected.profesion ?? ''} disabled={controlDisabled || isFieldReadOnly('profesion')} onChange={(e) => updateField('profesion', e.target.value)} />
            </div>
            <div className="flex flex-col gap-1" data-field="relacion_titular">
              <label className="font-semibold text-sm">Relación Titular<RequiredMark /></label>
              <Dropdown className="form-dropdown-presto w-full" value={selected.relacion_titular ?? null} options={relacionTitularOptions} optionLabel="description" optionValue="code" disabled={controlDisabled || isFieldReadOnly('relacion_titular')} placeholder="Seleccione" onChange={(e) => updateField('relacion_titular', e.value)} />
            </div>
            <div className="flex flex-col gap-1" data-field="telefono_fijo">
              <label className="font-semibold text-sm">Teléfono Fijo<RequiredMark /></label>
              {(() => {
                const { code, digits } = splitTelefonoFijo(
                  selected.telefono_fijo,
                  selected.region,
                  selected.comuna,
                );

                return (
                  <div className="flex items-center gap-1">
                    {code && <span className="font-bold whitespace-nowrap">({code})</span>}
                    <InputText className="form-input-presto w-full"
                      value={digits}
                      disabled={controlDisabled || isFieldReadOnly('telefono_fijo')}
                      placeholder={telefonoFijoPlaceholder(code)}
                      maxLength={telefonoFijoDigitos(code)}
                      onChange={(e) =>
                        updateField('telefono_fijo', (code || '') + sanitizePhone(e.target.value, telefonoFijoDigitos(code)))
                      }
                    />
                  </div>
                );
              })()}
            </div>
            <div className="flex flex-col gap-1" data-field="telefono_movil">
              <label className="font-semibold text-sm">Teléfono Móvil<RequiredMark /></label>
              <InputText className="form-input-presto w-full" maxLength={fiadorLimitOf('telefono_movil')} value={selected.telefono_movil ?? ''} disabled={controlDisabled || isFieldReadOnly('telefono_movil')} placeholder={TELEFONO_MOVIL_PLACEHOLDER} onChange={(e) => updateField('telefono_movil', sanitizePhone(e.target.value, fiadorLimitOf('telefono_movil')))} />
            </div>
            <div className="flex flex-col gap-1" data-field="email">
              <label className="font-semibold text-sm">Email<RequiredMark /></label>
              <InputText className="form-input-presto w-full" maxLength={fiadorLimitOf('email')} value={selected.email ?? ''} disabled={controlDisabled || isFieldReadOnly('email')} placeholder={EMAIL_PLACEHOLDER} onChange={(e) => updateField('email', e.target.value)} />
            </div>
            <div className="flex flex-col gap-1 md:col-span-2 xl:col-span-3" data-field="direccion">
              <label className="font-semibold text-sm">Dirección<RequiredMark /></label>
              <InputText className="form-input-presto w-full" maxLength={fiadorLimitOf('direccion')} value={selected.direccion ?? ''} disabled={controlDisabled || isFieldReadOnly('direccion')} onChange={(e) => updateField('direccion', sanitizeDireccion(e.target.value))} />
            </div>
            <div className="flex flex-col gap-1 md:col-span-1 xl:col-span-1" data-field="region">
              <label className="font-semibold text-sm">Región<RequiredMark /></label>
              <Dropdown className="form-dropdown-presto w-full" value={selected.region ?? null} options={regionOptions} optionLabel="description" optionValue="code" disabled={controlDisabled || isFieldReadOnly('region')} placeholder="Seleccione" onChange={(e) => updateField('region', e.value)} />
            </div>
            <div className="flex flex-col gap-1 md:col-span-1 xl:col-span-1" data-field="comuna">
              <label className="font-semibold text-sm">Comuna<RequiredMark /></label>
              <Dropdown className="form-dropdown-presto w-full" value={selected.comuna ?? null} options={filteredComunaOptions} optionLabel="description" optionValue="code" disabled={controlDisabled || isFieldReadOnly('comuna')} placeholder="Seleccione" onChange={(e) => updateField('comuna', e.value)} />
            </div>
          </div>
        )}
        </div>
      </Dialog>
    </Card>
  );
}
