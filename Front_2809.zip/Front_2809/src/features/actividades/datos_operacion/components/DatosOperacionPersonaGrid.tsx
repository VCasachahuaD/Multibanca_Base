import type { ReactNode } from 'react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { Card } from 'primereact/card';
import { Column } from 'primereact/column';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { DataTable } from 'primereact/datatable';
import { Dialog } from 'primereact/dialog';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';

import RequiredMark from '@/shared/components/RequiredMark';

import type {
  DatosOperacionComprador,
  DatosOperacionVendedor,
} from '../models/datos_operacion';
import {
  buildCompradorEmpty,
  buildVendedorEmpty,
} from '../models/datos_operacion';
import { limitOf } from '../models/fieldLimits';
import {
  TELEFONO_MOVIL_PLACEHOLDER,
  telefonoFijoDigitos,
  telefonoFijoPlaceholder,
} from '@/shared/utils/fieldLimits';
import {
  EMPTY_CONTROLES_COMPRADOR,
  EMPTY_CONTROLES_VENDEDOR,
  type CatalogoOption,
  type ControlesComprador,
  type ControlesVendedor,
} from '../models/catalogo';
import { focusFieldByKey } from '../utils/fieldFocus';
import { describeRutError, formatRutSinPuntos, normalizeRut, rutComparableKey } from '@/shared/utils/rut';
import {
  maxFechaNacimiento,
  minFechaNacimiento,
  viewDateNacimiento,
  yearRangeNacimiento,
} from '@/shared/utils/dateCoherence';
import {
  describeEmailError,
  EMAIL_PLACEHOLDER,
  sanitizePhone,
} from '@/shared/utils/chileanValidators';
import {
  describeDireccionError,
  describeNombrePersonaError,
  describeRazonSocialError,
  sanitizeDireccion,
  sanitizeNombrePersona,
  sanitizeRazonSocial,
} from '@/shared/utils/textValidators';

const renderResponsiveCell = (value: ReactNode, titulo: string) => <div data-titulo={titulo}>{value ?? ""}</div>;

type PersonaRow = DatosOperacionComprador | DatosOperacionVendedor;

type PersonaRequiredField =
  | 'rut'
  | 'razon_social'
  | 'nombres'
  | 'apellido_paterno'
  | 'apellido_materno'
  | 'direccion'
  | 'region'
  | 'comuna'
  | 'direccion_env_esc'
  | 'region_env_esc'
  | 'comuna_env_esc'
  | 'tipo_dir_dividendo'
  | 'direccion_env_div'
  | 'region_env_div'
  | 'comuna_env_div'
  | 'telefono'
  | 'telefono_comercial'
  | 'telefono_movil'
  | 'profesion'
  | 'email'
  | 'email2'
  | 'relacion_titular';


type DialogMode = 'view' | 'edit' | 'create';

type Props<T extends PersonaRow> = {
  title: string;
  type: 'comprador' | 'vendedor';
  value: T[];
  idExpediente: number;
  idDatosOperacion: number;
  disabled: boolean;
  canEdit: boolean;
  controles?: ControlesComprador | ControlesVendedor;
  loadingControles?: boolean;
  /** Nombres de campos que no se pueden editar (solo lectura). */
  readOnlyFields?: string[];
  /** Permite agregar filas (solo vendedor). */
  allowAdd?: boolean;
  /** Permite eliminar filas (solo vendedor). */
  allowDelete?: boolean;
  onChange: (rows: T[]) => void;
  onWarn?: (message: string) => void;
};

const parseDate = (value?: string | null): Date | null => {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const toIso = (value: Date | null | undefined): string | null => {
  if (!value) return null;
  return value.toISOString();
};

const getRowId = (row: PersonaRow): number => {
  if ('id_datos_operacion_comprador' in row) return row.id_datos_operacion_comprador;
  return row.id_datos_operacion_vendedor;
};

const setRowId = <T extends PersonaRow>(row: T, id: number): T => {
  if ('id_datos_operacion_comprador' in row) {
    return { ...row, id_datos_operacion_comprador: id } as T;
  }
  return { ...row, id_datos_operacion_vendedor: id } as T;
};

const fullName = (row: PersonaRow) =>
  [row.nombres, row.apellido_paterno, row.apellido_materno]
    .filter(Boolean)
    .join(' ')
    .trim() || row.razon_social || row.rut || 'Registro';

const isEmptyValue = (value: unknown): boolean =>
  value === null || value === undefined || (typeof value === 'string' && value.trim() === '');

const normalizeCatalogCode = (value: unknown): string =>
  value === null || value === undefined ? '' : String(value).trim();

const getCatalogDescription = (options: CatalogoOption[], value: unknown): string => {
  const normalizedValue = normalizeCatalogCode(value);
  if (!normalizedValue) return '';

  const option = options.find((item) => {
    const normalizedCode = normalizeCatalogCode(item.code);
    return (
      normalizedCode === normalizedValue ||
      normalizedCode.replace(/^0+/, '') === normalizedValue.replace(/^0+/, '')
    );
  });

  return option?.description ?? option?.code ?? normalizedValue;
};

/**
 * Determina si la persona es jurídica.
 *
 * IMPORTANTE: el `code` del catálogo de tipo de persona es numérico ('01'/'02'),
 * por lo que NO alcanza con revisar el código: la detección se hace sobre la
 * DESCRIPCIÓN ('Natural'/'Jurídico') resuelta desde el catálogo. Si no se recibe
 * catálogo, cae a un fallback por código y, en último caso, por datos
 * (razón social cargada sin nombres).
 */
export const isPersonaJuridica = (
  row: PersonaRow,
  tipoPersonaOptions?: CatalogoOption[] | null,
): boolean => {
  const descripcion = getCatalogDescription(
    tipoPersonaOptions ?? [],
    row.tipo_persona,
  ).toLowerCase();

  if (descripcion.includes('jur')) return true;
  if (descripcion.includes('nat')) return false;

  const tipoPersona = String(row.tipo_persona ?? '').toLowerCase();
  if (tipoPersona.includes('jur')) return true;
  if (tipoPersona.includes('nat')) return false;

  const razonSocial = String(row.razon_social ?? '').trim();
  const nombres = String(row.nombres ?? '').trim();
  return !!razonSocial && !nombres;
};

const labelTextByField: Record<string, string> = {
  rut: 'RUT',
  tipo_persona: 'Tipo Persona',
  razon_social: 'Razón Social',
  nombres: 'Nombres',
  apellido_paterno: 'Apellido Paterno',
  apellido_materno: 'Apellido Materno',
  direccion: 'Dirección',
  region: 'Región',
  comuna: 'Comuna',
  direccion_env_esc: 'Dirección Envío Escritura',
  region_env_esc: 'Región Envío Escritura',
  comuna_env_esc: 'Comuna Envío Escritura',
  tipo_dir_dividendo: 'Tipo Dirección Dividendo',
  direccion_env_div: 'Dirección Envío Dividendo',
  region_env_div: 'Región Envío Dividendo',
  comuna_env_div: 'Comuna Envío Dividendo',
  telefono: 'Teléfono',
  telefono_comercial: 'Teléfono Comercial',
  telefono_movil: 'Teléfono Móvil',
  profesion: 'Profesión',
  email: 'Email',
  email2: 'Email 2',
  relacion_titular: 'Relación Titular',
};

/**
 * Mensaje accionable del RUT de una persona (el RUT vacío también es error).
 * `normalizeRut` tolera los RUT sin puntos o sin guion (dato legado), y devuelve
 * `null` solo cuando el RUT es válido.
 */
export const getPersonaRutErrorMessage = (row: PersonaRow): string | null => {
  const error = describeRutError(normalizeRut(row.rut));

  return error ? `RUT. ${error}` : null;
};

/**
 * Campos obligatorios de una persona, en el ORDEN VISUAL del diálogo.
 *
 * Se reporta y se enfoca sólo el PRIMER faltante, así que el orden importa: debe ir de
 * arriba hacia abajo igual que el JSX (rut → tipo persona → razón social | nombres,
 * apellidos y profesión → relación titular → tipo dirección dividendo → dirección,
 * región y comuna → teléfonos → emails → envío escritura → envío dividendo).
 */
const getRequiredPersonaFields = (
  type: 'comprador' | 'vendedor',
  row: PersonaRow,
  tipoPersonaOptions?: CatalogoOption[] | null,
): PersonaRequiredField[] => {
  const juridica = isPersonaJuridica(row, tipoPersonaOptions);

  // El tipo de persona no es obligatorio, pero define qué campos de identificación se ven.
  const identificacion: PersonaRequiredField[] = juridica
    ? ['razon_social']
    : ['nombres', 'apellido_paterno', 'apellido_materno', 'profesion'];

  const cabecera: PersonaRequiredField[] = ['rut', ...identificacion, 'relacion_titular'];

  const ubicacion: PersonaRequiredField[] = ['direccion', 'region', 'comuna', 'telefono'];

  // Teléfono comercial, teléfono móvil y Email 2 sólo existen en persona natural.
  const contacto: PersonaRequiredField[] = juridica
    ? ['email']
    : ['telefono_comercial', 'telefono_movil', 'email', 'email2'];

  if (type === 'comprador') {
    return [
      ...cabecera,
      'tipo_dir_dividendo',
      ...ubicacion,
      ...contacto,
      'direccion_env_esc',
      'region_env_esc',
      'comuna_env_esc',
      'direccion_env_div',
      'region_env_div',
      'comuna_env_div',
    ];
  }

  // Vendedor: no tiene envío de dividendo, y el de escritura sólo se muestra si es
  // persona jurídica.
  const envioEscritura: PersonaRequiredField[] = juridica
    ? ['direccion_env_esc', 'region_env_esc', 'comuna_env_esc']
    : [];

  return [...cabecera, ...ubicacion, ...contacto, ...envioEscritura];
};

export const getMissingPersonaField = (
  type: 'comprador' | 'vendedor',
  row: PersonaRow,
  tipoPersonaOptions?: CatalogoOption[] | null,
): string | null => {
  const requiredFields = getRequiredPersonaFields(type, row, tipoPersonaOptions);
  for (const field of requiredFields) {
    if (esObligatorioFaltante(row, field)) {
      return labelTextByField[String(field)] ?? String(field);
    }
  }
  return null;
};

export const getMissingPersonaFieldKey = (
  type: 'comprador' | 'vendedor',
  row: PersonaRow,
  tipoPersonaOptions?: CatalogoOption[] | null,
): string | null => {
  const requiredFields = getRequiredPersonaFields(type, row, tipoPersonaOptions);
  for (const field of requiredFields) {
    if (esObligatorioFaltante(row, field)) {
      return String(field);
    }
  }
  return null;
};

const getAreaCode = (regionCode: string | null | undefined, comunaCode: string | null | undefined): string | null => {
  if (!regionCode) return null;
  const r = String(regionCode).trim();
  const c = String(comunaCode ?? '').trim();

  switch (r) {
    case '07': return '2';    // Metropolitana
    case '08': return '72';   // O'Higgins
    case '10': return '42';   // Ñuble
    case '12': return '45';   // Araucanía
    case '13': return '63';   // Los Ríos
    case '15': return '67';   // Aysén
    case '16': return '61';   // Magallanes
    case '06':
      if (c === '06-18' || c === '06-32') return '34';
      if (c === '06-23' || c === '06-26') return '33';
      return null;
    case '09':
      if (c === '09-10' || c === '09-01') return '73';
      if (c === '09-06' || c === '09-26') return '75';
      return null;
    case '11':
      if (c === '11-07') return '41';
      return null;
    case '14':
      if (c === '14-16') return '64';
      if (c === '14-13') return '65';
      return null;
    default: return null;
  }
};

/** Códigos de área de Chile: 1 dígito en RM, 2 en regiones. */
const AREA_CODES_KNOWN = ['2', '33', '34', '41', '42', '45', '61', '63', '64', '65', '67', '72', '73', '75'];

/**
 * Separa un teléfono FIJO (input compuesto) en código de área + dígitos locales.
 * El código puede venir ya guardado en el valor (dato existente) o deducirse de la
 * región/comuna mientras el usuario escribe; la caja del input muestra `digits`.
 */
const splitTelefonoFijo = (
  value: unknown,
  region: string | null | undefined,
  comuna: string | null | undefined,
): { code: string | null; digits: string } => {
  const val = String(value ?? '').trim();
  const matchedCode = AREA_CODES_KNOWN.find((c) => val.startsWith(c));
  const regionCode = getAreaCode(region, comuna);
  const code = matchedCode ?? regionCode ?? null;
  const digits = matchedCode ? val.slice(matchedCode.length) : regionCode ? '' : val;
  return { code, digits };
};

/**
 * Dígitos locales del Teléfono Comercial (sin el código de área).
 * El valor guardado INCLUYE el código, así que "tener valor" no es "teléfono completo":
 * un campo con sólo `2` se ve VACÍO en pantalla —la caja muestra los dígitos y el `(2)`
 * se dibuja aparte— y por eso la validación de obligatorio lo daba por lleno.
 */
export const getTelefonoComercialDigitos = (row: PersonaRow): string =>
  splitTelefonoFijo(row.telefono_comercial, row.region, row.comuna).digits;

/** Igual que el resto de los obligatorios, pero el teléfono compuesto exige DÍGITOS. */
const esObligatorioFaltante = (row: PersonaRow, field: PersonaRequiredField): boolean =>
  field === 'telefono_comercial' ? getTelefonoComercialDigitos(row) === '' : isEmptyValue(row[field]);

export default function DatosOperacionPersonaGrid<T extends PersonaRow>({
  title,
  type,
  value,
  idExpediente,
  idDatosOperacion,
  disabled,
  canEdit,
  controles,
  loadingControles = false,
  readOnlyFields,
  allowAdd = true,
  allowDelete = true,
  onChange,
  onWarn,
}: Props<T>) {
  const isComprador = type === 'comprador';
  const isVendedor = type === 'vendedor';

  const resolvedControles =
    controles ??
    (type === 'vendedor' ? EMPTY_CONTROLES_VENDEDOR : EMPTY_CONTROLES_COMPRADOR);
  
  const tipoPersonaOptions = type === 'comprador' 
    ? (resolvedControles as ControlesComprador).tipo_comprador ?? []
    : (resolvedControles as ControlesVendedor).tipo_vendedor ?? [];
  const generoOptions = resolvedControles.genero;
  const estadoCivilOptions = resolvedControles.estado_civil;
  const nacionalidadOptions = resolvedControles.nacionalidad;
  const relacionTitularOptions = resolvedControles.relacion_titular;
  const tipoDireccionDividendoOptions =
    'tipo_direccion_dividendo' in resolvedControles
      ? resolvedControles.tipo_direccion_dividendo
      : [];
  const regionOptions = resolvedControles.region;
  const comunaOptions = resolvedControles.comuna;
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogMode, setDialogMode] = useState<DialogMode>('view');
  const [selected, setSelected] = useState<T | null>(null);
  const editingRowRef = useRef<T | null>(null);
  // Índice de la fila que se está editando, capturado al abrir el diálogo (ver saveRow).
  const editingIndexRef = useRef(-1);
  const dialogContentRef = useRef<HTMLDivElement>(null);

  const filteredComunaOptions = useMemo(() => {
    const regionCode = String(selected?.region ?? '').trim();
    if (!regionCode) return comunaOptions;
    return comunaOptions.filter((c) => {
      const code = String(c.code ?? '');
      return code === regionCode || code.startsWith(regionCode + '-');
    });
  }, [comunaOptions, selected?.region]);

  const filteredComunaEnvEscOptions = useMemo(() => {
    const regionCode = String(selected?.region_env_esc ?? '').trim();
    if (!regionCode) return comunaOptions;
    return comunaOptions.filter((c) => {
      const code = String(c.code ?? '');
      return code === regionCode || code.startsWith(regionCode + '-');
    });
  }, [comunaOptions, selected?.region_env_esc]);

  const filteredComunaEnvDivOptions = useMemo(() => {
    const regionCode = String(selected?.region_env_div ?? '').trim();
    if (!regionCode) return comunaOptions;
    return comunaOptions.filter((c) => {
      const code = String(c.code ?? '');
      return code === regionCode || code.startsWith(regionCode + '-');
    });
  }, [comunaOptions, selected?.region_env_div]);

  const canEditActions = canEdit && !disabled;
  const rows = useMemo(() => value?.filter((item) => item.row_status !== false) ?? [], [value]);

  const buildEmpty = (): T => {
    if (type === 'comprador') {
      return buildCompradorEmpty(idExpediente, idDatosOperacion) as T;
    }
    return buildVendedorEmpty(idExpediente, idDatosOperacion) as T;
  };

  const openCreate = () => {
    if (!canEditActions) return;
    editingRowRef.current = null;
    editingIndexRef.current = -1;
    setSelected(buildEmpty());
    setDialogMode('create');
    setDialogVisible(true);
  };

  const autocompletarCamposEnvio = (row: T): T => {
    return {
      ...row,
      direccion_env_esc: row.direccion_env_esc || row.direccion || '',
      region_env_esc: row.region_env_esc || row.region || null,
      comuna_env_esc: row.comuna_env_esc || row.comuna || null,
      direccion_env_div: row.direccion_env_div || row.direccion || '',
      region_env_div: row.region_env_div || row.region || null,
      comuna_env_div: row.comuna_env_div || row.comuna || null,
    };
  };

  const openView = (row: T) => {
    editingRowRef.current = null;
    editingIndexRef.current = -1;
    setSelected(autocompletarCamposEnvio(row));
    setDialogMode('view');
    setDialogVisible(true);
  };

  const openEdit = (row: T) => {
    if (!canEditActions) return;
    editingRowRef.current = row;
    // Se captura el índice AHORA: si el DataTable entrega una referencia vieja de la
    // fila, en saveRow ya no se la puede ubicar por identidad (ver saveRow).
    editingIndexRef.current = value.findIndex((item) => item === row);
    setSelected(autocompletarCamposEnvio(row));
    setDialogMode('edit');
    setDialogVisible(true);
  };

  const closeDialog = () => {
    setDialogVisible(false);
    setSelected(null);
    editingRowRef.current = null;
    editingIndexRef.current = -1;
  };

  const updateField = <K extends keyof T>(field: K, fieldValue: T[K]) => {
    setSelected((prev) => {
      if (!prev) return prev;
      return { ...prev, [field]: fieldValue };
    });
  };

  useEffect(() => {
    if (!selected) return;
    if (!isVendedor && !isComprador) return;

    const areaCode = getAreaCode(selected.region, selected.comuna);
    if (!areaCode) return;

    const currentValue = String(selected.telefono_comercial ?? '').trim();
    const matchedCode = AREA_CODES_KNOWN.find((code) => currentValue.startsWith(code));

    // Sin código no hay nada que re-basar (el prefijo `(código)` se dibuja igual desde
    // la región/comuna). Y si el valor es SÓLO el código de área se limpia: era un
    // valor fantasma que hacía pasar la validación de obligatorio a un campo que en
    // pantalla se ve vacío.
    const digits = matchedCode ? currentValue.slice(matchedCode.length) : '';
    const newValue = matchedCode && digits ? areaCode + digits : '';

    if (newValue === currentValue) return;

    setSelected((prev) => {
      if (!prev) return prev;
      return { ...prev, telefono_comercial: newValue as T[keyof T] };
    });
  }, [selected?.region, selected?.comuna]);

  useEffect(() => {
    if (!selected) return;
    const pairs: [string | null | undefined, (keyof T)][] = [
      [selected.region, 'comuna'],
      [selected.region_env_esc, 'comuna_env_esc'],
      [selected.region_env_div, 'comuna_env_div'],
    ];

    const clears: Partial<T> = {} as Partial<T>;
    for (const [regionVal, comunaField] of pairs) {
      const regionCode = String(regionVal ?? '').trim();
      if (!regionCode) continue;
      const comunaVal = String(selected[comunaField] ?? '').trim();
      if (comunaVal && !comunaVal.startsWith(regionCode + '-') && comunaVal !== regionCode) {
        (clears as Record<string, unknown>)[String(comunaField)] = null;
      }
    }

    if (Object.keys(clears).length > 0) {
      setSelected((prev) => {
        if (!prev) return prev;
        return { ...prev, ...clears };
      });
    }
  }, [selected?.region, selected?.region_env_esc, selected?.region_env_div]);

  const saveRow = () => {
    if (!selected) return;

    const rutMessage = getPersonaRutErrorMessage(selected);
    if (rutMessage) {
      onWarn?.(rutMessage);
      focusFieldByKey('rut', dialogContentRef.current, 80);
      return;
    }

    const missingField = getMissingPersonaField(type, selected, tipoPersonaOptions);
    if (missingField) {
      onWarn?.(`Debe completar el campo ${missingField}.`);
      focusFieldByKey(
        getMissingPersonaFieldKey(type, selected, tipoPersonaOptions),
        dialogContentRef.current,
        80,
      );
      return;
    }

    // UX-007: el email se valida por formato cuando tiene valor.
    const emailError =
      describeEmailError(selected.email) ?? describeEmailError(selected.email2);
    if (emailError) {
      const esEmail2 = !!describeEmailError(selected.email2);
      onWarn?.(`${esEmail2 ? 'Email 2' : 'Email'}. ${emailError}`);
      focusFieldByKey(
        esEmail2 ? 'email2' : 'email',
        dialogContentRef.current,
        80,
      );
      return;
    }

    // UX-009: caracteres permitidos en los campos de texto libre.
    const textoError =
      describeRazonSocialError(selected.razon_social, 'Razón Social. ') ??
      describeNombrePersonaError(selected.nombres, 'Nombres. ') ??
      describeNombrePersonaError(selected.apellido_paterno, 'Apellido Paterno. ') ??
      describeNombrePersonaError(selected.apellido_materno, 'Apellido Materno. ') ??
      describeDireccionError(selected.direccion, 'Dirección. ');
    if (textoError) {
      onWarn?.(textoError);
      focusFieldByKey(
        describeRazonSocialError(selected.razon_social)
          ? 'razon_social'
          : describeNombrePersonaError(selected.nombres)
            ? 'nombres'
            : describeNombrePersonaError(selected.apellido_paterno)
              ? 'apellido_paterno'
              : describeNombrePersonaError(selected.apellido_materno)
                ? 'apellido_materno'
                : 'direccion',
        dialogContentRef.current,
        80,
      );
      return;
    }

    const selectedId = getRowId(selected);
    const normalized = {
      ...selected,
      id_datos_operacion: idDatosOperacion,
      id_expediente: idExpediente,
      is_active: true,
      row_status: true,
    } as T;

    // Identificación de la fila que se está editando.
    // La identidad del objeto es lo primero, pero NO alcanza: si el DataTable entrega
    // una referencia vieja (o el padre vuelve a hidratar el formulario), la fila queda
    // "desconocida" y, como un comprador que todavía no existe en 5.4 tiene id 0, el
    // guardado caía en el camino de CREAR: el chequeo de duplicado encontraba la MISMA
    // fila que se estaba editando y respondía "ya se encuentra registrado".
    const editedRow = editingRowRef.current;
    let existingIndex = editedRow ? value.findIndex((item) => item === editedRow) : -1;

    // Índice capturado al abrir el diálogo (es 0 o más sólo si la identidad se pudo
    // resolver en ese momento, así que apunta exactamente a la misma fila).
    if (existingIndex < 0 && editedRow && editingIndexRef.current >= 0) {
      existingIndex = editingIndexRef.current;
    }

    if (existingIndex < 0 && selectedId !== 0) {
      existingIndex = value.findIndex((item) => getRowId(item) === selectedId);
    }

    // Último recurso: el RUT original de la fila abierta, que es la clave de negocio con
    // la que la grilla ya garantiza que no hay dos filas activas iguales.
    if (existingIndex < 0 && editedRow) {
      const claveRut = rutComparableKey(editedRow.rut);
      if (claveRut !== '') {
        existingIndex = value.findIndex((item) => rutComparableKey(item.rut) === claveRut);
      }
    }

    if (existingIndex >= 0 && existingIndex < value.length) {
      onChange(value.map((item, index) => (index === existingIndex ? normalized : item)));
      closeDialog();
      return;
    }

    // Una EDICIÓN que no se pudo ubicar NO debe seguir al camino de "crear": ahí el
    // chequeo de duplicado compara contra la fila que se está editando y el mensaje
    // "ya se encuentra registrado" es engañoso.
    if (editedRow || selectedId > 0) {
      onWarn?.('No se pudo localizar el registro que desea editar. Cierre el diálogo y vuelva a abrirlo.');
      return;
    }

    const rutDuplicado = value.find(
      (item) => item.row_status !== false && item.rut && item.rut === selected.rut,
    );
    if (rutDuplicado) {
      onWarn?.(`El RUT ${selected.rut} ya se encuentra registrado.`);
      return;
    }

    const localId = -Date.now();
    onChange([...value, setRowId(normalized, localId)]);
    closeDialog();
  };

  const deleteRow = (row: T) => {
    const rowId = getRowId(row);
    if (rowId <= 0) {
      onChange(value.filter((item) => getRowId(item) !== rowId));
      return;
    }
    onChange(
      value.map((item) =>
        getRowId(item) === rowId
          ? { ...item, is_active: false, row_status: false }
          : item,
      ),
    );
  };

  const confirmDelete = (row: T) => {
    if (!canEditActions) return;
    confirmDialog({
      message: `¿Está seguro de querer eliminar ${fullName(row)}?`,
      header: 'Confirmar eliminación',
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: 'Sí, eliminar',
      rejectLabel: 'Cancelar',
      acceptClassName: 'p-button-danger',
      accept: () => deleteRow(row),
    });
  };

  const actionsTemplate = (row: T) => (
    <div className="flex align-items-center justify-content-center gap-2">
      <Button
        type="button"
        icon="pi pi-eye"
        rounded
        text
        severity="info"
        tooltip="Ver detalle"
        onClick={() => openView(row)}
      />
      <Button
        type="button"
        icon="pi pi-pencil"
        rounded
        text
        severity="warning"
        tooltip="Editar"
        disabled={!canEditActions}
        onClick={() => openEdit(row)}
      />
      {isVendedor && allowDelete && (
        <Button
          type="button"
          icon="pi pi-trash"
          rounded
          text
          severity="danger"
          tooltip="Eliminar"
          disabled={!canEditActions}
          onClick={() => confirmDelete(row)}
        />
      )}
    </div>
  );

  const readOnlyDialog = dialogMode === 'view' || !canEditActions;
  const controlDisabled = readOnlyDialog || loadingControles;
  const isFieldReadOnly = (field: string): boolean =>
    (readOnlyFields ?? []).includes(field);

  const footer = (
    <div className="flex justify-end gap-2">
      <Button
        type="button"
        label={dialogMode === 'view' ? 'Cerrar' : 'Cancelar'}
        icon="pi pi-times"
        severity="secondary"
        outlined
        onClick={closeDialog}
      />
      {dialogMode !== 'view' && (
        <Button
          type="button"
          label="Aceptar"
          icon="pi pi-check"
          severity="success"
          onClick={saveRow}
        />
      )}
    </div>
  );

  return (
    <Card title={title} className="shadow-sm border border-gray-200 rounded-xl">
      <ConfirmDialog />

      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-3">
        <span className="text-sm text-gray-500">
          Registros asociados al expediente.
        </span>
        {isVendedor && allowAdd && (
          <Button
            type="button"
            label="Agregar"
            icon="pi pi-plus"
            severity="success"
            outlined
            disabled={!canEditActions}
            onClick={openCreate}
            className="btn-responsive"
          />
        )}
      </div>

      <DataTable
        key={`${type}-${canEditActions ? 'edit' : 'view'}`}
        value={rows}
        emptyMessage="No existen registros."
        paginator={rows.length > 5}
        rows={5}
        stripedRows
        rowHover
        className="text-sm datatable-presto"
        size="small"
      >
        <Column field="rut" header="RUT" body={(row) => renderResponsiveCell(row.rut, "RUT: ")} />
        <Column header="Tipo Persona" body={(row) => renderResponsiveCell(getCatalogDescription(tipoPersonaOptions, row.tipo_persona), "Tipo Persona: ")} />
        <Column field="razon_social" header="Razón Social" body={(row) => renderResponsiveCell(row.razon_social, "Razón Social: ")} />
        <Column header="Nombre" body={(row) => renderResponsiveCell(isPersonaJuridica(row, tipoPersonaOptions) ? '' : fullName(row), "Nombre: ")} />
        <Column header="Relación Titular" body={(row) => renderResponsiveCell(getCatalogDescription(relacionTitularOptions, row.relacion_titular), "Relación Titular: ")} />
        <Column
          key={`acciones-${type}-${canEditActions ? 'edit' : 'view'}`}
          header="Acciones"
          body={(row) => renderResponsiveCell(actionsTemplate(row), "Acciones: ")}
          style={{ width: isVendedor ? '14rem' : '11rem', textAlign: 'center' }}
        />
      </DataTable>

      <Dialog
        header={`${dialogMode === 'view' ? 'Detalle' : dialogMode === 'edit' ? 'Editar' : 'Nuevo'} ${title}`}
        visible={dialogVisible}
        modal
        className="w-full md:w-10/12 lg:w-8/12"
        footer={footer}
        onHide={closeDialog}
      >
        <div ref={dialogContentRef}>
        {selected && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            
            <div className="flex flex-col gap-1" data-field="rut">
              <label className="font-semibold text-sm">RUT<RequiredMark /></label>
              <InputText className="form-dropdown-presto w-full"
                maxLength={limitOf('rut')}
                value={selected.rut ?? ''}
                disabled={controlDisabled || isFieldReadOnly('rut')}
                placeholder="12345678-9"
                onChange={(e) => updateField('rut' as keyof T, formatRutSinPuntos(e.target.value) as T[keyof T])}
              />
            </div>

            <div className="flex flex-col gap-1" data-field="tipo_persona">
              <label className="font-semibold text-sm">Tipo Persona</label>
              <Dropdown className="form-dropdown-presto w-full"
                value={selected.tipo_persona ?? null}
                options={tipoPersonaOptions}
                optionLabel="description"
                optionValue="code"
                disabled={isComprador ? true : dialogMode !== 'create' || controlDisabled}
                placeholder="Seleccione"
                onChange={(e) => updateField('tipo_persona' as keyof T, e.value as T[keyof T])}
              />
            </div>

            {isPersonaJuridica(selected, tipoPersonaOptions) && (
              <div className="flex flex-col gap-1 md:col-span-1 xl:col-span-1" data-field="razon_social">
                <label className="font-semibold text-sm">Razón Social<RequiredMark /></label>
                <InputText className="form-dropdown-presto w-full"
                  maxLength={limitOf('razon_social')}
                  value={selected.razon_social ?? ''}
                  disabled={controlDisabled || isFieldReadOnly('razon_social')}
                  onChange={(e) => updateField('razon_social' as keyof T, sanitizeRazonSocial(e.target.value) as T[keyof T])}
                />
              </div>
            )}

            {!isPersonaJuridica(selected, tipoPersonaOptions) && (
              <>
                <div className="flex flex-col gap-1" data-field="nombres">
                  <label className="font-semibold text-sm">Nombres<RequiredMark /></label>
                  <InputText className="form-dropdown-presto w-full"
                    maxLength={limitOf('nombres')}
                    value={selected.nombres ?? ''}
                    disabled={controlDisabled || isFieldReadOnly('nombres')}
                    onChange={(e) => updateField('nombres' as keyof T, sanitizeNombrePersona(e.target.value) as T[keyof T])}
                  />
                </div>
                <div className="flex flex-col gap-1" data-field="apellido_paterno">
                  <label className="font-semibold text-sm">Apellido Paterno<RequiredMark /></label>
                  <InputText className="form-dropdown-presto w-full"
                    maxLength={limitOf('apellido_paterno')}
                    value={selected.apellido_paterno ?? ''}
                    disabled={controlDisabled || isFieldReadOnly('apellido_paterno')}
                    onChange={(e) => updateField('apellido_paterno' as keyof T, sanitizeNombrePersona(e.target.value) as T[keyof T])}
                  />
                </div>
                <div className="flex flex-col gap-1" data-field="apellido_materno">
                  <label className="font-semibold text-sm">Apellido Materno<RequiredMark /></label>
                  <InputText className="form-dropdown-presto w-full"
                    maxLength={limitOf('apellido_materno')}
                    value={selected.apellido_materno ?? ''}
                    disabled={controlDisabled || isFieldReadOnly('apellido_materno')}
                    onChange={(e) => updateField('apellido_materno' as keyof T, sanitizeNombrePersona(e.target.value) as T[keyof T])}
                  />
                </div>
                <div className="flex flex-col gap-1" data-field="fecha_nacimiento">
                  <label className="font-semibold text-sm">Fecha Nacimiento</label>
                  <Calendar 
                    className="calendar-presto"
                    value={parseDate(selected.fecha_nacimiento)}
                    disabled={controlDisabled || isFieldReadOnly('fecha_nacimiento')}
                    showIcon
                    dateFormat="dd/mm/yy"
                    minDate={minFechaNacimiento()}
                    maxDate={maxFechaNacimiento()}
                    yearRange={yearRangeNacimiento()}
                    viewDate={viewDateNacimiento(selected.fecha_nacimiento)}
                    onChange={(e) =>
                      updateField('fecha_nacimiento' as keyof T, toIso(e.value as Date | null) as T[keyof T])
                    }
                  />
                </div>
                <div className="flex flex-col gap-1" data-field="genero">
                  <label className="font-semibold text-sm">Género</label>
                  <Dropdown className="form-dropdown-presto w-full"
                    value={selected.genero ?? null}
                    options={generoOptions}
                    optionLabel="description"
                    optionValue="code"
                    disabled={controlDisabled || isFieldReadOnly('genero')}
                    placeholder="Seleccione"
                    onChange={(e) => updateField('genero' as keyof T, e.value as T[keyof T])}
                  />
                </div>
                <div className="flex flex-col gap-1" data-field="estado_civil">
                  <label className="font-semibold text-sm">Estado Civil</label>
                  <Dropdown className="form-dropdown-presto w-full"
                    value={selected.estado_civil ?? null}
                    options={estadoCivilOptions}
                    optionLabel="description"
                    optionValue="code"
                    disabled={controlDisabled || isFieldReadOnly('estado_civil')}
                    placeholder="Seleccione"
                    onChange={(e) => updateField('estado_civil' as keyof T, e.value as T[keyof T])}
                  />
                </div>
                <div className="flex flex-col gap-1" data-field="nacionalidad">
                  <label className="font-semibold text-sm">Nacionalidad</label>
                  <Dropdown className="form-dropdown-presto w-full"
                    value={selected.nacionalidad ?? null}
                    options={nacionalidadOptions}
                    optionLabel="description"
                    optionValue="code"
                    disabled={controlDisabled || isFieldReadOnly('nacionalidad')}
                    placeholder="Seleccione"
                    onChange={(e) => updateField('nacionalidad' as keyof T, e.value as T[keyof T])}
                  />
                </div>
                <div className="flex flex-col gap-1" data-field="profesion">
                  <label className="font-semibold text-sm">Profesión<RequiredMark /></label>
                  <InputText className="form-dropdown-presto w-full"
                    maxLength={limitOf('profesion')}
                    value={selected.profesion ?? ''}
                    disabled={controlDisabled || isFieldReadOnly('profesion')}
                    onChange={(e) => updateField('profesion' as keyof T, e.target.value as T[keyof T])}
                  />
                </div>
              </>
            )}

            <div className="flex flex-col gap-1" data-field="relacion_titular">
              <label className="font-semibold text-sm">Relación Titular<RequiredMark /></label>
              <Dropdown className="form-dropdown-presto w-full"
                value={selected.relacion_titular ?? null}
                options={relacionTitularOptions}
                optionLabel="description"
                optionValue="code"
                disabled={controlDisabled || isFieldReadOnly('relacion_titular')}
                placeholder="Seleccione"
                onChange={(e) => updateField('relacion_titular' as keyof T, e.value as T[keyof T])}
              />
            </div>

            {isComprador && (
              <div className="flex flex-col gap-1" data-field="tipo_dir_dividendo">
                <label className="font-semibold text-sm">Tipo Dirección Dividendo<RequiredMark /></label>
                <Dropdown
                  className="form-dropdown-presto w-full"
                  value={selected.tipo_dir_dividendo ?? null}
                  options={tipoDireccionDividendoOptions ?? []}
                  optionLabel="description"
                  optionValue="code"
                  disabled={controlDisabled || isFieldReadOnly('tipo_dir_dividendo')}
                  placeholder="Seleccione"
                  onChange={(e) =>
                    updateField('tipo_dir_dividendo' as keyof T, e.value as T[keyof T])
                  }
                />
              </div>
            )}

            <div className="flex flex-col gap-1 md:col-span-2 xl:col-span-3" data-field="direccion">
              <label className="font-semibold text-sm">Dirección<RequiredMark /></label>
              <InputText className="form-dropdown-presto w-full"
                maxLength={limitOf('direccion')}
                value={selected.direccion ?? ''}
                disabled={controlDisabled || isFieldReadOnly('direccion')}
                onChange={(e) => updateField('direccion' as keyof T, sanitizeDireccion(e.target.value) as T[keyof T])}
              />
            </div>

            <div className="flex flex-col gap-1" data-field="region">
              <label className="font-semibold text-sm">Región<RequiredMark /></label>
              <Dropdown className="form-dropdown-presto w-full"
                value={selected.region ?? null}
                options={regionOptions}
                optionLabel="description"
                optionValue="code"
                disabled={controlDisabled || isFieldReadOnly('region')}
                placeholder="Seleccione"
                onChange={(e) => updateField('region' as keyof T, e.value as T[keyof T])}
              />
            </div>

            <div className="flex flex-col gap-1" data-field="comuna">
              <label className="font-semibold text-sm">Comuna<RequiredMark /></label>
              <Dropdown className="form-dropdown-presto w-full"
                value={selected.comuna ?? null}
                options={filteredComunaOptions}
                optionLabel="description"
                optionValue="code"
                disabled={controlDisabled || isFieldReadOnly('comuna')}
                placeholder="Seleccione"
                onChange={(e) => updateField('comuna' as keyof T, e.value as T[keyof T])}
              />
            </div>

            <div className="flex flex-col gap-1" data-field="telefono">
              <label className="font-semibold text-sm">Teléfono<RequiredMark /></label>
              <InputText className="form-dropdown-presto w-full"
                maxLength={limitOf('telefono')}
                value={selected.telefono ?? ''}
                disabled={controlDisabled || isFieldReadOnly('telefono')}
                placeholder={TELEFONO_MOVIL_PLACEHOLDER}
                onChange={(e) =>
                  updateField('telefono' as keyof T, sanitizePhone(e.target.value, limitOf('telefono')) as T[keyof T])
                }
              />
            </div>

            {!isPersonaJuridica(selected, tipoPersonaOptions) && (
              <>
                <div className="flex flex-col gap-1" data-field="telefono_comercial">
                  <label className="font-semibold text-sm">Teléfono Comercial<RequiredMark /></label>
                  {(() => {
                    const { code, digits } = splitTelefonoFijo(
                      selected.telefono_comercial,
                      selected.region,
                      selected.comuna,
                    );

                    return (
                      <div className="flex items-center gap-1">
                        {code && <span className="font-bold whitespace-nowrap">({code})</span>}
                        <InputText className="form-dropdown-presto w-full"
                          value={digits}
                          disabled={controlDisabled || isFieldReadOnly('telefono_comercial')}
                          placeholder={telefonoFijoPlaceholder(code)}
                          maxLength={telefonoFijoDigitos(code)}
                          onChange={(e) =>
                            updateField(
                              'telefono_comercial' as keyof T,
                              ((code || '') + sanitizePhone(e.target.value, telefonoFijoDigitos(code))) as T[keyof T],
                            )
                          }
                        />
                      </div>
                    );
                  })()}
                </div>
                <div className="flex flex-col gap-1" data-field="telefono_movil">
                  <label className="font-semibold text-sm">Teléfono Móvil<RequiredMark /></label>
                  <InputText className="form-dropdown-presto w-full"
                    maxLength={limitOf('telefono_movil')}
                    value={selected.telefono_movil ?? ''}
                    disabled={controlDisabled || isFieldReadOnly('telefono_movil')}
                    placeholder={TELEFONO_MOVIL_PLACEHOLDER}
                    onChange={(e) =>
                      updateField(
                        'telefono_movil' as keyof T,
                        sanitizePhone(e.target.value, limitOf('telefono_movil')) as T[keyof T],
                      )
                    }
                  />
                </div>
              </>
            )}

            <div className="flex flex-col gap-1" data-field="email">
              <label className="font-semibold text-sm">Email<RequiredMark /></label>
              <InputText className="form-dropdown-presto w-full"
                maxLength={limitOf('email')}
                value={selected.email ?? ''}
                disabled={controlDisabled || isFieldReadOnly('email')}
                placeholder={EMAIL_PLACEHOLDER}
                onChange={(e) => updateField('email' as keyof T, e.target.value as T[keyof T])}
              />
            </div>

            {!isPersonaJuridica(selected, tipoPersonaOptions) && (
              <div className="flex flex-col gap-1" data-field="email2">
                <label className="font-semibold text-sm">Email 2<RequiredMark /></label>
                <InputText className="form-dropdown-presto w-full"
                  maxLength={limitOf('email2')}
                  value={selected.email2 ?? ''}
                  disabled={controlDisabled || isFieldReadOnly('email2')}
                  onChange={(e) => updateField('email2' as keyof T, e.target.value as T[keyof T])}
                />
              </div>
            )}

            {(isComprador || (isVendedor && isPersonaJuridica(selected, tipoPersonaOptions))) && (
              <>
                <div className="flex flex-col gap-1 md:col-span-2 xl:col-span-3" data-field="direccion_env_esc">
                  <label className="font-semibold text-sm">Dirección Envío Escritura<RequiredMark /></label>
                  <InputText className="form-dropdown-presto w-full"
                    maxLength={limitOf('direccion_env_esc')}
                    value={selected.direccion_env_esc ?? ''}
                    disabled={controlDisabled || isFieldReadOnly('direccion_env_esc')}
                    onChange={(e) =>
                      updateField('direccion_env_esc' as keyof T, sanitizeDireccion(e.target.value) as T[keyof T])
                    }
                  />
                </div>
                <div className="flex flex-col gap-1 md:col-span-1 xl:col-span-1" data-field="region_env_esc">
                  <label className="font-semibold text-sm">Región Envío Escritura<RequiredMark /></label>
                  <Dropdown className="form-dropdown-presto w-full"
                    value={selected.region_env_esc ?? null}
                    options={regionOptions}
                    optionLabel="description"
                    optionValue="code"
                    disabled={controlDisabled || isFieldReadOnly('region_env_esc')}
                    placeholder="Seleccione"
                    onChange={(e) =>
                      updateField('region_env_esc' as keyof T, e.value as T[keyof T])
                    }
                  />
                </div>
                <div className="flex flex-col gap-1 md:col-span-1 xl:col-span-1" data-field="comuna_env_esc">
                  <label className="font-semibold text-sm">Comuna Envío Escritura<RequiredMark /></label>
                  <Dropdown className="form-dropdown-presto w-full"
                    value={selected.comuna_env_esc ?? null}
                    options={filteredComunaEnvEscOptions}
                    optionLabel="description"
                    optionValue="code"
                    disabled={controlDisabled || isFieldReadOnly('comuna_env_esc')}
                    placeholder="Seleccione"
                    onChange={(e) =>
                      updateField('comuna_env_esc' as keyof T, e.value as T[keyof T])
                    }
                  />
                </div>
              </>
            )}

            {isComprador && (
              <>
                <div className="flex flex-col gap-1 md:col-span-2 xl:col-span-3" data-field="direccion_env_div">
                  <label className="font-semibold text-sm">Dirección Envío Dividendo<RequiredMark /></label>
                  <InputText className="form-dropdown-presto w-full"
                    maxLength={limitOf('direccion_env_div')}
                    value={selected.direccion_env_div ?? ''}
                    disabled={controlDisabled || isFieldReadOnly('direccion_env_div')}
                    onChange={(e) =>
                      updateField('direccion_env_div' as keyof T, sanitizeDireccion(e.target.value) as T[keyof T])
                    }
                  />
                </div>
                <div className="flex flex-col gap-1 md:col-span-1 xl:col-span-1" data-field="region_env_div">
                  <label className="font-semibold text-sm">Región Envío Dividendo<RequiredMark /></label>
                  <Dropdown className="form-dropdown-presto w-full"
                    value={selected.region_env_div ?? null}
                    options={regionOptions}
                    optionLabel="description"
                    optionValue="code"
                    disabled={controlDisabled || isFieldReadOnly('region_env_div')}
                    placeholder="Seleccione"
                    onChange={(e) =>
                      updateField('region_env_div' as keyof T, e.value as T[keyof T])
                    }
                  />
                </div>
                <div className="flex flex-col gap-1 md:col-span-1 xl:col-span-1" data-field="comuna_env_div">
                  <label className="font-semibold text-sm">Comuna Envío Dividendo<RequiredMark /></label>
                  <Dropdown className="form-dropdown-presto w-full"
                    value={selected.comuna_env_div ?? null}
                    options={filteredComunaEnvDivOptions}
                    optionLabel="description"
                    optionValue="code"
                    disabled={controlDisabled || isFieldReadOnly('comuna_env_div')}
                    placeholder="Seleccione"
                    onChange={(e) =>
                      updateField('comuna_env_div' as keyof T, e.value as T[keyof T])
                    }
                  />
                </div>
              </>
            )}
          </div>
        )}
        </div>
      </Dialog>
    </Card>
  );
}