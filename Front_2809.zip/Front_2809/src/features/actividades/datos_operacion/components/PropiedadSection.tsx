import { useMemo } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';

import RequiredMark from '@/shared/components/RequiredMark';

import type { DatosOperacionPropiedad } from '../models/datos_operacion';
import {
  EMPTY_CONTROLES_PROPIEDAD,
  type ControlesPropiedad,
} from '../models/catalogo';

type Props = {
  value: DatosOperacionPropiedad | null | undefined;
  disabled: boolean;
  controles?: ControlesPropiedad;
  loadingControles?: boolean;
  /** Nombres de campos que no se pueden editar (solo lectura). */
  readOnlyFields?: string[];
  onChange: <K extends keyof DatosOperacionPropiedad>(
    field: K,
    value: DatosOperacionPropiedad[K],
  ) => void;
};

const fieldClass = 'flex flex-col gap-1';
const labelClass = 'font-semibold text-sm text-gray-700';
const inputClass = 'form-input-presto w-full';
const dropdownClass = 'form-dropdown-presto w-full';

export default function PropiedadSection({
  value,
  disabled,
  controles = EMPTY_CONTROLES_PROPIEDAD,
  loadingControles = false,
  readOnlyFields,
  onChange,
}: Props) {
  const tipoPropiedadOptions = controles.tipo_propiedad;
  const estadoPropiedadOptions = controles.estado_propiedad;
  const tipoVentaOptions = controles.tipo_venta;
  const tipoConstruccionOptions = controles.tipo_construccion;
  const tipoDireccionOptions = controles.tipo_direccion;
  const existeRolAvaluoOptions = controles.existe_rol_avaluo;
  const regionOptions = controles.region;
  const comunaOptions = controles.comuna;
  const filteredComunaOptions = useMemo(() => {
    const regionCode = String(value?.region ?? '').trim();
    if (!regionCode) return comunaOptions;
    return comunaOptions.filter((c) => {
      const code = String(c.code ?? '');
      return code === regionCode || code.startsWith(regionCode + '-');
    });
  }, [comunaOptions, value?.region]);
  const controlDisabled = disabled || loadingControles;
  const isFieldReadOnly = (field: string): boolean =>
    (readOnlyFields ?? []).includes(field);
  const existeRol = value?.existe_rol_avaluo === '001';
  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-gray-200 bg-white p-4 sm:p-5 shadow-sm">
        <div className="mb-4 border-b border-gray-100 pb-3">
          <h3 className="text-base font-semibold text-gray-800">Datos de la Propiedad</h3>
          <p className="text-sm text-gray-500">Clasificación, estado y ubicación de la propiedad.</p>
        </div>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
          <div className={fieldClass} data-field="tipo_propiedad">
            <label className={labelClass}>Tipo Propiedad<RequiredMark /></label>
            <Dropdown
              value={value?.tipo_propiedad ?? null}
              options={tipoPropiedadOptions}
              optionLabel="description"
              optionValue="code"
              disabled={controlDisabled || isFieldReadOnly('tipo_propiedad')}
              className={dropdownClass}
              placeholder="Seleccione"
              onChange={(e) => onChange('tipo_propiedad', e.value)}
              showClear
            />
          </div>

          <div className={fieldClass} data-field="estado">
            <label className={labelClass}>Estado<RequiredMark /></label>
            <Dropdown
              value={value?.estado ?? null}
              options={estadoPropiedadOptions}
              optionLabel="description"
              optionValue="code"
              disabled={controlDisabled || isFieldReadOnly('estado')}
              className={dropdownClass}
              placeholder="Seleccione"
              onChange={(e) => onChange('estado', e.value)}
              showClear
            />
          </div>

          <div className={fieldClass} data-field="tipo_venta">
            <label className={labelClass}>Tipo Venta<RequiredMark /></label>
            <Dropdown
              value={value?.tipo_venta ?? null}
              options={tipoVentaOptions}
              optionLabel="description"
              optionValue="code"
              disabled={controlDisabled || isFieldReadOnly('tipo_venta')}
              className={dropdownClass}
              placeholder="Seleccione"
              onChange={(e) => onChange('tipo_venta', e.value)}
              showClear
            />
          </div>

          <div className={fieldClass} data-field="tipo_construccion">
            <label className={labelClass}>Tipo Construcción<RequiredMark /></label>
            <Dropdown
              value={value?.tipo_construccion ?? null}
              options={tipoConstruccionOptions}
              optionLabel="description"
              optionValue="code"
              disabled={controlDisabled || isFieldReadOnly('tipo_construccion')}
              className={dropdownClass}
              placeholder="Seleccione"
              onChange={(e) => onChange('tipo_construccion', e.value)}
              showClear
            />
          </div>

          <div className={fieldClass} data-field="tipo_direccion">
            <label className={labelClass}>Tipo Dirección<RequiredMark /></label>
            <Dropdown
              value={value?.tipo_direccion ?? null}
              options={tipoDireccionOptions}
              optionLabel="description"
              optionValue="code"
              disabled={controlDisabled || isFieldReadOnly('tipo_direccion')}
              className={dropdownClass}
              placeholder="Seleccione"
              onChange={(e) => onChange('tipo_direccion', e.value)}
              showClear
            />
          </div>

          <div className={fieldClass} data-field="existe_rol_avaluo">
            <label className={labelClass}>Existe Rol Avalúo<RequiredMark /></label>
            <Dropdown
              value={value?.existe_rol_avaluo ?? null}
              options={existeRolAvaluoOptions}
              optionLabel="description"
              optionValue="code"
              disabled={controlDisabled || isFieldReadOnly('existe_rol_avaluo')}
              className={dropdownClass}
              placeholder="Seleccione"
              onChange={(e) => {
                onChange('existe_rol_avaluo', e.value);
                if (e.value !== '001') {
                  onChange('rol_avaluo_1', null);
                  onChange('rol_avaluo_2', null);
                  onChange('valor_avaluo_pesos', null);
                }
              }}
              showClear
            />
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-gray-200 bg-white p-4 sm:p-5 shadow-sm">
        <div className="mb-4 border-b border-gray-100 pb-3">
          <h3 className="text-base font-semibold text-gray-800">Dirección y Rol de Avalúo</h3>
          <p className="text-sm text-gray-500">Detalle de dirección, identificación y valor de avalúo.</p>
        </div>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
          <div className="flex flex-col gap-1 xl:col-span-3" data-field="direccion">
            <label className={labelClass}>Dirección<RequiredMark /></label>
            <InputText
              value={value?.direccion ?? ''}
              disabled={controlDisabled || isFieldReadOnly('direccion')}
              className={inputClass}
              onChange={(e) => onChange('direccion', e.target.value)}
            />
          </div>

          <div className={fieldClass} data-field="villa_condominio">
            <label className={labelClass}>Villa / Condominio<RequiredMark /></label>
            <InputText
              value={value?.villa_condominio ?? ''}
              disabled={controlDisabled || isFieldReadOnly('villa_condominio')}
              className={inputClass}
              onChange={(e) => onChange('villa_condominio', e.target.value)}
            />
          </div>

          <div className={fieldClass} data-field="numero">
            <label className={labelClass}>Número<RequiredMark /></label>
            <InputText
              value={value?.numero ?? ''}
              disabled={controlDisabled || isFieldReadOnly('numero')}
              className={inputClass}
              onChange={(e) => onChange('numero', e.target.value)}
            />
          </div>

          <div className={fieldClass} data-field="numero_casa_habitantes">
            <label className={labelClass}>N° Casa Habitantes<RequiredMark /></label>
            <InputText
              value={value?.numero_casa_habitantes ?? ''}
              disabled={controlDisabled || isFieldReadOnly('numero_casa_habitantes')}
              className={inputClass}
              maxLength={9}
              onChange={(e) => {
                // Numérico: sólo dígitos, guardado como número (`null` si queda vacío).
                const digitos = e.target.value.replace(/\D/g, '').slice(0, 9);
                onChange('numero_casa_habitantes', digitos === '' ? null : Number(digitos));
              }}
            />
          </div>

          <div className={fieldClass} data-field="conjunto">
            <label className={labelClass}>Conjunto<RequiredMark /></label>
            <InputText
              value={value?.conjunto ?? ''}
              disabled={controlDisabled || isFieldReadOnly('conjunto')}
              className={inputClass}
              onChange={(e) => onChange('conjunto', e.target.value)}
            />
          </div>

          <div className={fieldClass} data-field="manzana">
            <label className={labelClass}>Manzana<RequiredMark /></label>
            <InputText
              value={value?.manzana ?? ''}
              disabled={controlDisabled || isFieldReadOnly('manzana')}
              className={inputClass}
              onChange={(e) => onChange('manzana', e.target.value)}
            />
          </div>

          <div className={fieldClass} data-field="lote">
            <label className={labelClass}>Lote<RequiredMark /></label>
            <InputText
              value={value?.lote ?? ''}
              disabled={controlDisabled || isFieldReadOnly('lote')}
              className={inputClass}
              onChange={(e) => onChange('lote', e.target.value)}
            />
          </div>

          <div className={fieldClass} data-field="region">
            <label className={labelClass}>Región<RequiredMark /></label>
            <Dropdown
              value={value?.region ?? null}
              options={regionOptions}
              optionLabel="description"
              optionValue="code"
              disabled={controlDisabled || isFieldReadOnly('region')}
              className={dropdownClass}
              placeholder="Seleccione"
              onChange={(e) => {
                onChange('region', e.value);
                const comunaVal = value?.comuna;
                if (comunaVal && !String(comunaVal).startsWith(e.value + '-') && comunaVal !== e.value) {
                  onChange('comuna', null);
                }
              }}
              showClear
              filter
            />
          </div>

          <div className={fieldClass} data-field="comuna">
            <label className={labelClass}>Comuna<RequiredMark /></label>
            <Dropdown
              value={value?.comuna ?? null}
              options={filteredComunaOptions}
              optionLabel="description"
              optionValue="code"
              disabled={controlDisabled || isFieldReadOnly('comuna')}
              className={dropdownClass}
              placeholder="Seleccione"
              onChange={(e) => onChange('comuna', e.value)}
              showClear
              filter
            />
          </div>

          <div className={fieldClass} data-field="valor_avaluo_pesos">
            <label className={labelClass}>Valor Avalúo Pesos{existeRol && <RequiredMark />}</label>
            <InputNumber
              value={value?.valor_avaluo_pesos ?? null}
              disabled={controlDisabled || !existeRol || isFieldReadOnly('valor_avaluo_pesos')}
              className={inputClass}
              inputClassName="w-full"
              // Pesos chilenos: moneda sin decimales. Misma configuración que el modal
              // que edita este campo en `corregir_reparo_calculo_doc`.
              mode="currency"
              currency="CLP"
              locale="es-CL"
              min={0}
              onValueChange={(e) => onChange('valor_avaluo_pesos', e.value ?? null)}
            />
          </div>

          <div className={fieldClass} data-field="rol_avaluo_1">
            <label className={labelClass}>Rol Avalúo 1{existeRol && <RequiredMark />}</label>
            <InputText
              value={value?.rol_avaluo_1 ?? ''}
              disabled={controlDisabled || !existeRol || isFieldReadOnly('rol_avaluo_1')}
              className={inputClass}
              onChange={(e) => onChange('rol_avaluo_1', e.target.value)}
            />
          </div>

          <div className={fieldClass} data-field="rol_avaluo_2">
            <label className={labelClass}>Rol Avalúo 2{existeRol && <RequiredMark />}</label>
            <InputText
              value={value?.rol_avaluo_2 ?? ''}
              disabled={controlDisabled || !existeRol || isFieldReadOnly('rol_avaluo_2')}
              className={inputClass}
              onChange={(e) => onChange('rol_avaluo_2', e.target.value)}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
