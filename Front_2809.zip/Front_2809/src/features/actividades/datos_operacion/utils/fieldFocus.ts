// Utilidad para enfocar y hacer scroll automático hacia un campo requerido
// que falló la validación. Los componentes de Datos de Operación exponen
// sus controles con el atributo `data-field="<llave_snake_case>"`.

export const FIELD_FOCUS_ATTR = "data-field";
export const FIELD_ERROR_CLASS = "field-error";

/**
 * Atributo opcional para marcar un campo que NO debe recibir foco automático
 * (solo scroll + resaltado).
 */
export const FIELD_NO_AUTOFOCUS_ATTR = "data-no-autofocus";

/**
 * Los `Calendar` de PrimeReact abren su panel al recibir el foco
 * (`onInputFocus` → `show()`, con `showOnFocus` por defecto en `true`). Si ese
 * foco ocurre durante la animación de entrada de un `Dialog`, el panel queda en
 * un estado inconsistente: se ve, pero no responde hasta que el usuario vuelve
 * a hacer clic en el campo. Por eso, cuando el control es un calendario solo se
 * hace scroll y se marca el error: el panel lo abre el usuario con un clic.
 */
const SKIP_AUTOFOCUS_SELECTOR = '.p-calendar';

/**
 * Quita el resaltado de error de todos los campos del ámbito indicado.
 * Se llama antes de aplicar una validación nueva para no dejar resaltados
 * "colgando" de una validación anterior.
 * @param scope contenedor donde limpiar (por defecto todo el documento).
 */
export function clearFieldErrors(scope?: HTMLElement | null): void {
  const root = scope ?? document;

  root
    .querySelectorAll<HTMLElement>(`.${FIELD_ERROR_CLASS}`)
    .forEach((element) => element.classList.remove(FIELD_ERROR_CLASS));
}

/**
 * Hace scroll y focus al control identificado por `fieldKey`, marcándolo
 * en rojo (clase `field-error`) para señalar el campo requerido.
 * El resaltado se quita cuando el usuario interactúa con el control.
 *
 * Excepción: los campos de calendario (`.p-calendar`) o marcados con
 * `data-no-autofocus` NO reciben foco (ver `SKIP_AUTOFOCUS_SELECTOR`);
 * solo se hace scroll y se resalta el error.
 * @param fieldKey  llave del campo (snake_case), p. ej. "tipo_propiedad".
 * @param scope     contenedor opcional donde buscar (por defecto todo el documento).
 * @param delay     milisegundos a esperar antes de enfocar (permite que el tab/dialog renderice).
 * @param markError si `true` agrega la clase `field-error` al contenedor del campo.
 */
export function focusFieldByKey(
  fieldKey: string | null | undefined,
  scope?: HTMLElement | null,
  delay = 150,
  markError = true,
): void {
  if (!fieldKey) return;

  const root = scope ?? document;

  window.setTimeout(() => {
    const wrapper = root.querySelector<HTMLElement>(
      `[${FIELD_FOCUS_ATTR}="${fieldKey}"]`,
    );
    if (!wrapper) return;

    wrapper.scrollIntoView({ behavior: "smooth", block: "center" });

    if (markError) {
      wrapper.classList.add("field-error");
    }

    const omitirAutofoco =
      wrapper.hasAttribute(FIELD_NO_AUTOFOCUS_ATTR) ||
      !!wrapper.querySelector(SKIP_AUTOFOCUS_SELECTOR);

    if (!omitirAutofoco) {
      const target = wrapper.querySelector<HTMLElement>(
        'input:not([type="hidden"]), textarea, select, button, [tabindex]:not([tabindex="-1"])',
      );
      const el = target ?? wrapper;
      el.focus({ preventScroll: true });
    }

    const clearError = () => {
      wrapper.classList.remove("field-error");
      wrapper.removeEventListener("input", clearError);
      wrapper.removeEventListener("change", clearError);
      wrapper.removeEventListener("click", clearError);
    };
    wrapper.addEventListener("input", clearError);
    wrapper.addEventListener("change", clearError);
    wrapper.addEventListener("click", clearError);
  }, delay);
}
