import { useEffect, useRef, useState } from "react";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";
import { InputNumber } from "primereact/inputnumber";
import { InputText } from "primereact/inputtext";
import { RadioButton } from "primereact/radiobutton";
import { Toast } from "primereact/toast";

interface CorreccionRolAvaluoModalProps {
  visible: boolean;
  existe_rol_avaluo: string | null;
  rol_avaluo_editado: string | null;
  valor_avaluo_pesos: number | null;
  on_hide: () => void;
  on_confirm: (data: {
    existe_rol_avaluo: string | null;
    rol_avaluo_editado: string | null;
    valor_avaluo_pesos: number | null;
  }) => void;
}

const is_si = (value: string | null | undefined): boolean =>
  value === "SI" || value === "Sí";

export default function CorreccionRolAvaluoModal({
  visible,
  existe_rol_avaluo,
  rol_avaluo_editado,
  valor_avaluo_pesos,
  on_hide,
  on_confirm,
}: CorreccionRolAvaluoModalProps) {
  const toast = useRef<Toast>(null);
  const [existe, set_existe] = useState<string | null>(existe_rol_avaluo);
  const [rol, set_rol] = useState<string | null>(rol_avaluo_editado);
  const [valor, set_valor] = useState<number | null>(valor_avaluo_pesos);

  useEffect(() => {
    if (visible) {
      set_existe(existe_rol_avaluo);
      set_rol(rol_avaluo_editado);
      set_valor(valor_avaluo_pesos);
    }
  }, [visible, existe_rol_avaluo, rol_avaluo_editado, valor_avaluo_pesos]);

  const change_existe = (next_value: string) => {
    set_existe(next_value);
    if (!is_si(next_value)) {
      set_rol(null);
      set_valor(null);
    }
  };

  const validate = (): string => {
    if (!existe) {
      return "Debe seleccionar si ¿Existe Rol Avalúo? (Sí o E/T).";
    }

    if (is_si(existe)) {
      if (!rol || !String(rol).trim()) {
        return "Rol Avalúo es obligatorio cuando ¿Existe Rol Avalúo? = Sí.";
      }
      if (
        valor === null ||
        valor === undefined ||
        Number.isNaN(Number(valor))
      ) {
        return "Valor Avalúo Pesos es obligatorio cuando ¿Existe Rol Avalúo? = Sí.";
      }
    }

    return "";
  };

  const handle_aceptar = () => {
    const msg = validate();
    if (msg) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: msg,
        life: 3000,
      });
      return;
    }

    on_confirm({
      existe_rol_avaluo: existe,
      rol_avaluo_editado: rol,
      valor_avaluo_pesos: valor,
    });
    on_hide();
  };

  const existe_yes = is_si(existe);

  const footer = (
    <div className="flex justify-end gap-2">
      <Button
        type="button"
        label="Cancelar"
        icon="pi pi-times"
        severity="secondary"
        outlined
        onClick={on_hide}
      />
      <Button
        type="button"
        label="Aceptar"
        icon="pi pi-check"
        severity="success"
        onClick={handle_aceptar}
      />
    </div>
  );

  return (
    <>
      <Toast ref={toast} />
      <Dialog
        header="Corrección Rol Avalúo"
        visible={visible}
        onHide={on_hide}
        modal
        dismissableMask={false}
        closeOnEscape={false}
        draggable={false}
        resizable={false}
        className="w-full md:w-6/12"
        footer={footer}
      >
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center gap-6">
            <span className="text-sm font-semibold text-gray-800">
              ¿Existe Rol Avalúo? *
            </span>
            <div className="flex flex-wrap gap-5">
              <div className="flex items-center gap-2">
                <RadioButton
                  className="form-radio-presto"
                  inputId="modal_existe_rol_si"
                  value="SI"
                  checked={existe_yes}
                  onChange={() => change_existe("SI")}
                />
                <label htmlFor="modal_existe_rol_si" className="cursor-pointer text-sm">
                  Sí
                </label>
              </div>
              <div className="flex items-center gap-2">
                <RadioButton
                  className="form-radio-presto"
                  inputId="modal_existe_rol_et"
                  value="E/T"
                  checked={existe === "E/T" || existe === "ET"}
                  onChange={() => change_existe("E/T")}
                />
                <label htmlFor="modal_existe_rol_et" className="cursor-pointer text-sm">
                  E/T
                </label>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1">
              <label htmlFor="modal_rol_avaluo_editado" className="text-sm font-semibold">
                Rol Avalúo {existe_yes ? "*" : ""}
              </label>
              <InputText
                id="modal_rol_avaluo_editado"
                value={rol ?? ""}
                onChange={(e) => set_rol(e.target.value)}
                className="form-input-presto w-full"
                disabled={!existe_yes}
                placeholder={existe_yes ? "Ej: 12.345-001" : "-"}
              />
            </div>

            <div className="flex flex-col gap-1">
              <label htmlFor="modal_valor_avaluo_pesos" className="text-sm font-semibold">
                Valor Avalúo Pesos {existe_yes ? "*" : ""}
              </label>
              <InputNumber
                inputId="modal_valor_avaluo_pesos"
                value={valor ?? null}
                onValueChange={(e) => set_valor(e.value ?? null)}
                mode="currency"
                currency="CLP"
                locale="es-CL"
                className="form-input-presto w-full"
                disabled={!existe_yes}
                placeholder={existe_yes ? "Ingrese valor" : "-"}
              />
            </div>
          </div>
        </div>
      </Dialog>
    </>
  );
}
