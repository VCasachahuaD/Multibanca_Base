import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Accordion, AccordionTab } from "primereact/accordion";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Checkbox } from "primereact/checkbox";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";

import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";

import type { CorregirReparoCalculoDoc } from "../models/corregir_reparo_calculo_doc";
import type { CatalogoOption, ControlesPropiedad } from "../models/catalogo";
import { EMPTY_CONTROLES_PROPIEDAD } from "../models/catalogo";
import { useCorregirReparoCalculoDoc } from "../hooks/useCorregirReparoCalculoDoc";
import { useUpsertCorregirReparoCalculoDoc } from "../hooks/useUpsertCorregirReparoCalculoDoc";
import { useAvanzarCorregirReparoCalculoDoc } from "../hooks/useAvanzarCorregirReparoCalculoDoc";
import { useControlesPropiedad } from "../hooks/useControlesPropiedad";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
import CorreccionRolAvaluoModal from "../components/CorreccionRolAvaluoModal";
const ACTIVITY_ID = "_J6wLpT4zEelNy2_Y1mD7x";

const build_initial_state = (id_expediente: number): CorregirReparoCalculoDoc => ({
  id_corregir_reparo_calculo_doc: 0,
  id_expediente,
  id_usuario_solicitante: 0,
  is_subsanar: false,
  observaciones: null,
  existe_rol_avaluo: null,
  rol_avaluo_editado: null,
  valor_avaluo_pesos: null,
  solicitante: "",
  observaciones_reparo: "",
  fecha_ingreso: null,
  tipo_propiedad: "",
  tipo_direccion: "",
  direccion: "",
  region: "",
  comuna: "",
  rol_avaluo: "",
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: new Date().toISOString(),
  modified_by: null,
  modified_date: null,
});

const normalize = (
  source: Partial<CorregirReparoCalculoDoc> | null | undefined,
  id_expediente_fallback: number,
): CorregirReparoCalculoDoc => ({
  id_corregir_reparo_calculo_doc: Number(source?.id_corregir_reparo_calculo_doc ?? 0),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback),
  id_usuario_solicitante: Number(source?.id_usuario_solicitante ?? 0),
  is_subsanar: Boolean(source?.is_subsanar ?? false),
  observaciones: source?.observaciones ?? null,
  existe_rol_avaluo: source?.existe_rol_avaluo ?? null,
  rol_avaluo_editado: source?.rol_avaluo_editado ?? null,
  valor_avaluo_pesos:
    source?.valor_avaluo_pesos === undefined ? null : source?.valor_avaluo_pesos,
  solicitante: source?.solicitante ?? "",
  observaciones_reparo: source?.observaciones_reparo ?? "",
  fecha_ingreso: source?.fecha_ingreso ?? null,
  tipo_propiedad: source?.tipo_propiedad ?? "",
  tipo_direccion: source?.tipo_direccion ?? "",
  direccion: source?.direccion ?? "",
  region: source?.region ?? "",
  comuna: source?.comuna ?? "",
  rol_avaluo: source?.rol_avaluo ?? "",
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? new Date().toISOString(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const format_date = (value: string | null | undefined): string => {
  if (!value) return "";
  return new Date(value).toLocaleDateString("es-CL", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
};

const is_existe_rol_si = (value: string | null | undefined): boolean =>
  value === "SI" || value === "Sí";

const resolveLabel = (options: CatalogoOption[], value?: string | null): string => {
  if (!value || !value.trim()) return "-";
  const match = options.find((o) => o.code === value);
  if (match && match.description) return match.description;
  return value;
};

export default function CorregirReparoCalculoDocPage() {
  const toast = useRef<Toast>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: id_param } = useParams();
  const { fromTracking = false } = location.state || {};
  const id_expediente = Number(id_param ?? 0);
  const has_valid_expediente = id_expediente > 0;

  const [form, set_form] = useState<CorregirReparoCalculoDoc>(build_initial_state(id_expediente));
  const [is_disabled, set_is_disabled] = useState(true);
  const [can_advance, set_can_advance] = useState(false);
  const [is_busy, set_is_busy] = useState(false);
  const [correccion_modal_visible, set_correccion_modal_visible] = useState(false);

  const has_hydrated = useRef(false);
  const current_expediente = useRef(id_expediente);

  const { data, isLoading } = useCorregirReparoCalculoDoc(id_expediente);
  const save_mutation = useUpsertCorregirReparoCalculoDoc();
  const avanzar_mutation = useAvanzarCorregirReparoCalculoDoc();
  const { data: controles_data } = useControlesPropiedad();
  const controles = controles_data?.detail ?? EMPTY_CONTROLES_PROPIEDAD;

  useEffect(() => {
    if (current_expediente.current !== id_expediente) {
      current_expediente.current = id_expediente;
      has_hydrated.current = false;

      set_form(build_initial_state(id_expediente));
      set_is_disabled(true);
      set_can_advance(false);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (has_hydrated.current) return;

    if (data?.status && data.detail) {
      const loaded = normalize(data.detail, id_expediente);
      set_form(loaded);
      set_is_disabled(true);
      set_can_advance(false);
      has_hydrated.current = true;
      return;
    }

    if (!has_valid_expediente) {
      set_form(build_initial_state(0));
      set_is_disabled(false);
      set_can_advance(false);
      has_hydrated.current = true;
      return;
    }

    if (data) {
      set_form(build_initial_state(id_expediente));
      set_is_disabled(true);
      set_can_advance(false);
      has_hydrated.current = true;
    }
  }, [data, id_expediente, has_valid_expediente]);

  const toggle_subsanar = (checked: boolean) => {
    set_form((prev) => ({
      ...prev,
      is_subsanar: checked,
    }));
  };

  const handle_editar = () => {
    set_is_disabled(false);
    set_can_advance(false);
  };

  const validate_form = (): string => {
    if (!form.observaciones || !form.observaciones.trim()) {
      return "Debe ingresar las Observaciones finales.";
    }

    if (!form.existe_rol_avaluo) {
      return "Debe seleccionar si ¿Existe Rol Avalúo? (Sí o E/T).";
    }

    if (is_existe_rol_si(form.existe_rol_avaluo)) {
      if (!form.rol_avaluo_editado || !String(form.rol_avaluo_editado).trim()) {
        return "Rol Avalúo es obligatorio cuando ¿Existe Rol Avalúo? = Sí.";
      }
      if (
        form.valor_avaluo_pesos === null ||
        form.valor_avaluo_pesos === undefined ||
        Number.isNaN(Number(form.valor_avaluo_pesos))
      ) {
        return "Valor Avalúo Pesos es obligatorio cuando ¿Existe Rol Avalúo? = Sí.";
      }
    }

    return "";
  };

  const handle_guardar = async () => {

    const validation_msg = validate_form();
    if (validation_msg) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: validation_msg,
        life: 3000,
      });
      return;
    }

    set_is_busy(true);
    try {
      const payload = normalize({ ...form, id_expediente }, id_expediente);
      const response = await save_mutation.mutateAsync(payload);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Información guardada correctamente",
          life: 3000,
        });

        const saved = normalize(response.detail ?? payload, payload.id_expediente);
        set_form(saved);
        set_is_disabled(true);
        set_can_advance(true);
        has_hydrated.current = true;
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: response.message || "No se pudo guardar",
          life: 3000,
        });
      }
    } catch (error) {
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Ocurrió un error al guardar",
        life: 3000,
      });
    } finally {
      set_is_busy(false);
    }
  };

  const handle_avanzar = async () => {

    if (!has_valid_expediente) {
      const msg = "No existe un id_expediente válido para avanzar.";
      toast.current?.show({ severity: "warn", summary: "Validación", detail: msg, life: 3000 });
      return;
    }

    if (!form.is_subsanar) {
      const msg = "Debe marcar Subsanar para avanzar la actividad.";
      toast.current?.show({ severity: "warn", summary: "Validación", detail: msg, life: 3000 });
      return;
    }

    set_is_busy(true);
    try {
      const response = await avanzar_mutation.mutateAsync(id_expediente);
      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Actividad avanzada correctamente",
          life: 2000,
        });
        navigate("/home/bandeja");
      } else {
        const msg = response.message || "No se pudo avanzar la actividad.";
        toast.current?.show({ severity: "warn", summary: "Atención", detail: msg, life: 3000 });
      }
    } catch (error) {
      const msg = "Ocurrió un error al avanzar.";
      toast.current?.show({ severity: "error", summary: "Error", detail: msg, life: 3000 });
    } finally {
      set_is_busy(false);
    }
  };

  const handle_salir = () => navigate("/home/bandeja");

  const handle_correccion_confirm = (data: {
    existe_rol_avaluo: string | null;
    rol_avaluo_editado: string | null;
    valor_avaluo_pesos: number | null;
  }) => {
    set_form((prev) => ({
      ...prev,
      existe_rol_avaluo: data.existe_rol_avaluo,
      rol_avaluo_editado: data.rol_avaluo_editado,
      valor_avaluo_pesos: data.valor_avaluo_pesos,
    }));
  };

  return (
    <>
      <Toast ref={toast} />

      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Corregir Reparo Cálculo y Generación Documento
      </h2>

      <Accordion multiple activeIndex={[2]}>
        <AccordionTab header="Información del Expediente" disabled={!has_valid_expediente}>
          <EncabezadoActividad idExpediente={id_expediente} activityID={ACTIVITY_ID} />
        </AccordionTab>

        <AccordionTab header="Funciones Transversales" disabled={!has_valid_expediente}>
          <FuncionesTransversales idExpediente={id_expediente} idActividad={ACTIVITY_ID} />
        </AccordionTab>

        <AccordionTab header="Corregir Reparo Cálculo y Generación Documento">
          <Card className="w-full shadow-md card-presto-form mb-6">
            {isLoading && has_valid_expediente && (
              <div className="mb-4 text-sm text-blue-600">Cargando información...</div>
            )}

            <div className="flex flex-col gap-6">
              <ReparoTabla
                form={form}
                is_disabled={is_disabled}
                on_toggle_subsanar={toggle_subsanar}
              />

              <RolAvaluoTabla
                form={form}
                controles={controles}
                is_disabled={is_disabled}
                on_edit={() => set_correccion_modal_visible(true)}
              />

              <div className="flex flex-col gap-1">
                <label className="font-semibold text-sm">Observaciones *</label>
                <InputTextarea
                  value={form.observaciones ?? ""}
                  onChange={(e) =>
                    set_form((prev) => ({ ...prev, observaciones: e.target.value }))
                  }
                  rows={4}
                  maxLength={1000}
                  className="form-textarea-presto w-full"
                  disabled={is_disabled}
                  placeholder="Ingrese observaciones (máximo 1000 caracteres)"
                  style={{ resize: "none" }}
                />
                <div className="flex justify-end mt-1 text-xs">
                  <span className={
                    (form.observaciones?.length ?? 0) >= 1000 
                      ? "text-red-600" 
                      : (form.observaciones?.length ?? 0) >= 900 
                        ? "text-orange-500" 
                        : "text-gray-500"
                  }>
                    {form.observaciones?.length ?? 0}
                  </span>
                  <span className="mx-1 text-gray-500">/</span>
                  <span className="text-gray-500">1000</span>
                </div>
              </div>
            </div>

            <ActivityActionBar
              from_tracking={fromTracking}
              is_busy={is_busy}
              is_disabled={is_disabled}
              can_advance={can_advance}
              is_saving={save_mutation.isPending}
              is_advancing={avanzar_mutation.isPending}
              on_edit={handle_editar}
              on_save={handle_guardar}
              on_advance={handle_avanzar}
              on_exit={handle_salir}
            />
          </Card>
        </AccordionTab>
      </Accordion>

      <CorreccionRolAvaluoModal
        visible={correccion_modal_visible}
        existe_rol_avaluo={form.existe_rol_avaluo}
        rol_avaluo_editado={form.rol_avaluo_editado}
        valor_avaluo_pesos={form.valor_avaluo_pesos}
        on_hide={() => set_correccion_modal_visible(false)}
        on_confirm={handle_correccion_confirm}
      />
    </>
  );
}

interface ReparoTablaProps {
  form: CorregirReparoCalculoDoc;
  is_disabled: boolean;
  on_toggle_subsanar: (checked: boolean) => void;
}

function ReparoTabla({ form, is_disabled, on_toggle_subsanar }: ReparoTablaProps) {
  return (
    <div>
      <div className="bg-azul-presto text-white px-4 py-2 font-semibold text-sm uppercase">
        Detalles del Reparo
      </div>
      <div className="reparo-table-container">
        <table className="reparo-table">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-left w-1/4">
                Solicitante
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-left">
                Observaciones del Reparo
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-center w-32">
                Fecha de Ingreso
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-center w-24">
                Subsanar
              </th>
            </tr>
          </thead>
          <tbody>
            <tr className="bg-white">
              <td data-label="Solicitante" className="px-3 py-2 text-sm border border-gray-200">{form.solicitante || "-"}</td>
              <td data-label="Observaciones del Reparo" className="px-3 py-2 text-sm border border-gray-200">
                {form.observaciones_reparo || "-"}
              </td>
              <td data-label="Fecha de Ingreso" className="px-3 py-2 text-sm border border-gray-200 text-center">
                {format_date(form.fecha_ingreso)}
              </td>
              <td data-label="Subsanar" className="px-3 py-2 border border-gray-200 text-center">
                <Checkbox
                  inputId="is_subsanar"
                  className="form-checkbox-presto"
                  checked={form.is_subsanar}
                  onChange={(e) => on_toggle_subsanar(!!e.checked)}
                  disabled={is_disabled}
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

interface RolAvaluoTablaProps {
  form: CorregirReparoCalculoDoc;
  controles: ControlesPropiedad;
  is_disabled: boolean;
  on_edit: () => void;
}

function RolAvaluoTabla({ form, controles, is_disabled, on_edit }: RolAvaluoTablaProps) {
  return (
    <div>
      <div className="bg-azul-presto text-white px-4 py-2 font-semibold text-sm uppercase">
        Datos de la Propiedad
      </div>
      <div className="reparo-table-container">
        <table className="reparo-table">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-left">
                Tipo de Propiedad
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-left">
                Tipo de Dirección
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-left">
                Dirección
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-left">
                Región
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-left">
                Comuna
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-left">
                Rol Avalúo
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-center w-24">
                Editar
              </th>
            </tr>
          </thead>
          <tbody>
            <tr className="bg-white">
              <td data-label="Tipo de Propiedad" className="px-3 py-2 text-sm border border-gray-200">
                {resolveLabel(controles.tipo_propiedad, form.tipo_propiedad)}
              </td>
              <td data-label="Tipo de Dirección" className="px-3 py-2 text-sm border border-gray-200">
                {resolveLabel(controles.tipo_direccion, form.tipo_direccion)}
              </td>
              <td data-label="Dirección" className="px-3 py-2 text-sm border border-gray-200">{form.direccion || "-"}</td>
              <td data-label="Región" className="px-3 py-2 text-sm border border-gray-200">{resolveLabel(controles.region, form.region)}</td>
              <td data-label="Comuna" className="px-3 py-2 text-sm border border-gray-200">{resolveLabel(controles.comuna, form.comuna)}</td>
              <td data-label="Rol Avalúo" className="px-3 py-2 text-sm border border-gray-200">{form.rol_avaluo || "-"}</td>
              <td data-label="Editar" className="px-3 py-2 border border-gray-200 text-center">
                <Button
                  label="Editar"
                  size="small"
                  severity="info"
                  outlined
                  disabled={is_disabled}
                  onClick={on_edit}
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
