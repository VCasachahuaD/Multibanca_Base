import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Accordion, AccordionTab } from "primereact/accordion";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Checkbox, CheckboxChangeEvent } from "primereact/checkbox";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";

import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";
import type { GenerarCartaResguardo } from "../models/generar_carta_resguardo";
import { useAvanzarGenerarCartaResguardo } from "../hooks/useAvanzarGenerarCartaResguardo";
import { useGenerarCartaResguardo } from "../hooks/useGenerarCartaResguardo";
import { useUpsertGenerarCartaResguardo } from "../hooks/useUpsertGenerarCartaResguardo";
import { RadioButton } from "primereact/radiobutton";
import { Dropdown } from "primereact/dropdown";
import { useControlesGenerarCartaResguardo } from "../hooks/useControlesGenerarCartaResguardo";
import { EMPTY_CONTROLES_GENERAR_cARTA_RESGUARDO } from "../models/catalogo";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const ACTIVITY_ID = "_Fm4K_N9rWeaBh7_L2tP6z";

const buildInitialState = (id_expediente: number): GenerarCartaResguardo => ({
    id_generar_carta_resguardo: 0,
    id_expediente,
    generar_carta: false,
    tipo_carta: "",
    enviar_a_reparo: false,
    observaciones: "",
    is_active: true,
    row_status: true,
    created_by: 0,
    created_date: new Date().toISOString(),
    modified_by: null,
    modified_date: null,
});

const normalizeGenerarCartaResguardo = (
    source: Partial<GenerarCartaResguardo> | null | undefined,
    id_expediente_fallback: number,
): GenerarCartaResguardo => {
    return {
        id_generar_carta_resguardo: Number(source?.id_generar_carta_resguardo ?? 0),
        id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
        generar_carta: Boolean(source?.generar_carta ?? false),
        tipo_carta: source?.tipo_carta ?? "",
        enviar_a_reparo: Boolean(source?.enviar_a_reparo ?? false),
        observaciones: source?.observaciones ?? "",
        is_active: source?.is_active ?? true,
        row_status: source?.row_status ?? true,
        created_by: Number(source?.created_by ?? 0),
        created_date: source?.created_date ?? new Date().toISOString(),
        modified_by: source?.modified_by ?? null,
        modified_date: source?.modified_date ?? null,
    };
};

export default function GenerarCartaResguardoPage() {
    const toast = useRef<Toast>(null);

    const navigate = useNavigate();
    const location = useLocation();
    const { id_expediente: idExpedienteParam } = useParams();
    const { fromTracking = false } = location.state || {};

    const id_expediente = Number(idExpedienteParam ?? 0);

    const [form, setForm] = useState<GenerarCartaResguardo>(
        buildInitialState(id_expediente),
    );
    const [isDisabled, setIsDisabled] = useState(true);
    const [canAdvance, setCanAdvance] = useState(false);
    const [isBusy, setIsBusy] = useState(false);

    const hasHydratedRef = useRef(false);
    const currentExpedienteRef = useRef<number>(id_expediente);

    const { data, isLoading } = useGenerarCartaResguardo(id_expediente);
    const saveMutation = useUpsertGenerarCartaResguardo();
    const avanzarMutation = useAvanzarGenerarCartaResguardo();
    const controlesGenerarCartaResguardoQuery = useControlesGenerarCartaResguardo();

    const controlesGenerarCartaResguardo = controlesGenerarCartaResguardoQuery.data?.status
        ? controlesGenerarCartaResguardoQuery.data.detail ?? EMPTY_CONTROLES_GENERAR_cARTA_RESGUARDO
        : EMPTY_CONTROLES_GENERAR_cARTA_RESGUARDO;

    useEffect(() => {
        if (currentExpedienteRef.current !== id_expediente) {
            currentExpedienteRef.current = id_expediente;
            hasHydratedRef.current = false;

            setForm(buildInitialState(id_expediente));
            setIsDisabled(true);
            setCanAdvance(false);
        }
    }, [id_expediente]);

    useEffect(() => {
        if (hasHydratedRef.current) return;

        if (data?.status && data.detail) {
            const loadedEntity = normalizeGenerarCartaResguardo(
                data.detail,
                id_expediente,
            );

            setForm(loadedEntity);
            setIsDisabled(true);
            setCanAdvance(false);
            hasHydratedRef.current = true;
            return;
        }

        if (!id_expediente || id_expediente <= 0) {
            setForm(buildInitialState(0));
            setIsDisabled(false);
            setCanAdvance(false);
            hasHydratedRef.current = true;
            return;
        }

        if (data) {
            setForm((prev) =>
                normalizeGenerarCartaResguardo(
                    {
                        ...prev,
                        id_expediente,
                    },
                    id_expediente,
                ),
            );
            setIsDisabled(true);
            setCanAdvance(false);
            hasHydratedRef.current = true;
        }
    }, [data, id_expediente]);

    const updateField = <K extends keyof GenerarCartaResguardo>(
        field: K,
        value: GenerarCartaResguardo[K],
    ) => {
        setForm((prev) => ({
            ...prev,
            [field]: value,
        }));
    };

    const handleEnviarAReparoChange = (e: CheckboxChangeEvent) => {
        updateField("enviar_a_reparo", Boolean(e.checked));
    };

    const handleEditar = () => {
        setIsDisabled(false);
        setCanAdvance(false);
    };

    const validateForm = () => {
        if (!form.id_expediente || form.id_expediente <= 0) {
            return "No existe un id_expediente válido.";
        }

        return "";
    };

    const handleGuardar = async () => {
        const validationMessage = validateForm();
        if (validationMessage) {
            toast.current?.show({
                severity: "warn",
                summary: "Validación",
                detail: validationMessage,
                life: 3000,
            });
            return;
        }

        try {
            setIsBusy(true);

            const payload: GenerarCartaResguardo = normalizeGenerarCartaResguardo(
                {
                    ...form,
                    id_generar_carta_resguardo: Number(
                        form.id_generar_carta_resguardo ?? 0,
                    ),
                    id_expediente: Number(form.id_expediente || id_expediente || 0),
                },
                id_expediente,
            );

            const response = await saveMutation.mutateAsync(payload);

            if (response.status) {
                toast.current?.show({
                    severity: "success",
                    summary: "Éxito",
                    detail: "Actividad Generar Carta Resguardo guardada correctamente",
                    life: 3000,
                });

                const savedEntity = normalizeGenerarCartaResguardo(
                    response.detail ?? payload,
                    payload.id_expediente,
                );

                setForm(savedEntity);
                setIsDisabled(true);
                setCanAdvance(true);
                hasHydratedRef.current = true;
            } else {
                toast.current?.show({
                    severity: "warn",
                    summary: "Atención",
                    detail: response.message || "No se pudo guardar",
                    life: 3000,
                });
            }
        } catch (error) {
            console.error("ERROR GUARDAR Generar Carta Resguardo", error);

            toast.current?.show({
                severity: "error",
                summary: "Error",
                detail: "Ocurrió un error al guardar",
                life: 3000,
            });
        } finally {
            setIsBusy(false);
        }
    };

    const handleAvanzar = async () => {
        const validationMessage = validateForm();
        if (validationMessage) {
            toast.current?.show({
                severity: "warn",
                summary: "Validación",
                detail: validationMessage,
                life: 3000,
            });
            return;
        }

        /* if (!form.enviar_a_reparo) {
            const msg = "Debe enviar a reparo para avanzar la actividad.";
            toast.current?.show({
                severity: "warn",
                summary: "Validación",
                detail: msg,
                life: 3000,
            });
            return;
        } */

        try {
            setIsBusy(true);

            const response = await avanzarMutation.mutateAsync(Number(form.id_expediente));

            if (response.status) {
                toast.current?.show({
                    severity: "success",
                    summary: "Éxito",
                    detail: "Actividad avanzada correctamente",
                    life: 2000,
                });

                navigate("/home/bandeja");
            } else {
                const msg = response.message || "No se pudo avanzar la actividad.";
                toast.current?.show({
                    severity: "warn",
                    summary: "Atención",
                    detail: msg,
                    life: 3000,
                });
            }
        } catch (error) {
            console.error("ERROR AVANZAR Generar Carta Resguardo", error);
            const msg = "Ocurrió un error al avanzar.";

            toast.current?.show({
                severity: "error",
                summary: "Error",
                detail: msg,
                life: 3000,
            });
        } finally {
            setIsBusy(false);
        }
    };

    const handleSalir = () => {
        navigate("/home/bandeja");
    };

    return (
        <>
            <Toast ref={toast} />

            <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Generar Carta Resguardo
            </h2>

            <Accordion activeIndex={[0, 2]} multiple>
                <AccordionTab
                    disabled={!id_expediente || id_expediente <= 0}
                    header="Información del Expediente"
                >
                    <EncabezadoActividad
                        idExpediente={Number(form.id_expediente || id_expediente || 0)}
                        activityID={ACTIVITY_ID}
                    />
                </AccordionTab>

                <AccordionTab
                    header="Funciones Transversales"
                    disabled={!id_expediente || id_expediente <= 0}
                >
                    <FuncionesTransversales
                        idExpediente={Number(form.id_expediente || id_expediente || 0)}
                        idActividad={ACTIVITY_ID}
                    />
                </AccordionTab>

                <AccordionTab header="Generar Carta Resguardo">
                    <Card className="w-full shadow-md card-presto-form mb-6">
                        {isLoading && id_expediente > 0 && (
                            <div className="mb-4 text-sm text-blue-600">
                                Cargando información...
                            </div>
                        )}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

                            <div className="flex flex-col gap-1">
                                <label className="font-semibold text-sm">Generar Carta Resguardo *</label>

                                <div className="flex items-center gap-6 h-10">
                                    <div className="flex items-center gap-2">
                                        <RadioButton
                                            className="form-radio-presto"
                                            inputId="generar_carta_si"
                                            checked={form?.generar_carta === true}
                                            disabled={isDisabled}
                                            onChange={() => updateField('generar_carta', true)}
                                        />

                                        <label
                                            htmlFor="generar_carta_si"
                                            className="text-sm text-gray-700"
                                        >
                                            Sí
                                        </label>
                                    </div>

                                    <div className="flex items-center gap-2">
                                        <RadioButton
                                            className="form-radio-presto"
                                            inputId="generar_carta_no"
                                            checked={form?.generar_carta === false}
                                            disabled={isDisabled}
                                            onChange={() => updateField('generar_carta', false)}
                                        />

                                        <label
                                            htmlFor="generar_carta_no"
                                            className="text-sm text-gray-700"
                                        >
                                            No
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div className="flex flex-col gap-1">
                                <label className="font-semibold text-sm">Tipo de carta resguardo</label>
                                <Dropdown
                                    value={form?.tipo_carta ?? null}
                                    options={controlesGenerarCartaResguardo.tipocarta}
                                    optionLabel="description"
                                    optionValue="code"
                                    disabled={isDisabled}
                                    className="form-dropdown-presto w-full"
                                    placeholder="Seleccione"
                                    onChange={(e) => updateField('tipo_carta', e.value)}
                                    showClear
                                />
                            </div>


                            <div className="flex flex-col gap-2 md:col-span-3">
                                <label className="font-semibold text-sm">Subsanar</label>

                                <div className="flex items-center gap-2 h-11">
                                    <Checkbox
                                        className="form-checkbox-presto"
                                        inputId="enviar_a_reparo"
                                        checked={form.enviar_a_reparo}
                                        onChange={handleEnviarAReparoChange}
                                        disabled={isDisabled}
                                    />
                                    <label htmlFor="enviar_a_reparo" className="text-sm">
                                        ¿Enviar a reparo?
                                    </label>
                                </div>
                            </div>

                            <div className="flex flex-col gap-1 md:col-span-3">
  <label className="font-semibold text-sm">
    Observaciones
  </label>
  <InputTextarea
    value={form.observaciones ?? ""}
    onChange={(e) => updateField("observaciones", e.target.value)}
    rows={4}
    maxLength={1000}
    className="form-textarea-presto w-full"
    disabled={isDisabled}
    placeholder="Ingrese observaciones (máximo 1000 caracteres)"
    style={{ resize: "none" }}
  />
  <div className="flex justify-end mt-1 text-xs">
    <span className={
      (form.observaciones?.length ?? 0) >= 1000 
        ? "text-red-600" 
        : (form.observaciones?.length ?? 0) >= 900 
          ? "text-orange-500" 
          : "text-gray-500"
    }>
      {form.observaciones?.length ?? 0}
    </span>
    <span className="mx-1 text-gray-500">/</span>
    <span className="text-gray-500">1000</span>
  </div>
</div>
                        </div>

                        <ActivityActionBar
                          from_tracking={fromTracking}
                          is_busy={isBusy}
                          is_disabled={isDisabled}
                          can_advance={canAdvance}
                          is_saving={saveMutation.isPending}
                          is_advancing={avanzarMutation.isPending}
                          on_edit={handleEditar}
                          on_save={handleGuardar}
                          on_advance={handleAvanzar}
                          on_exit={handleSalir}
                        />
                    </Card>
                </AccordionTab>
            </Accordion>
        </>
    );
}