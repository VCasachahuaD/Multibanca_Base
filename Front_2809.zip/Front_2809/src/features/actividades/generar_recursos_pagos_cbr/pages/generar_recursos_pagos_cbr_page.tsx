import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Accordion, AccordionTab } from "primereact/accordion";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";

import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";
import type { GenerarRecursosPagosCbr } from "../models/generar_recursos_pagos_cbr";
import { useAvanzarGenerarRecursosPagosCbr } from "../hooks/useAvanzarGenerarRecursosPagosCbr";
import { useGenerarRecursosPagosCbr } from "../hooks/useGenerarRecursosPagosCbr";
import { useUpsertGenerarRecursosPagosCbr } from "../hooks/useUpsertGenerarRecursosPagosCbr";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const ACTIVITY_ID = "_Se4Q_M3xHebPv7_X8uN5b";

const buildInitialState = (id_expediente: number): GenerarRecursosPagosCbr => ({
  id_generar_recursos_pagos_cbr: 0,
  id_expediente,
  observaciones: "",
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: new Date().toISOString(),
  modified_by: null,
  modified_date: null,
});

const normalizeGenerarRecursosPagosCbr = (
  source: Partial<GenerarRecursosPagosCbr> | null | undefined,
  id_expediente_fallback: number,
): GenerarRecursosPagosCbr => {
  return {
    id_generar_recursos_pagos_cbr: Number(source?.id_generar_recursos_pagos_cbr ?? 0),
    id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    observaciones: source?.observaciones ?? "",
    is_active: source?.is_active ?? true,
    row_status: source?.row_status ?? true,
    created_by: Number(source?.created_by ?? 0),
    created_date: source?.created_date ?? new Date().toISOString(),
    modified_by: source?.modified_by ?? null,
    modified_date: source?.modified_date ?? null,
  };
};

export default function GenerarRecursosPagosCbrPage() {
  const toast = useRef<Toast>(null);

  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: idExpedienteParam } = useParams();
  const { fromTracking = false } = location.state || {};

  const id_expediente = Number(idExpedienteParam ?? 0);

  const [form, setForm] = useState<GenerarRecursosPagosCbr>(
    buildInitialState(id_expediente),
  );
  const [isDisabled, setIsDisabled] = useState(true);
  const [canAdvance, setCanAdvance] = useState(false);
  const [isBusy, setIsBusy] = useState(false);

  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef<number>(id_expediente);

  const { data, isLoading } = useGenerarRecursosPagosCbr(id_expediente);
  const saveMutation = useUpsertGenerarRecursosPagosCbr();
  const avanzarMutation = useAvanzarGenerarRecursosPagosCbr();

  useEffect(() => {
    if (currentExpedienteRef.current !== id_expediente) {
      currentExpedienteRef.current = id_expediente;
      hasHydratedRef.current = false;

      setForm(buildInitialState(id_expediente));
      setIsDisabled(true);
      setCanAdvance(false);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (data?.status && data.detail) {
      const loadedEntity = normalizeGenerarRecursosPagosCbr(
        data.detail,
        id_expediente,
      );

      setForm(loadedEntity);
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (!id_expediente || id_expediente <= 0) {
      setForm(buildInitialState(0));
      setIsDisabled(false);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (data) {
      setForm((prev) =>
        normalizeGenerarRecursosPagosCbr(
          {
            ...prev,
            id_expediente,
          },
          id_expediente,
        ),
      );
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
    }
  }, [data, id_expediente]);

  const updateField = <K extends keyof GenerarRecursosPagosCbr>(
    field: K,
    value: GenerarRecursosPagosCbr[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleEditar = () => {
    setIsDisabled(false);
    setCanAdvance(false);
  };

  const validateForm = () => {
    if (!form.id_expediente || form.id_expediente <= 0) {
      return "No existe un id_expediente válido.";
    }

    return "";
  };

  const handleGuardar = async () => {
    const validationMessage = validateForm();
    if (validationMessage) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: validationMessage,
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);

      const payload: GenerarRecursosPagosCbr = normalizeGenerarRecursosPagosCbr(
        {
          ...form,
          id_generar_recursos_pagos_cbr: Number(
            form.id_generar_recursos_pagos_cbr ?? 0,
          ),
          id_expediente: Number(form.id_expediente || id_expediente || 0),
        },
        id_expediente,
      );

      const response = await saveMutation.mutateAsync(payload);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Actividad Generar recursos pagos CBR guardada correctamente",
          life: 3000,
        });

        const savedEntity = normalizeGenerarRecursosPagosCbr(
          response.detail ?? payload,
          payload.id_expediente,
        );

        setForm(savedEntity);
        setIsDisabled(true);
        setCanAdvance(true);
        hasHydratedRef.current = true;
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: response.message || "No se pudo guardar",
          life: 3000,
        });
      }
    } catch (error) {
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Ocurrió un error al guardar",
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleAvanzar = async () => {
    const validationMessage = validateForm();
    if (validationMessage) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: validationMessage,
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);

      const response = await avanzarMutation.mutateAsync(Number(form.id_expediente));

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Actividad avanzada correctamente",
          life: 2000,
        });

        navigate("/home/bandeja");
      } else {
        const msg = response.message || "No se pudo avanzar la actividad.";

        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: msg,
          life: 3000,
        });
      }
    } catch (error) {
      const msg = "Ocurrió un error al avanzar.";

      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: msg,
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleSalir = () => {
    navigate("/home/bandeja");
  };

  return (
    <>
      <Toast ref={toast} />

      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Generar recursos pagos CBR
      </h2>

      <Accordion activeIndex={[0, 2]} multiple>
        <AccordionTab
          disabled={!id_expediente || id_expediente <= 0}
          header="Información del Expediente"
        >
          <EncabezadoActividad
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            activityID={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab
          header="Funciones Transversales"
          disabled={!id_expediente || id_expediente <= 0}
        >
          <FuncionesTransversales
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            idActividad={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header="Generar recursos pagos CBR">
          <Card className="w-full shadow-md card-presto-form mb-6">
            {isLoading && id_expediente > 0 && (
              <div className="mb-4 text-sm text-blue-600">
                Cargando información...
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="flex flex-col gap-1 md:col-span-3">
  <label className="font-semibold text-sm">
    Observaciones
  </label>
  <InputTextarea
    value={form.observaciones ?? ""}
    onChange={(e) => updateField("observaciones", e.target.value)}
    rows={5}
    maxLength={1000}
    className="form-textarea-presto w-full"
    disabled={isDisabled}
    placeholder="Ingrese observaciones (máximo 1000 caracteres)"
    style={{ resize: "none" }}
  />
  <div className="flex justify-end mt-1 text-xs">
    <span className={
      (form.observaciones?.length ?? 0) >= 1000 
        ? "text-red-600" 
        : (form.observaciones?.length ?? 0) >= 900 
          ? "text-orange-500" 
          : "text-gray-500"
    }>
      {form.observaciones?.length ?? 0}
    </span>
    <span className="mx-1 text-gray-500">/</span>
    <span className="text-gray-500">1000</span>
  </div>
</div>
            </div>

            <ActivityActionBar
              from_tracking={fromTracking}
              is_busy={isBusy}
              is_disabled={isDisabled}
              can_advance={canAdvance}
              is_saving={saveMutation.isPending}
              is_advancing={avanzarMutation.isPending}
              on_edit={handleEditar}
              on_save={handleGuardar}
              on_advance={handleAvanzar}
              on_exit={handleSalir}
            />
          </Card>
        </AccordionTab>
      </Accordion>
    </>
  );
}