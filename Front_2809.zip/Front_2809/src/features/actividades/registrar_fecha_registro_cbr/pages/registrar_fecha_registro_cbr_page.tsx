import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Accordion, AccordionTab } from "primereact/accordion";
import { Button } from "primereact/button";
import { Calendar } from "primereact/calendar";
import { Card } from "primereact/card";
import { InputNumber } from "primereact/inputnumber";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";

import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";
import type { RegistrarFechaRegistroCbr } from "../models/registrar_fecha_registro_cbr";
import { useAvanzarRegistrarFechaRegistroCbr } from "../hooks/useAvanzarRegistrarFechaRegistroCbr";
import { useRegistrarFechaRegistroCbr } from "../hooks/useRegistrarFechaRegistroCbr";
import { useUpsertRegistrarFechaRegistroCbr } from "../hooks/useUpsertRegistrarFechaRegistroCbr";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const ACTIVITY_ID = "_Vh5T_Q1aKeaSy8_A9xR6e";

const buildInitialState = (id_expediente: number): RegistrarFechaRegistroCbr => ({
  id_registrar_fecha_registro_cbr: 0,
  id_expediente,
  fecha_registro_cbr: new Date().toISOString(),
  observaciones: "",
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: new Date().toISOString(),
  modified_by: null,
  modified_date: null,
});

const normalizeRegistrarFechaRegistroCbr = (
  source: Partial<RegistrarFechaRegistroCbr> | null | undefined,
  id_expediente_fallback: number,
): RegistrarFechaRegistroCbr => {
  return {
    id_registrar_fecha_registro_cbr: Number(source?.id_registrar_fecha_registro_cbr ?? 0),
    id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    fecha_registro_cbr: source?.fecha_registro_cbr ?? new Date().toISOString(),
    observaciones: source?.observaciones ?? "",
    is_active: source?.is_active ?? true,
    row_status: source?.row_status ?? true,
    created_by: Number(source?.created_by ?? 0),
    created_date: source?.created_date ?? new Date().toISOString(),
    modified_by: source?.modified_by ?? null,
    modified_date: source?.modified_date ?? null,
  };
};

export default function RegistrarFechaRegistroCbrPage() {
  const toast = useRef<Toast>(null);

  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: idExpedienteParam } = useParams();
  const { fromTracking = false } = location.state || {};

  const id_expediente = Number(idExpedienteParam ?? 0);

  const [form, setForm] = useState<RegistrarFechaRegistroCbr>(
    buildInitialState(id_expediente),
  );
  const [isDisabled, setIsDisabled] = useState(true);
  const [canAdvance, setCanAdvance] = useState(false);
  const [isBusy, setIsBusy] = useState(false);

  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef<number>(id_expediente);

  const { data, isLoading } = useRegistrarFechaRegistroCbr(id_expediente);
  const saveMutation = useUpsertRegistrarFechaRegistroCbr();
  const avanzarMutation = useAvanzarRegistrarFechaRegistroCbr();

  useEffect(() => {
    if (currentExpedienteRef.current !== id_expediente) {
      currentExpedienteRef.current = id_expediente;
      hasHydratedRef.current = false;

      setForm(buildInitialState(id_expediente));
      setIsDisabled(true);
      setCanAdvance(false);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (data?.status && data.detail) {
      const loadedEntity = normalizeRegistrarFechaRegistroCbr(
        data.detail,
        id_expediente,
      );

      setForm(loadedEntity);
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (!id_expediente || id_expediente <= 0) {
      setForm(buildInitialState(0));
      setIsDisabled(false);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (data) {
      setForm((prev) =>
        normalizeRegistrarFechaRegistroCbr(
          {
            ...prev,
            id_expediente,
          },
          id_expediente,
        ),
      );
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
    }
  }, [data, id_expediente]);

  const updateField = <K extends keyof RegistrarFechaRegistroCbr>(
    field: K,
    value: RegistrarFechaRegistroCbr[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleEditar = () => {
    setIsDisabled(false);
    setCanAdvance(false);
  };

  const validateForm = () => {
    if (!form.id_expediente || form.id_expediente <= 0) {
      return "No existe un id_expediente válido.";
    }

    if (!form.fecha_registro_cbr) {
      return "La fecha de registro CBR es obligatoria.";
    }

    if (!form.observaciones?.trim()) {
      return "Las observaciones son obligatorias.";
    }

    return "";
  };

  const handleGuardar = async () => {

    const validationMessage = validateForm();
    if (validationMessage) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: validationMessage,
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);

      const payload: RegistrarFechaRegistroCbr = normalizeRegistrarFechaRegistroCbr(
        {
          ...form,
          id_registrar_fecha_registro_cbr: Number(
            form.id_registrar_fecha_registro_cbr ?? 0,
          ),
          id_expediente: Number(form.id_expediente || id_expediente || 0),
        },
        id_expediente,
      );

      const response = await saveMutation.mutateAsync(payload);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Actividad Registrar Fecha Registro CBR guardada correctamente",
          life: 3000,
        });

        const savedEntity = normalizeRegistrarFechaRegistroCbr(
          response.detail ?? payload,
          payload.id_expediente,
        );

        setForm(savedEntity);
        setIsDisabled(true);
        setCanAdvance(true);
        hasHydratedRef.current = true;
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: response.message || "No se pudo guardar",
          life: 3000,
        });
      }
    } catch (error) {
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Ocurrió un error al guardar",
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleAvanzar = async () => {
    const validationMessage = validateForm();
    if (validationMessage) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: validationMessage,
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);

      const response = await avanzarMutation.mutateAsync(Number(form.id_expediente));

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Actividad avanzada correctamente",
          life: 2000,
        });

        navigate("/home/bandeja");
      } else {
        const msg = response.message || "No se pudo avanzar la actividad.";
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: msg,
          life: 3000,
        });
      }
    } catch (error) {
      const msg = "Ocurrió un error al avanzar.";

      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: msg,
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleSalir = () => {
    navigate("/home/bandeja");
  };

  const fecha_as_date = form.fecha_registro_cbr
    ? new Date(form.fecha_registro_cbr)
    : new Date();

  return (
    <>
      <Toast ref={toast} />

      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Registrar Fecha Registro CBR
      </h2>

      <Accordion activeIndex={[0, 2]} multiple>
        <AccordionTab
          disabled={!id_expediente || id_expediente <= 0}
          header="Información del Expediente"
        >
          <EncabezadoActividad
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            activityID={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab
          header="Funciones Transversales"
          disabled={!id_expediente || id_expediente <= 0}
        >
          <FuncionesTransversales
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            idActividad={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header="Registrar Fecha Registro CBR">
          <Card className="w-full shadow-md card-presto-form mb-6">
            {isLoading && id_expediente > 0 && (
              <div className="mb-4 text-sm text-blue-600">
                Cargando información...
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="flex flex-col gap-1">
                <label className="font-semibold text-sm">
                  Fecha Registro CBR <span className="text-red-500">*</span>
                </label>
                <Calendar
                  value={fecha_as_date}
                  onChange={(e) => {
                    const val = e.value as Date | null;
                    updateField(
                      "fecha_registro_cbr",
                      val ? val.toISOString() : new Date().toISOString(),
                    );
                  }}
                  dateFormat="dd/mm/yy"
                  disabled={isDisabled}
                  className="calendar-presto"
                />
              </div>

              <div className="flex flex-col gap-1 md:col-span-3">
                <label className="font-semibold text-sm">
                  Observaciones <span className="text-red-500">*</span>
                </label>
                <InputTextarea
                  value={form.observaciones ?? ""}
                  onChange={(e) => updateField("observaciones", e.target.value)}
                  rows={4}
                  maxLength={1000}
                  className="form-textarea-presto w-full"
                  disabled={isDisabled}
                  placeholder="Ingrese observaciones (máximo 1000 caracteres)"
                  style={{ resize: "none" }}
                />
                <div className="flex justify-end mt-1 text-xs">
                  <span className={
                    (form.observaciones?.length ?? 0) >= 1000 
                      ? "text-red-600" 
                      : (form.observaciones?.length ?? 0) >= 900 
                        ? "text-orange-500" 
                        : "text-gray-500"
                  }>
                    {form.observaciones?.length ?? 0}
                  </span>
                  <span className="mx-1 text-gray-500">/</span>
                  <span className="text-gray-500">1000</span>
                </div>
              </div>
            </div>

            <ActivityActionBar
              from_tracking={fromTracking}
              is_busy={isBusy}
              is_disabled={isDisabled}
              can_advance={canAdvance}
              is_saving={saveMutation.isPending}
              is_advancing={avanzarMutation.isPending}
              on_edit={handleEditar}
              on_save={handleGuardar}
              on_advance={handleAvanzar}
              on_exit={handleSalir}
            />
          </Card>
        </AccordionTab>
      </Accordion>
    </>
  );
}