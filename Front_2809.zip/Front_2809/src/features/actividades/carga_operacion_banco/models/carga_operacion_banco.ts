export interface CargaOperacionBancoDatosOperacion {
  id_carga_operacion_banco_datos_operacion: number;
  id_carga_operacion_banco: number;
  id_expediente: number;

  nro_mutuo?: number | null;
  tipo_operacion?: string | null;
  nro_registro?: number | null;
  ult_clasif_al?: string | null;
  segmento?: string | null;
  canal_venta?: string | null;
  nro_op_cartera?: number | null;
  modelo_operacion?: string | null;
  tipo_carpeta?: string | null;
  propietario?: string | null;
  inmobiliaria?: string | null;
  glosa_producto?: string | null;
  codigo_producto_comercial?: string | null;
  nro_piloto?: number | null;
  banco_alzante?: string | null;
  nombre_proyecto?: string | null;

  is_active: boolean;
  row_status: boolean;
  created_by: number;
  created_date: string;
  modified_by?: number | null;
  modified_date?: string | null;
}

export interface CargaOperacionBancoAntecedenteComprador {
  id_carga_operacion_banco_antecedente_comprador: number;
  id_carga_operacion_banco: number;
  id_expediente: number;

  rut?: string | null;
  tipo_comprador?: string | null;
  razon_social?: string | null;
  nombres?: string | null;
  apellido_paterno?: string | null;
  apellido_materno?: string | null;
  fecha_nacimiento?: string | null;
  genero?: string | null;
  estado_civil?: string | null;
  relacion_titular?: string | null;
  direccion?: string | null;
  region?: string | null;
  comuna?: string | null;
  telefono?: string | null;
  email?: string | null;
  nacionalidad?: string | null;
  profesion?: string | null;

  is_active: boolean;
  row_status: boolean;
  created_by: number;
  created_date: string;
  modified_by?: number | null;
  modified_date?: string | null;
}

export interface CargaOperacionBancoAntecedenteVendedor {
  id_carga_operacion_banco_antecedente_vendedor: number;
  id_carga_operacion_banco: number;
  id_expediente: number;

  rut?: string | null;
  tipo_vendedor?: string | null;
  razon_social?: string | null;
  nombres?: string | null;
  apellido_paterno?: string | null;
  apellido_materno?: string | null;
  fecha_nacimiento?: string | null;
  genero?: string | null;
  estado_civil?: string | null;
  relacion_titular?: string | null;
  direccion?: string | null;
  region?: string | null;
  comuna?: string | null;
  telefono?: string | null;
  email?: string | null;
  nacionalidad?: string | null;
  profesion?: string | null;

  is_active: boolean;
  row_status: boolean;
  created_by: number;
  created_date: string;
  modified_by?: number | null;
  modified_date?: string | null;
}


export interface CargaOperacionBancoAntecedenteCredito {
  id_carga_operacion_banco_antecedente_credito: number;
  id_carga_operacion_banco: number;
  id_expediente: number;

  tipo_prestamo?: string | null;
  factor_conversion_uf?: number | null;
  destino_credito?: string | null;
  monto_solicitado?: number | null;
  tipo_tasa?: string | null;
  tasa?: number | null;
  plazo?: number | null;
  fecha_inicio?: string | null;
  monto_nominal?: number | null;
  monto_residual?: number | null;
  plazo_primer_periodo?: number | null;
  periodo_gracia?: number | null;
  comision?: number | null;
  plazo_segundo_periodo?: number | null;
  tasa_primer_periodo?: number | null;
  meses_sabaticos?: number | null;
  variabilidad_tasa?: string | null;
  tasa_segundo_periodo?: number | null;
  moneda?: string | null;
  tipo_tasa_mixta_prod_com?: string | null;
  tasa_maxima?: number | null;
  codigo_producto_cartera?: string | null;
  indicador_segunda_vivienda?: string | null;
  tipo_financiamiento?: string | null;
  precio_venta_pesos?: number | null;
  precio_venta_moneda_original?: number | null;
  cantidad_meses_sin_vencimiento?: number | null;
  indicador_cred_comp?: number | null;
  indicador_pac?: string | null;
  tipo_tasa_aplic_contab?: string | null;
  numero_cuenta_gastos?: number | null;
  prestamo_maximo?: number | null;

  is_active: boolean;
  row_status: boolean;
  created_by: number;
  created_date: string;
  modified_by?: number | null;
  modified_date?: string | null;
}

export interface CargaOperacionBancoDatosComercial {
  id_carga_operacion_banco_datos_comercial: number;
  id_carga_operacion_banco: number;
  id_expediente: number;

  codigo_ejecutivo?: number | null;
  login_ejecutivo?: string | null;
  nombre_ejecutivo?: string | null;
  rut_ejecutivo?: string | null;
  codigo_oficina?: number | null;
  nombre_oficina?: string | null;
  codigo_curse?: number | null;
  glosa_curse?: string | null;
  codigo_ejecutivo_curse?: number | null;
  login_ejecutivo_curse?: string | null;
  nombre_ejecutivo_curse?: string | null;
  rut_ejecutivo_curse?: string | null;
  rut_banco?: string | null;
  renovacion_urbana?: string | null;
  nombre_banco?: string | null;
  tipo_hipoteca?: string | null;

  is_active: boolean;
  row_status: boolean;
  created_by: number;
  created_date: string;
  modified_by?: number | null;
  modified_date?: string | null;
}

export interface CargaOperacionBanco {
  id_carga_operacion_banco: number;
  id_expediente: number;

  is_active: boolean;
  row_status: boolean;
  created_by: number;
  created_date: string;
  modified_by?: number | null;
  modified_date?: string | null;

  datos_operacion?: CargaOperacionBancoDatosOperacion | null;
  antecedentes_comprador?: CargaOperacionBancoAntecedenteComprador[] | null;
  antecedentes_vendedor?: CargaOperacionBancoAntecedenteVendedor[] | null;
  antecedente_credito?: CargaOperacionBancoAntecedenteCredito | null;
  datos_comercial?: CargaOperacionBancoDatosComercial | null;
}
