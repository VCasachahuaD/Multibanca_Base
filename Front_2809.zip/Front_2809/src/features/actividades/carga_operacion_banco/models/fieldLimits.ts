/**
 * Límites de longitud (maxLength) de los inputs de Carga Operación Banco.
 *
 * MAPA POR ACTIVIDAD: tamaños de columna declarados en los EntityConfig del backend
 * (`Data.Repository.Implementations/EntityConfig/Multibanca/CargaOperacionBanco/*.cs`).
 *
 * Los números de NEGOCIO (RUT, teléfonos, email) NO se definen acá: vienen de
 * `@/shared/utils/fieldLimits` para que sean iguales en todas las actividades.
 *
 * REGLAS
 *  - Ningún componente debe llevar números: usar siempre `limitOf('nombre_campo')`.
 *  - La clave es el nombre snake_case del campo, idéntico al `data-field` del JSX.
 *  - Para cambiar un límite basta editar UNA línea de este archivo.
 *  - Los Dropdown (catálogos) y Calendar no tienen límite de caracteres.
 *
 * NOTA: para los campos SIN regla de negocio (texto libre) se aplica el ancho de la
 * columna como techo, para no bloquear un dato que hoy el backend acepte. Las
 * longitudes propuestas por negocio están en `SUGGESTED_LIMITS`, sin aplicar.
 */

import { EMAIL_MAX_LENGTH, RUT_MAX, TELEFONO_FIJO_MAX } from '@/shared/utils/fieldLimits';

/** Datos de la Operación */
export const DATOS_OPERACION_LIMITS = {
  nro_mutuo: 19, // bigint
  nro_registro: 19, // bigint
  nro_op_cartera: 19, // bigint
  nro_piloto: 10, // int
  ult_clasif_al: 200, // varchar(200)
  propietario: 150, // varchar(150)
  nombre_proyecto: 250, // varchar(250)
} as const;

/** Antecedentes del Comprador y del Vendedor (mismas columnas en ambas tablas) */
export const ANTECEDENTES_LIMITS = {
  rut: RUT_MAX, // regla de negocio (columna: varchar(12))
  razon_social: 250, // varchar(250)
  nombres: 150, // varchar(150)
  apellido_paterno: 100, // varchar(100)
  apellido_materno: 100, // varchar(100)
  direccion: 250, // varchar(250)
  telefono: TELEFONO_FIJO_MAX, // regla de negocio: 9 dígitos CON código de área (columna: varchar(20))
  email: EMAIL_MAX_LENGTH, // tope de negocio (columna: varchar(150))
  profesion: 150, // varchar(150)
} as const;

/** Antecedentes del Crédito */
export const CREDITO_LIMITS = {
  // numeric(18, 6) -> 12 enteros + 6 decimales = 19 caracteres con el punto
  factor_conversion_uf: 19,
  monto_solicitado: 19,
  tasa: 19,
  monto_nominal: 19,
  monto_residual: 19,
  comision: 19,
  tasa_primer_periodo: 19,
  tasa_segundo_periodo: 19,
  tasa_maxima: 19,
  precio_venta_pesos: 19,
  precio_venta_moneda_original: 19,
  prestamo_maximo: 19,

  // int -> 10 dígitos
  plazo: 10,
  plazo_primer_periodo: 10,
  periodo_gracia: 10,
  plazo_segundo_periodo: 10,
  meses_sabaticos: 10,
  cantidad_meses_sin_vencimiento: 10,
  indicador_cred_comp: 10,
  numero_cuenta_gastos: 10,

  // varchar
  variabilidad_tasa: 100, // varchar(100)
  tipo_tasa_mixta_prod_com: 100, // varchar(100)
  codigo_producto_cartera: 100, // varchar(100)
  tipo_tasa_aplic_contab: 100, // varchar(100)
  indicador_segunda_vivienda: 50, // varchar(50)
  indicador_pac: 50, // varchar(50)
} as const;

/** Datos Comerciales */
export const COMERCIAL_LIMITS = {
  codigo_ejecutivo: 19, // bigint
  codigo_oficina: 19, // bigint
  codigo_curse: 19, // bigint
  codigo_ejecutivo_curse: 19, // bigint
  login_ejecutivo: 100, // varchar(100)
  login_ejecutivo_curse: 100, // varchar(100)
  nombre_ejecutivo: 150, // varchar(150)
  nombre_ejecutivo_curse: 150, // varchar(150)
  nombre_oficina: 150, // varchar(150)
  renovacion_urbana: 150, // varchar(150)
  nombre_banco: 150, // varchar(150)
  glosa_curse: 250, // varchar(250)
  rut_ejecutivo: RUT_MAX, // regla de negocio (columna: varchar(12))
  rut_ejecutivo_curse: RUT_MAX, // regla de negocio (columna: varchar(12))
  rut_banco: RUT_MAX, // regla de negocio (columna: varchar(12))
} as const;

export const FIELD_LIMITS: Record<string, number> = {
  ...DATOS_OPERACION_LIMITS,
  ...ANTECEDENTES_LIMITS,
  ...CREDITO_LIMITS,
  ...COMERCIAL_LIMITS,
};

/**
 * Longitudes propuestas por negocio, PENDIENTES de confirmar contra el diccionario
 * de datos. NO se aplican todavía: el valor vigente es el de la columna (FIELD_LIMITS).
 * Para activar una: mover el número a FIELD_LIMITS y borrar su TODO.
 *
 * TODO diccionario: campos que parecen códigos/indicadores (columna demasiado generosa)
 */
export const SUGGESTED_LIMITS: Record<string, number> = {
  // TODO diccionario
  indicador_segunda_vivienda: 5, // admite S/N, SI/NO o código '001' (columna: 50)
  indicador_pac: 5, // admite S/N, SI/NO o código '001' (columna: 50)
  indicador_cred_comp: 3, // admite 0/1 o '001' (columna: int)
  codigo_producto_cartera: 10, // es un código de catálogo (columna: 100)
  tipo_tasa_mixta_prod_com: 30, // nombre/código del producto (columna: 100)
  tipo_tasa_aplic_contab: 30, // descripción breve (columna: 100)
  variabilidad_tasa: 20, // Fija/Variable/Semestral (columna: 100)
  ult_clasif_al: 20, // clasificación corta (columna: 200)
  renovacion_urbana: 50, // 2 si fuera flag S/N (columna: 150)

  // TODO diccionario: identificadores
  nro_mutuo: 12, // columna: bigint (19)
  nro_registro: 12, // columna: bigint (19)
  nro_op_cartera: 12, // columna: bigint (19)
  nro_piloto: 8, // columna: int (10)
};

/**
 * Devuelve el maxLength del campo indicado (mismo nombre que su `data-field`).
 * @param field nombre snake_case del campo, p. ej. "nombre_proyecto".
 */
export function limitOf(field: string): number | undefined {
  return FIELD_LIMITS[field];
}
