import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { useAuth } from '@/app/providers/AuthProvider';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import { Toast } from 'primereact/toast';

import EncabezadoActividad from '@/features/encabezado/pages/EncabezadoActividad';
import FuncionesTransversales from '@/features/funciones_transversales/pages/FuncionesTransversales';
import {
  clearFieldErrors,
  focusFieldByKey,
} from '@/features/actividades/datos_operacion/utils/fieldFocus';
import { getErrorMessage } from '@/core/errors/getErrorMessage';
import { formatRutSinPuntos, isValidRutSinPuntos, describeRutError } from '@/shared/utils/rut';
import { describeFechaNacimientoError } from '@/shared/utils/dateCoherence';
import { describeEmailError } from '@/shared/utils/chileanValidators';
import {
  describeDireccionError,
  describeNombrePersonaError,
  describeRazonSocialError,
} from '@/shared/utils/textValidators';
import AntecedenteCreditoSection from '../components/AntecedenteCreditoSection';
import AntecedentesCompradorSection from '../components/AntecedentesCompradorSection';
import AntecedentesVendedorSection from '../components/AntecedentesVendedorSection';
import DatosComercialSection from '../components/DatosComercialSection';
import DatosOperacionSection from '../components/DatosOperacionSection';
import { useAvanzarCargaOperacionBanco } from '../hooks/useAvanzarCargaOperacionBanco';
import { useCargaOperacionBanco } from '../hooks/useCargaOperacionBanco';
import { useControlesAntecedenteComprador } from '../hooks/useControlesAntecedenteComprador';
import { useControlesAntecedenteCredito } from '../hooks/useControlesAntecedenteCredito';
import { useControlesAntecedenteVendedor } from '../hooks/useControlesAntecedenteVendedor';
import { useControlesDatosComercial } from '../hooks/useControlesDatosComercial';
import { useControlesDatosOperacion } from '../hooks/useControlesDatosOperacion';
import { useUpsertCargaOperacionBanco } from '../hooks/useUpsertCargaOperacionBanco';
import {
  EMPTY_CONTROLES_ANTECEDENTE_COMPRADOR,
  EMPTY_CONTROLES_ANTECEDENTE_CREDITO,
  EMPTY_CONTROLES_ANTECEDENTE_VENDEDOR,
  EMPTY_CONTROLES_DATOS_COMERCIAL,
  EMPTY_CONTROLES_DATOS_OPERACION,
  type CatalogoOption,
  type ControlesAntecedenteComprador,
  type ControlesAntecedenteCredito,
  type ControlesAntecedenteVendedor,
  type ControlesDatosComercial,
  type ControlesDatosOperacion,
} from '../models/catalogo';
import type {
  CargaOperacionBanco,
  CargaOperacionBancoAntecedenteComprador,
  CargaOperacionBancoAntecedenteCredito,
  CargaOperacionBancoAntecedenteVendedor,
  CargaOperacionBancoDatosComercial,
  CargaOperacionBancoDatosOperacion,
} from '../models/carga_operacion_banco';

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
import RequiredMark from '@/shared/components/RequiredMark';
const ACTIVITY_ID = '_4X3k8H6kEeeGvo3jOJ1wYw';

/**
 * Fila guardada que no pasó la validación de obligatorios. Se usa para, además
 * de resaltar la sección, abrir el diálogo de ESA fila y enfocar el campo
 * pendiente (navegación al input).
 */
type FilaInvalida =
  | { tipo: 'comprador'; row: CargaOperacionBancoAntecedenteComprador }
  | { tipo: 'vendedor'; row: CargaOperacionBancoAntecedenteVendedor };

const now = () => new Date().toISOString();

/**
 * Normaliza descripciones de catálogo: sin acentos, en minúsculas y con
 * espacios simples, para comparar de forma tolerante.
 */
const normalizarTexto = (value: string): string =>
  value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();

/**
 * Descripción de una opción de catálogo a partir de su código. El `code` viene
 * numérico ('01'/'02'), por eso se compara también sin ceros a la izquierda.
 */
const catalogoDescripcion = (
  options: CatalogoOption[],
  code: string | number | null | undefined,
): string => {
  const buscado = String(code ?? '').trim();
  if (!buscado) return '';

  const option = options.find((item) => {
    const itemCode = String(item.code ?? '').trim();

    return (
      itemCode === buscado ||
      itemCode.replace(/^0+/, '') === buscado.replace(/^0+/, '')
    );
  });

  return option?.description ?? '';
};

/**
 * Indica si el valor seleccionado corresponde a una opción cuya descripción
 * contiene `raiz` (ej: "asoc" → Asociada). Se resuelve contra el mismo catálogo
 * que llena el select; si el código no resuelve, se compara el propio valor
 * (respaldo por si viniera la descripción en lugar del código).
 */
const coincideOpcion = (
  options: CatalogoOption[],
  valor: string | number | null | undefined,
  raiz: string,
): boolean => {
  const descripcion = normalizarTexto(catalogoDescripcion(options, valor));

  return descripcion
    ? descripcion.includes(raiz)
    : normalizarTexto(String(valor ?? '')).includes(raiz);
};

/**
 * Un campo numérico está "vacío" solo si es null/undefined: el 0 es un valor válido
 * (Comisión, Periodo de Gracia, Monto Residual, indicadores, etc.).
 */
const esNumeroVacio = (valor: number | null | undefined): boolean =>
  valor === null || valor === undefined;

/**
 * Convierte a número un valor opcional que puede venir del backend. Devuelve null si viene
 * vacío o si no es numérico: en `precio_venta_moneda_original` quedó guardado el literal 'UF'
 * mientras el campo se trataba como texto, y Number('UF') es NaN.
 */
const toNumeroOpcional = (valor: unknown): number | null => {
  if (valor === undefined || valor === null || valor === '') return null;

  const numero = Number(valor);
  return Number.isFinite(numero) ? numero : null;
};

// Defaults de Antecedentes del Crédito (NC.6) según catálogos:
// TIPO_TASA: Preferencial = "04" | MONEDA: Unidad de Fomento = "UF"
const DEFAULT_TIPO_TASA = '04';
const DEFAULT_MONEDA = 'UF';

const buildDatosOperacionInitialState = (
  id_expediente: number,
): CargaOperacionBancoDatosOperacion => ({
  id_carga_operacion_banco_datos_operacion: 0,
  id_carga_operacion_banco: 0,
  id_expediente,
  nro_mutuo: null,
  tipo_operacion: null,
  nro_registro: null,
  ult_clasif_al: '',
  segmento: null,
  canal_venta: null,
  nro_op_cartera: null,
  modelo_operacion: null,
  tipo_carpeta: null,
  propietario: '',
  inmobiliaria: null,
  glosa_producto: null,
  codigo_producto_comercial: null,
  nro_piloto: null,
  banco_alzante: null,
  nombre_proyecto: '',
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const buildCompradorInitialState = (
  id_expediente: number,
  id_carga_operacion_banco = 0,
): CargaOperacionBancoAntecedenteComprador => ({
  id_carga_operacion_banco_antecedente_comprador: 0,
  id_carga_operacion_banco,
  id_expediente,
  rut: '',
  tipo_comprador: null,
  razon_social: '',
  nombres: '',
  apellido_paterno: '',
  apellido_materno: '',
  fecha_nacimiento: null,
  genero: null,
  estado_civil: null,
  relacion_titular: null,
  direccion: '',
  region: null,
  comuna: null,
  telefono: '',
  email: '',
  nacionalidad: null,
  profesion: '',
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const buildVendedorInitialState = (
  id_expediente: number,
  id_carga_operacion_banco = 0,
): CargaOperacionBancoAntecedenteVendedor => ({
  id_carga_operacion_banco_antecedente_vendedor: 0,
  id_carga_operacion_banco,
  id_expediente,
  rut: '',
  tipo_vendedor: null,
  razon_social: '',
  nombres: '',
  apellido_paterno: '',
  apellido_materno: '',
  fecha_nacimiento: null,
  genero: null,
  estado_civil: null,
  relacion_titular: null,
  direccion: '',
  region: null,
  comuna: null,
  telefono: '',
  email: '',
  nacionalidad: null,
  profesion: '',
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const buildAntecedenteCreditoInitialState = (
  id_expediente: number,
  id_carga_operacion_banco = 0,
): CargaOperacionBancoAntecedenteCredito => ({
  id_carga_operacion_banco_antecedente_credito: 0,
  id_carga_operacion_banco,
  id_expediente,
  tipo_prestamo: null,
  factor_conversion_uf: null,
  destino_credito: null,
  monto_solicitado: null,
  tipo_tasa: DEFAULT_TIPO_TASA,
  tasa: null,
  plazo: null,
  fecha_inicio: null,
  monto_nominal: null,
  monto_residual: null,
  plazo_primer_periodo: null,
  periodo_gracia: null,
  comision: null,
  plazo_segundo_periodo: null,
  tasa_primer_periodo: null,
  meses_sabaticos: null,
  variabilidad_tasa: '',
  tasa_segundo_periodo: null,
  moneda: DEFAULT_MONEDA,
  tipo_tasa_mixta_prod_com: '',
  tasa_maxima: null,
  codigo_producto_cartera: '',
  indicador_segunda_vivienda: '',
  tipo_financiamiento: null,
  precio_venta_pesos: null,
  // Decimal: sin default 'UF' (el campo es un monto, no una moneda).
  precio_venta_moneda_original: null,
  cantidad_meses_sin_vencimiento: null,
  indicador_cred_comp: null,
  indicador_pac: '',
  tipo_tasa_aplic_contab: '',
  numero_cuenta_gastos: null,
  prestamo_maximo: null,
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const buildDatosComercialInitialState = (
  id_expediente: number,
  id_carga_operacion_banco = 0,
): CargaOperacionBancoDatosComercial => ({
  id_carga_operacion_banco_datos_comercial: 0,
  id_carga_operacion_banco,
  id_expediente,
  codigo_ejecutivo: null,
  login_ejecutivo: '',
  nombre_ejecutivo: '',
  rut_ejecutivo: null,
  codigo_oficina: null,
  nombre_oficina: '',
  codigo_curse: null,
  glosa_curse: '',
  codigo_ejecutivo_curse: null,
  login_ejecutivo_curse: '',
  nombre_ejecutivo_curse: '',
  rut_ejecutivo_curse: null,
  rut_banco: null,
  renovacion_urbana: '',
  nombre_banco: '',
  tipo_hipoteca: null,
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const buildInitialState = (id_expediente: number): CargaOperacionBanco => ({
  id_carga_operacion_banco: 0,
  id_expediente,
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
  datos_operacion: buildDatosOperacionInitialState(id_expediente),
  antecedentes_comprador: [],
  antecedentes_vendedor: [],
  antecedente_credito: buildAntecedenteCreditoInitialState(id_expediente),
  datos_comercial: buildDatosComercialInitialState(id_expediente),
});

const normalizeDatosOperacion = (
  source: Partial<CargaOperacionBancoDatosOperacion> | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoDatosOperacion => ({
  id_carga_operacion_banco_datos_operacion: Number(
    source?.id_carga_operacion_banco_datos_operacion ?? 0,
  ),
  id_carga_operacion_banco: Number(
    source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
  nro_mutuo:
    source?.nro_mutuo === undefined || source?.nro_mutuo === null
      ? null
      : Number(source.nro_mutuo),
  tipo_operacion: source?.tipo_operacion ?? null,
  nro_registro:
    source?.nro_registro === undefined || source?.nro_registro === null
      ? null
      : Number(source.nro_registro),
  ult_clasif_al: source?.ult_clasif_al ?? '',
  segmento: source?.segmento ?? null,
  canal_venta: source?.canal_venta ?? null,
  nro_op_cartera:
    source?.nro_op_cartera === undefined || source?.nro_op_cartera === null
      ? null
      : Number(source.nro_op_cartera),
  modelo_operacion: source?.modelo_operacion ?? null,
  tipo_carpeta: source?.tipo_carpeta ?? null,
  propietario: source?.propietario ?? '',
  inmobiliaria: source?.inmobiliaria ?? null,
  glosa_producto: source?.glosa_producto ?? null,
  codigo_producto_comercial: source?.codigo_producto_comercial ?? null,
  nro_piloto:
    source?.nro_piloto === undefined || source?.nro_piloto === null
      ? null
      : Number(source.nro_piloto),
  banco_alzante: source?.banco_alzante ?? null,
  nombre_proyecto: source?.nombre_proyecto ?? '',
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? now(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const normalizeAntecedenteComprador = (
  source: Partial<CargaOperacionBancoAntecedenteComprador> | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoAntecedenteComprador => ({
  ...buildCompradorInitialState(
    Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    Number(source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0),
  ),
  id_carga_operacion_banco_antecedente_comprador: Number(
    source?.id_carga_operacion_banco_antecedente_comprador ?? 0,
  ),
  id_carga_operacion_banco: Number(
    source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
  rut: formatRutSinPuntos(String(source?.rut ?? '')),
  tipo_comprador: source?.tipo_comprador ?? null,
  razon_social: source?.razon_social ?? '',
  nombres: source?.nombres ?? '',
  apellido_paterno: source?.apellido_paterno ?? '',
  apellido_materno: source?.apellido_materno ?? '',
  fecha_nacimiento: source?.fecha_nacimiento ?? null,
  genero: source?.genero ?? null,
  estado_civil: source?.estado_civil ?? null,
  relacion_titular: source?.relacion_titular ?? null,
  direccion: source?.direccion ?? '',
  region: source?.region ?? null,
  comuna: source?.comuna ?? null,
  telefono: source?.telefono ?? '',
  email: source?.email ?? '',
  nacionalidad: source?.nacionalidad ?? null,
  profesion: source?.profesion ?? '',
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? now(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const normalizeAntecedenteVendedor = (
  source: Partial<CargaOperacionBancoAntecedenteVendedor> | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoAntecedenteVendedor => ({
  ...buildVendedorInitialState(
    Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    Number(source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0),
  ),
  id_carga_operacion_banco_antecedente_vendedor: Number(
    source?.id_carga_operacion_banco_antecedente_vendedor ?? 0,
  ),
  id_carga_operacion_banco: Number(
    source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
  rut: formatRutSinPuntos(String(source?.rut ?? '')),
  tipo_vendedor: source?.tipo_vendedor ?? null,
  razon_social: source?.razon_social ?? '',
  nombres: source?.nombres ?? '',
  apellido_paterno: source?.apellido_paterno ?? '',
  apellido_materno: source?.apellido_materno ?? '',
  fecha_nacimiento: source?.fecha_nacimiento ?? null,
  genero: source?.genero ?? null,
  estado_civil: source?.estado_civil ?? null,
  relacion_titular: source?.relacion_titular ?? null,
  direccion: source?.direccion ?? '',
  region: source?.region ?? null,
  comuna: source?.comuna ?? null,
  telefono: source?.telefono ?? '',
  email: source?.email ?? '',
  nacionalidad: source?.nacionalidad ?? null,
  profesion: source?.profesion ?? '',
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? now(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const normalizeAntecedentesComprador = (
  source: Partial<CargaOperacionBancoAntecedenteComprador>[] | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoAntecedenteComprador[] =>
  (source ?? []).map((comprador) =>
    normalizeAntecedenteComprador(
      comprador,
      id_expediente_fallback,
      id_carga_operacion_banco_fallback,
    ),
  );

const normalizeAntecedentesVendedor = (
  source: Partial<CargaOperacionBancoAntecedenteVendedor>[] | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoAntecedenteVendedor[] =>
  (source ?? []).map((vendedor) =>
    normalizeAntecedenteVendedor(
      vendedor,
      id_expediente_fallback,
      id_carga_operacion_banco_fallback,
    ),
  );

const CODIGOS_TIPO_JURIDICO = ['JURIDICO', 'JURÍDICO', '02'];

const esTipoJuridico = (tipo: string | null | undefined): boolean => {
  const value = tipo?.toString().toUpperCase();

  return !!value && CODIGOS_TIPO_JURIDICO.includes(value);
};

/**
 * Excluye del payload los campos que no aplican al tipo de persona.
 * Los valores se conservan en el state del formulario (para restaurarlos si
 * el usuario vuelve al tipo anterior), pero no se envían al backend.
 * - Jurídico: solo corresponde razón social.
 * - Natural: corresponden nombres, apellidos, fecha nacimiento, género,
 *   estado civil, nacionalidad y profesión.
 */
const stripCamposNoAplicablesComprador = (
  comprador: CargaOperacionBancoAntecedenteComprador,
): CargaOperacionBancoAntecedenteComprador => {
  if (!comprador.tipo_comprador) return comprador;

  if (esTipoJuridico(comprador.tipo_comprador)) {
    return {
      ...comprador,
      nombres: '',
      apellido_paterno: '',
      apellido_materno: '',
      fecha_nacimiento: null,
      genero: null,
      estado_civil: null,
      nacionalidad: null,
      profesion: '',
    };
  }

  return {
    ...comprador,
    razon_social: '',
  };
};

/** Ver `stripCamposNoAplicablesComprador` (misma regla para vendedor). */
const stripCamposNoAplicablesVendedor = (
  vendedor: CargaOperacionBancoAntecedenteVendedor,
): CargaOperacionBancoAntecedenteVendedor => {
  if (!vendedor.tipo_vendedor) return vendedor;

  if (esTipoJuridico(vendedor.tipo_vendedor)) {
    return {
      ...vendedor,
      nombres: '',
      apellido_paterno: '',
      apellido_materno: '',
      fecha_nacimiento: null,
      genero: null,
      estado_civil: null,
      nacionalidad: null,
      profesion: '',
    };
  }

  return {
    ...vendedor,
    razon_social: '',
  };
};

const normalizeAntecedenteCredito = (
  source: Partial<CargaOperacionBancoAntecedenteCredito> | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoAntecedenteCredito => ({
  ...buildAntecedenteCreditoInitialState(
    Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    Number(source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0),
  ),
  id_carga_operacion_banco_antecedente_credito: Number(
    source?.id_carga_operacion_banco_antecedente_credito ?? 0,
  ),
  id_carga_operacion_banco: Number(
    source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
  tipo_prestamo: source?.tipo_prestamo ?? null,
  factor_conversion_uf:
    source?.factor_conversion_uf === undefined || source?.factor_conversion_uf === null
      ? null
      : Number(source.factor_conversion_uf),
  destino_credito: source?.destino_credito ?? null,
  monto_solicitado:
    source?.monto_solicitado === undefined || source?.monto_solicitado === null
      ? null
      : Number(source.monto_solicitado),
  tipo_tasa: source?.tipo_tasa ?? null,
  tasa: source?.tasa === undefined || source?.tasa === null ? null : Number(source.tasa),
  plazo: source?.plazo === undefined || source?.plazo === null ? null : Number(source.plazo),
  fecha_inicio: source?.fecha_inicio ?? null,
  monto_nominal:
    source?.monto_nominal === undefined || source?.monto_nominal === null
      ? null
      : Number(source.monto_nominal),
  monto_residual:
    source?.monto_residual === undefined || source?.monto_residual === null
      ? null
      : Number(source.monto_residual),
  plazo_primer_periodo:
    source?.plazo_primer_periodo === undefined || source?.plazo_primer_periodo === null
      ? null
      : Number(source.plazo_primer_periodo),
  periodo_gracia:
    source?.periodo_gracia === undefined || source?.periodo_gracia === null
      ? null
      : Number(source.periodo_gracia),
  comision:
    source?.comision === undefined || source?.comision === null
      ? null
      : Number(source.comision),
  plazo_segundo_periodo:
    source?.plazo_segundo_periodo === undefined || source?.plazo_segundo_periodo === null
      ? null
      : Number(source.plazo_segundo_periodo),
  tasa_primer_periodo:
    source?.tasa_primer_periodo === undefined || source?.tasa_primer_periodo === null
      ? null
      : Number(source.tasa_primer_periodo),
  meses_sabaticos:
    source?.meses_sabaticos === undefined || source?.meses_sabaticos === null
      ? null
      : Number(source.meses_sabaticos),
  variabilidad_tasa: source?.variabilidad_tasa ?? '',
  tasa_segundo_periodo:
    source?.tasa_segundo_periodo === undefined || source?.tasa_segundo_periodo === null
      ? null
      : Number(source.tasa_segundo_periodo),
  moneda: source?.moneda ?? null,
  tipo_tasa_mixta_prod_com: source?.tipo_tasa_mixta_prod_com ?? '',
  tasa_maxima:
    source?.tasa_maxima === undefined || source?.tasa_maxima === null
      ? null
      : Number(source.tasa_maxima),
  codigo_producto_cartera: source?.codigo_producto_cartera ?? '',
  indicador_segunda_vivienda: source?.indicador_segunda_vivienda ?? '',
  tipo_financiamiento: source?.tipo_financiamiento ?? null,
  precio_venta_pesos:
    source?.precio_venta_pesos === undefined || source?.precio_venta_pesos === null
      ? null
      : Number(source.precio_venta_pesos),
  precio_venta_moneda_original: toNumeroOpcional(source?.precio_venta_moneda_original),
  cantidad_meses_sin_vencimiento:
    source?.cantidad_meses_sin_vencimiento === undefined ||
    source?.cantidad_meses_sin_vencimiento === null
      ? null
      : Number(source.cantidad_meses_sin_vencimiento),
  indicador_cred_comp:
    source?.indicador_cred_comp === undefined || source?.indicador_cred_comp === null
      ? null
      : Number(source.indicador_cred_comp),
  indicador_pac: source?.indicador_pac ?? '',
  tipo_tasa_aplic_contab: source?.tipo_tasa_aplic_contab ?? '',
  numero_cuenta_gastos:
    source?.numero_cuenta_gastos === undefined || source?.numero_cuenta_gastos === null
      ? null
      : Number(source.numero_cuenta_gastos),
  prestamo_maximo:
    source?.prestamo_maximo === undefined || source?.prestamo_maximo === null
      ? null
      : Number(source.prestamo_maximo),
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? now(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const normalizeDatosComercial = (
  source: Partial<CargaOperacionBancoDatosComercial> | null | undefined,
  id_expediente_fallback: number,
  id_carga_operacion_banco_fallback = 0,
): CargaOperacionBancoDatosComercial => ({
  ...buildDatosComercialInitialState(
    Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    Number(source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0),
  ),
  id_carga_operacion_banco_datos_comercial: Number(
    source?.id_carga_operacion_banco_datos_comercial ?? 0,
  ),
  id_carga_operacion_banco: Number(
    source?.id_carga_operacion_banco ?? id_carga_operacion_banco_fallback ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
  codigo_ejecutivo:
    source?.codigo_ejecutivo === undefined || source?.codigo_ejecutivo === null
      ? null
      : Number(source.codigo_ejecutivo),
  login_ejecutivo: source?.login_ejecutivo ?? '',
  nombre_ejecutivo: source?.nombre_ejecutivo ?? '',
  rut_ejecutivo: formatRutSinPuntos(String(source?.rut_ejecutivo ?? '')) || null,
  codigo_oficina:
    source?.codigo_oficina === undefined || source?.codigo_oficina === null
      ? null
      : Number(source.codigo_oficina),
  nombre_oficina: source?.nombre_oficina ?? '',
  codigo_curse:
    source?.codigo_curse === undefined || source?.codigo_curse === null
      ? null
      : Number(source.codigo_curse),
  glosa_curse: source?.glosa_curse ?? '',
  codigo_ejecutivo_curse:
    source?.codigo_ejecutivo_curse === undefined || source?.codigo_ejecutivo_curse === null
      ? null
      : Number(source.codigo_ejecutivo_curse),
  login_ejecutivo_curse: source?.login_ejecutivo_curse ?? '',
  nombre_ejecutivo_curse: source?.nombre_ejecutivo_curse ?? '',
  rut_ejecutivo_curse: formatRutSinPuntos(String(source?.rut_ejecutivo_curse ?? '')) || null,
  rut_banco: formatRutSinPuntos(String(source?.rut_banco ?? '')) || null,
  renovacion_urbana: source?.renovacion_urbana ?? '',
  nombre_banco: source?.nombre_banco ?? '',
  tipo_hipoteca: source?.tipo_hipoteca ?? null,
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? now(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const normalizeCargaOperacionBanco = (
  source: Partial<CargaOperacionBanco> | null | undefined,
  id_expediente_fallback: number,
): CargaOperacionBanco => {
  const idCargaOperacionBanco = Number(source?.id_carga_operacion_banco ?? 0);
  const idExpediente = Number(source?.id_expediente ?? id_expediente_fallback ?? 0);

  return {
    id_carga_operacion_banco: idCargaOperacionBanco,
    id_expediente: idExpediente,
    is_active: source?.is_active ?? true,
    row_status: source?.row_status ?? true,
    created_by: Number(source?.created_by ?? 0),
    created_date: source?.created_date ?? now(),
    modified_by: source?.modified_by ?? null,
    modified_date: source?.modified_date ?? null,
    datos_operacion: normalizeDatosOperacion(
      source?.datos_operacion,
      idExpediente,
      idCargaOperacionBanco,
    ),
    antecedentes_comprador: normalizeAntecedentesComprador(
      source?.antecedentes_comprador,
      idExpediente,
      idCargaOperacionBanco,
    ),
    antecedentes_vendedor: normalizeAntecedentesVendedor(
      source?.antecedentes_vendedor,
      idExpediente,
      idCargaOperacionBanco,
    ),
    antecedente_credito: normalizeAntecedenteCredito(
      source?.antecedente_credito,
      idExpediente,
      idCargaOperacionBanco,
    ),
    datos_comercial: normalizeDatosComercial(
      source?.datos_comercial,
      idExpediente,
      idCargaOperacionBanco,
    ),
  };
};

export default function CargaOperacionBancoPage() {
  const toast = useRef<Toast>(null);

  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: idExpedienteParam } = useParams();
  const { fromTracking = false } = location.state || {};

  const id_expediente = Number(idExpedienteParam ?? 0);

  const [form, setForm] = useState<CargaOperacionBanco>(
    buildInitialState(id_expediente),
  );
  const [isDisabled, setIsDisabled] = useState(true);
  const [canAdvance, setCanAdvance] = useState(false);
  const [isBusy, setIsBusy] = useState(false);

  // UX-001: fila guardada que quedó con obligatorios pendientes. Al setearla,
  // la sección abre su diálogo en modo edición y enfoca el campo faltante.
  const [compradorInvalidoFocus, setCompradorInvalidoFocus] =
    useState<CargaOperacionBancoAntecedenteComprador | null>(null);
  const [vendedorInvalidoFocus, setVendedorInvalidoFocus] =
    useState<CargaOperacionBancoAntecedenteVendedor | null>(null);

  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef<number>(id_expediente);

  const idemKeyRef = useRef<string | null>(null);

  const { data, isLoading } = useCargaOperacionBanco(id_expediente);
  const saveMutation = useUpsertCargaOperacionBanco();
  const avanzarMutation = useAvanzarCargaOperacionBanco();

  const controlesDatosOperacionQuery = useControlesDatosOperacion();
  const controlesAntecedenteCompradorQuery = useControlesAntecedenteComprador();
  const controlesAntecedenteCreditoQuery = useControlesAntecedenteCredito();
  const controlesAntecedenteVendedorQuery = useControlesAntecedenteVendedor();
  const controlesDatosComercialQuery = useControlesDatosComercial();

  const catalogos: ControlesDatosOperacion = useMemo(() => {
    if (!controlesDatosOperacionQuery.data?.status) {
      return EMPTY_CONTROLES_DATOS_OPERACION;
    }

    return (
      controlesDatosOperacionQuery.data.detail ??
      EMPTY_CONTROLES_DATOS_OPERACION
    );
  }, [controlesDatosOperacionQuery.data]);

  const controlesComprador: ControlesAntecedenteComprador = useMemo(() => {
    if (!controlesAntecedenteCompradorQuery.data?.status) {
      return EMPTY_CONTROLES_ANTECEDENTE_COMPRADOR;
    }

    return (
      controlesAntecedenteCompradorQuery.data.detail ??
      EMPTY_CONTROLES_ANTECEDENTE_COMPRADOR
    );
  }, [controlesAntecedenteCompradorQuery.data]);

  const controlesVendedor: ControlesAntecedenteVendedor = useMemo(() => {
    if (!controlesAntecedenteVendedorQuery.data?.status) {
      return EMPTY_CONTROLES_ANTECEDENTE_VENDEDOR;
    }

    return (
      controlesAntecedenteVendedorQuery.data.detail ??
      EMPTY_CONTROLES_ANTECEDENTE_VENDEDOR
    );
  }, [controlesAntecedenteVendedorQuery.data]);

  const controlesCredito: ControlesAntecedenteCredito = useMemo(() => {
    if (!controlesAntecedenteCreditoQuery.data?.status) {
      return EMPTY_CONTROLES_ANTECEDENTE_CREDITO;
    }

    return (
      controlesAntecedenteCreditoQuery.data.detail ??
      EMPTY_CONTROLES_ANTECEDENTE_CREDITO
    );
  }, [controlesAntecedenteCreditoQuery.data]);

  const controlesComercial: ControlesDatosComercial = useMemo(() => {
    if (!controlesDatosComercialQuery.data?.status) {
      return EMPTY_CONTROLES_DATOS_COMERCIAL;
    }

    return (
      controlesDatosComercialQuery.data.detail ??
      EMPTY_CONTROLES_DATOS_COMERCIAL
    );
  }, [controlesDatosComercialQuery.data]);

  const isLoadingCatalogos = controlesDatosOperacionQuery.isLoading;
  const isLoadingControlesComprador =
    controlesAntecedenteCompradorQuery.isLoading;
  const isLoadingControlesVendedor =
    controlesAntecedenteVendedorQuery.isLoading;
  const isLoadingControlesCredito =
    controlesAntecedenteCreditoQuery.isLoading;
  const isLoadingControlesComercial =
    controlesDatosComercialQuery.isLoading;

  // Doc: el Propietario se autocompleta con el usuario que toma la operación.
  const { user } = useAuth();

  const propietarioPorDefecto = useMemo(
    () => user?.name_complete?.trim() || user?.user_name?.trim() || '',
    [user],
  );

  /** Completa el Propietario solo si viene vacío (nunca pisa un valor guardado). */
  const aplicarPropietarioPorDefecto = (
    state: CargaOperacionBanco,
  ): CargaOperacionBanco => {
    const actual = state.datos_operacion?.propietario?.trim();

    if (!propietarioPorDefecto || actual) return state;

    return {
      ...state,
      datos_operacion: {
        ...(state.datos_operacion ??
          buildDatosOperacionInitialState(state.id_expediente)),
        propietario: propietarioPorDefecto,
      },
    };
  };

  // Doc: N° Piloto se vuelve obligatorio si la operación es "Asociada".
  // "Asociada" existe en el catálogo de TIPO_CARPETA ('01' Asociada / '02'
  // Particular); se evalúa también TIPO_OPERACION por si el catálogo llegara a
  // incluir el valor. Se reutiliza la misma fuente/lógica que llena los selects.
  const esOperacionAsociada =
    coincideOpcion(catalogos.tipo_carpeta, form.datos_operacion?.tipo_carpeta, 'asoc') ||
    coincideOpcion(
      catalogos.tipo_operacion,
      form.datos_operacion?.tipo_operacion,
      'asoc',
    );

  const nroPilotoObligatorio = esOperacionAsociada;

  useEffect(() => {
    if (currentExpedienteRef.current !== id_expediente) {
      currentExpedienteRef.current = id_expediente;
      hasHydratedRef.current = false;
      setForm(aplicarPropietarioPorDefecto(buildInitialState(id_expediente)));
      setIsDisabled(true);
      setCanAdvance(false);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (!id_expediente || id_expediente <= 0) {
      setForm(aplicarPropietarioPorDefecto(buildInitialState(0)));
      setIsDisabled(false);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (data?.status && data.detail) {
      setForm(
        aplicarPropietarioPorDefecto(
          normalizeCargaOperacionBanco(data.detail, id_expediente),
        ),
      );
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (data) {
      setForm(aplicarPropietarioPorDefecto(buildInitialState(id_expediente)));
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
    }
  }, [data, id_expediente]);

  const updateDatosOperacionField = <
    K extends keyof CargaOperacionBancoDatosOperacion,
  >(
    field: K,
    value: CargaOperacionBancoDatosOperacion[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      datos_operacion: {
        ...(prev.datos_operacion ?? buildDatosOperacionInitialState(prev.id_expediente)),
        [field]: value,
      },
    }));
  };

  const updateAntecedenteCreditoField = <
    K extends keyof CargaOperacionBancoAntecedenteCredito,
  >(
    field: K,
    value: CargaOperacionBancoAntecedenteCredito[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      antecedente_credito: {
        ...(prev.antecedente_credito ??
          buildAntecedenteCreditoInitialState(
            prev.id_expediente,
            prev.id_carga_operacion_banco,
          )),
        [field]: value,
      },
    }));
  };

  const updateDatosComercialField = <
    K extends keyof CargaOperacionBancoDatosComercial,
  >(
    field: K,
    value: CargaOperacionBancoDatosComercial[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      datos_comercial: {
        ...(prev.datos_comercial ??
          buildDatosComercialInitialState(
            prev.id_expediente,
            prev.id_carga_operacion_banco,
          )),
        [field]: value,
      },
    }));
  };

  const updateAntecedentesComprador = (
    antecedentes_comprador: CargaOperacionBancoAntecedenteComprador[],
  ) => {
    setForm((prev) => ({
      ...prev,
      antecedentes_comprador: normalizeAntecedentesComprador(
        antecedentes_comprador,
        prev.id_expediente,
        prev.id_carga_operacion_banco,
      ),
    }));
  };

  const updateAntecedentesVendedor = (
    antecedentes_vendedor: CargaOperacionBancoAntecedenteVendedor[],
  ) => {
    setForm((prev) => ({
      ...prev,
      antecedentes_vendedor: normalizeAntecedentesVendedor(
        antecedentes_vendedor,
        prev.id_expediente,
        prev.id_carga_operacion_banco,
      ),
    }));
  };

  const handleEditar = () => {
    setIsDisabled(false);
    setCanAdvance(false);
  };

  const validateForm = (): {
    message: string;
    fieldKey?: string;
    filaInvalida?: FilaInvalida;
  } | null => {
    if (id_expediente > 0 && (!form.id_expediente || form.id_expediente <= 0)) {
      return { message: 'No existe un id_expediente válido.' };
    }

    const datosOperacion =
      form.datos_operacion ?? buildDatosOperacionInitialState(form.id_expediente);

    if (!datosOperacion.nro_mutuo) {
      return { message: 'Debe ingresar N° Mutuo.', fieldKey: 'nro_mutuo' };
    }
    if (!datosOperacion.tipo_operacion) {
      return { message: 'Debe seleccionar Tipo Operación.', fieldKey: 'tipo_operacion' };
    }
    if (!datosOperacion.nro_registro) {
      return { message: 'Debe ingresar N° Registro.', fieldKey: 'nro_registro' };
    }
    if (!datosOperacion.ult_clasif_al?.trim()) {
      return { message: 'Debe ingresar Ult. Clasif. al.', fieldKey: 'ult_clasif_al' };
    }
    if (!datosOperacion.segmento) {
      return { message: 'Debe seleccionar Segmento.', fieldKey: 'segmento' };
    }
    if (!datosOperacion.canal_venta) {
      return { message: 'Debe seleccionar Canal de Venta.', fieldKey: 'canal_venta' };
    }
    if (!datosOperacion.nro_op_cartera) {
      return { message: 'Debe ingresar N° Op. Cartera.', fieldKey: 'nro_op_cartera' };
    }
    if (!datosOperacion.modelo_operacion) {
      return {
        message: 'Debe seleccionar Modelo de Operación.',
        fieldKey: 'modelo_operacion',
      };
    }
    if (!datosOperacion.tipo_carpeta) {
      return { message: 'Debe seleccionar Tipo Carpeta.', fieldKey: 'tipo_carpeta' };
    }
    if (!datosOperacion.propietario?.trim()) {
      return { message: 'Debe ingresar Propietario.', fieldKey: 'propietario' };
    }
    if (!datosOperacion.inmobiliaria) {
      return { message: 'Debe seleccionar Inmobiliaria.', fieldKey: 'inmobiliaria' };
    }
    if (!datosOperacion.glosa_producto) {
      return { message: 'Debe seleccionar Glosa Producto.', fieldKey: 'glosa_producto' };
    }
    if (!datosOperacion.codigo_producto_comercial) {
      return {
        message: 'Debe seleccionar Código Producto Comercial.',
        fieldKey: 'codigo_producto_comercial',
      };
    }
    // Doc: N° Piloto es obligatorio solo si la operación es "Asociada".
    if (nroPilotoObligatorio && !datosOperacion.nro_piloto) {
      return {
        message: 'Debe ingresar N° Piloto (la operación es Asociada).',
        fieldKey: 'nro_piloto',
      };
    }
    // Nombre de Proyecto es obligatorio siempre (sin condición).
    if (!datosOperacion.nombre_proyecto?.trim()) {
      return { message: 'Debe ingresar Nombre Proyecto.', fieldKey: 'nombre_proyecto' };
    }

    // RN-C-04 / RN-V-06: si hay Inmobiliaria, Dirección/Región/Comuna son obligatorias
    const requiereDireccion = Boolean(datosOperacion.inmobiliaria);

    const compradoresActivos =
      form.antecedentes_comprador?.filter((comprador) => comprador.row_status !== false) ??
      [];

    if (compradoresActivos.length === 0) {
      return {
        message: 'Debe agregar al menos un comprador.',
        fieldKey: 'antecedentes-comprador',
      };
    }

    const compradorInvalido = compradoresActivos.find((comprador) => {
      // RUT: formato sin puntos (12345678-9) + dígito verificador (módulo 11)
      if (!isValidRutSinPuntos(comprador.rut)) return true;
      if (!comprador.tipo_comprador) return true;

      const tipo = comprador.tipo_comprador.toString().toUpperCase();

      if (tipo === 'JURIDICO' || tipo === 'JURÍDICO' || tipo === '02') {
        if (!comprador.razon_social?.trim()) return true;
        // UX-009: caracteres permitidos según tipo de dato.
        if (describeRazonSocialError(comprador.razon_social)) return true;
      } else {
        if (!comprador.nombres?.trim()) return true;
        if (describeNombrePersonaError(comprador.nombres)) return true;
        if (!comprador.apellido_paterno?.trim()) return true;
        if (describeNombrePersonaError(comprador.apellido_paterno)) return true;
        if (!comprador.apellido_materno?.trim()) return true;
        if (describeNombrePersonaError(comprador.apellido_materno)) return true;
      }

      // UX-004: fecha de nacimiento coherente (no futura, mayor de edad).
      if (describeFechaNacimientoError(comprador.fecha_nacimiento)) return true;

      if (requiereDireccion) {
        if (!comprador.direccion?.trim() || !comprador.region || !comprador.comuna) {
          return true;
        }
      }

      if (describeDireccionError(comprador.direccion)) return true;

      // UX-007: email opcional, validado si se ingresa.
      if (describeEmailError(comprador.email)) return true;

      return false;
    });

    if (compradorInvalido) {
      const motivoRut = describeRutError(compradorInvalido.rut);
      const motivoFecha = describeFechaNacimientoError(
        compradorInvalido.fecha_nacimiento,
      );
      const motivoEmail = describeEmailError(compradorInvalido.email);
      const motivoTexto =
        describeRazonSocialError(compradorInvalido.razon_social, 'Razón Social. ') ??
        describeNombrePersonaError(compradorInvalido.nombres, 'Nombres. ') ??
        describeNombrePersonaError(
          compradorInvalido.apellido_paterno,
          'Apellido Paterno. ',
        ) ??
        describeNombrePersonaError(
          compradorInvalido.apellido_materno,
          'Apellido Materno. ',
        ) ??
        describeDireccionError(compradorInvalido.direccion, 'Dirección. ');
      const etiqueta = `Comprador ${compradorInvalido.rut || '(sin RUT)'}.`;

      const motivos = [
        motivoRut,
        motivoFecha ? `Fecha de nacimiento. ${motivoFecha}` : null,
        motivoEmail ? `Email. ${motivoEmail}` : null,
        motivoTexto,
      ].filter(Boolean);

      return {
        message: motivos.length
          ? `${etiqueta} ${motivos.join(' ')}`
          : 'Hay compradores con información obligatoria pendiente.',
        // Resalta la sección y abre el diálogo de la fila inválida.
        fieldKey: 'antecedentes-comprador',
        filaInvalida: { tipo: 'comprador', row: compradorInvalido },
      };
    }

    const vendedoresActivos =
      form.antecedentes_vendedor?.filter((vendedor) => vendedor.row_status !== false) ?? [];

    // RN-V-01: los datos del vendedor NO son obligatorios si no se completó
    // N° Piloto. RN-V-02: si N° Piloto tiene valor, es obligatorio al menos uno.
    const nroPilotoInformado =
      datosOperacion.nro_piloto !== null && datosOperacion.nro_piloto !== undefined;

    if (nroPilotoInformado && vendedoresActivos.length === 0) {
      return {
        message: 'Debe agregar al menos un vendedor, porque se informó N° Piloto.',
        fieldKey: 'antecedentes-vendedor',
      };
    }

    const vendedorInvalido = vendedoresActivos.find((vendedor) => {
      // RUT: formato sin puntos (12345678-9) + dígito verificador (módulo 11)
      if (!isValidRutSinPuntos(vendedor.rut)) return true;
      if (!vendedor.tipo_vendedor) return true;

      const tipo = vendedor.tipo_vendedor?.toString().toUpperCase();

      if (tipo === 'JURIDICO' || tipo === 'JURÍDICO' || tipo === '02') {
        if (!vendedor.razon_social?.trim()) return true;
        // UX-009: caracteres permitidos según tipo de dato.
        if (describeRazonSocialError(vendedor.razon_social)) return true;
      } else {
        if (!vendedor.nombres?.trim()) return true;
        if (describeNombrePersonaError(vendedor.nombres)) return true;
        if (!vendedor.apellido_paterno?.trim()) return true;
        if (describeNombrePersonaError(vendedor.apellido_paterno)) return true;
      }

      // UX-004: fecha de nacimiento coherente (no futura, mayor de edad).
      if (describeFechaNacimientoError(vendedor.fecha_nacimiento)) return true;

      if (requiereDireccion) {
        if (!vendedor.direccion?.trim() || !vendedor.region || !vendedor.comuna) {
          return true;
        }
      }

      if (describeDireccionError(vendedor.direccion)) return true;

      // UX-007: email opcional, validado si se ingresa.
      if (describeEmailError(vendedor.email)) return true;

      return false;
    });

    if (vendedorInvalido) {
      const motivoRut = describeRutError(vendedorInvalido.rut);
      const motivoFecha = describeFechaNacimientoError(
        vendedorInvalido.fecha_nacimiento,
      );
      const motivoEmail = describeEmailError(vendedorInvalido.email);
      const motivoTexto =
        describeRazonSocialError(vendedorInvalido.razon_social, 'Razón Social. ') ??
        describeNombrePersonaError(vendedorInvalido.nombres, 'Nombres. ') ??
        describeNombrePersonaError(
          vendedorInvalido.apellido_paterno,
          'Apellido Paterno. ',
        ) ??
        describeDireccionError(vendedorInvalido.direccion, 'Dirección. ');
      const etiqueta = `Vendedor ${vendedorInvalido.rut || '(sin RUT)'}.`;

      const motivos = [
        motivoRut,
        motivoFecha ? `Fecha de nacimiento. ${motivoFecha}` : null,
        motivoEmail ? `Email. ${motivoEmail}` : null,
        motivoTexto,
      ].filter(Boolean);

      return {
        message: motivos.length
          ? `${etiqueta} ${motivos.join(' ')}`
          : 'Hay vendedores con información obligatoria pendiente.',
        // Resalta la sección y abre el diálogo de la fila inválida.
        fieldKey: 'antecedentes-vendedor',
        filaInvalida: { tipo: 'vendedor', row: vendedorInvalido },
      };
    }

    const antecedenteCredito =
      form.antecedente_credito ??
      buildAntecedenteCreditoInitialState(
        form.id_expediente,
        form.id_carga_operacion_banco,
      );

    // Campos obligatorios (Sí) según documento funcional - sección Antecedentes del Crédito.
    // Se validan en el ORDEN VISUAL del formulario (51 → 80) para que el mensaje y el
    // autoscroll avancen de arriba hacia abajo. Los numéricos usan esNumeroVacio: el 0 es
    // un valor válido (Comisión, Periodo de Gracia, Monto Residual, indicadores, etc.).
    if (!antecedenteCredito.tipo_prestamo) {
      return { message: 'Debe seleccionar Tipo Préstamo.', fieldKey: 'tipo_prestamo' };
    }
    if (esNumeroVacio(antecedenteCredito.factor_conversion_uf)) {
      return { message: 'Debe ingresar Factor Conversión UF.', fieldKey: 'factor_conversion_uf' };
    }
    if (!antecedenteCredito.destino_credito) {
      return { message: 'Debe seleccionar Destino Crédito.', fieldKey: 'destino_credito' };
    }
    if (esNumeroVacio(antecedenteCredito.monto_solicitado)) {
      return { message: 'Debe ingresar Monto Solicitado.', fieldKey: 'monto_solicitado' };
    }
    if (!antecedenteCredito.tipo_tasa) {
      return { message: 'Debe seleccionar Tipo Tasa.', fieldKey: 'tipo_tasa' };
    }
    if (esNumeroVacio(antecedenteCredito.tasa)) {
      return { message: 'Debe ingresar Tasa.', fieldKey: 'tasa' };
    }
    if (esNumeroVacio(antecedenteCredito.plazo)) {
      return { message: 'Debe ingresar Plazo.', fieldKey: 'plazo' };
    }
    if (!antecedenteCredito.fecha_inicio) {
      return { message: 'Debe ingresar Fecha Inicio.', fieldKey: 'fecha_inicio' };
    }
    if (esNumeroVacio(antecedenteCredito.monto_nominal)) {
      return { message: 'Debe ingresar Monto Nominal.', fieldKey: 'monto_nominal' };
    }
    if (esNumeroVacio(antecedenteCredito.monto_residual)) {
      return { message: 'Debe ingresar Monto Residual.', fieldKey: 'monto_residual' };
    }
    if (esNumeroVacio(antecedenteCredito.plazo_primer_periodo)) {
      return {
        message: 'Debe ingresar Plazo Primer Periodo.',
        fieldKey: 'plazo_primer_periodo',
      };
    }
    if (esNumeroVacio(antecedenteCredito.periodo_gracia)) {
      return { message: 'Debe ingresar Periodo Gracia.', fieldKey: 'periodo_gracia' };
    }
    if (esNumeroVacio(antecedenteCredito.comision)) {
      return { message: 'Debe ingresar Comisión.', fieldKey: 'comision' };
    }
    if (esNumeroVacio(antecedenteCredito.plazo_segundo_periodo)) {
      return {
        message: 'Debe ingresar Plazo Segundo Periodo.',
        fieldKey: 'plazo_segundo_periodo',
      };
    }
    if (esNumeroVacio(antecedenteCredito.tasa_primer_periodo)) {
      return {
        message: 'Debe ingresar Tasa Primer Periodo.',
        fieldKey: 'tasa_primer_periodo',
      };
    }
    if (esNumeroVacio(antecedenteCredito.meses_sabaticos)) {
      return { message: 'Debe ingresar Meses Sabáticos.', fieldKey: 'meses_sabaticos' };
    }
    if (!antecedenteCredito.variabilidad_tasa?.trim()) {
      return { message: 'Debe ingresar Variabilidad Tasa.', fieldKey: 'variabilidad_tasa' };
    }
    if (esNumeroVacio(antecedenteCredito.tasa_segundo_periodo)) {
      return {
        message: 'Debe ingresar Tasa Segundo Periodo.',
        fieldKey: 'tasa_segundo_periodo',
      };
    }
    if (!antecedenteCredito.moneda) {
      return { message: 'Debe seleccionar Moneda.', fieldKey: 'moneda' };
    }
    if (!antecedenteCredito.tipo_tasa_mixta_prod_com?.trim()) {
      return {
        message: 'Debe ingresar Tipo Tasa Mixta Prod. Com.',
        fieldKey: 'tipo_tasa_mixta_prod_com',
      };
    }
    if (esNumeroVacio(antecedenteCredito.tasa_maxima)) {
      return { message: 'Debe ingresar Tasa Máxima.', fieldKey: 'tasa_maxima' };
    }
    if (!antecedenteCredito.codigo_producto_cartera?.trim()) {
      return {
        message: 'Debe ingresar Código Producto Cartera.',
        fieldKey: 'codigo_producto_cartera',
      };
    }
    if (!antecedenteCredito.indicador_segunda_vivienda?.trim()) {
      return {
        message: 'Debe ingresar Indicador Segunda Vivienda.',
        fieldKey: 'indicador_segunda_vivienda',
      };
    }
    if (!antecedenteCredito.tipo_financiamiento) {
      return {
        message: 'Debe seleccionar Tipo Financiamiento.',
        fieldKey: 'tipo_financiamiento',
      };
    }
    if (esNumeroVacio(antecedenteCredito.precio_venta_pesos)) {
      return { message: 'Debe ingresar Precio Venta Pesos.', fieldKey: 'precio_venta_pesos' };
    }
    if (esNumeroVacio(antecedenteCredito.precio_venta_moneda_original)) {
      return {
        message: 'Debe ingresar Precio Venta Moneda Original.',
        fieldKey: 'precio_venta_moneda_original',
      };
    }
    if (esNumeroVacio(antecedenteCredito.cantidad_meses_sin_vencimiento)) {
      return {
        message: 'Debe ingresar Cantidad Meses Sin Vencimiento.',
        fieldKey: 'cantidad_meses_sin_vencimiento',
      };
    }
    if (esNumeroVacio(antecedenteCredito.indicador_cred_comp)) {
      return {
        message: 'Debe ingresar Indicador Cred. Comp.',
        fieldKey: 'indicador_cred_comp',
      };
    }
    if (!antecedenteCredito.indicador_pac?.trim()) {
      return { message: 'Debe ingresar Indicador PAC.', fieldKey: 'indicador_pac' };
    }
    if (!antecedenteCredito.tipo_tasa_aplic_contab?.trim()) {
      return {
        message: 'Debe ingresar Tipo Tasa Aplic. Contab.',
        fieldKey: 'tipo_tasa_aplic_contab',
      };
    }

    const datosComercial =
      form.datos_comercial ??
      buildDatosComercialInitialState(
        form.id_expediente,
        form.id_carga_operacion_banco,
      );

    if (!datosComercial.nombre_banco?.trim()) {
      return { message: 'Debe ingresar Nombre Banco.', fieldKey: 'nombre_banco' };
    }
    if (!datosComercial.tipo_hipoteca) {
      return { message: 'Debe seleccionar Tipo Hipoteca.', fieldKey: 'tipo_hipoteca' };
    }

    // RUT opcionales: si se ingresan, deben cumplir formato sin puntos + módulo 11
    if (datosComercial.rut_ejecutivo?.trim()) {
      const error = describeRutError(datosComercial.rut_ejecutivo);
      if (error) {
        return { message: `RUT Ejecutivo. ${error}`, fieldKey: 'rut_ejecutivo' };
      }
    }
    if (datosComercial.rut_ejecutivo_curse?.trim()) {
      const error = describeRutError(datosComercial.rut_ejecutivo_curse);
      if (error) {
        return {
          message: `RUT Ejecutivo Curse. ${error}`,
          fieldKey: 'rut_ejecutivo_curse',
        };
      }
    }
    if (datosComercial.rut_banco?.trim()) {
      const error = describeRutError(datosComercial.rut_banco);
      if (error) {
        return { message: `RUT Banco. ${error}`, fieldKey: 'rut_banco' };
      }
    }

    return null;
  };

  const buildPayload = () => {
    const expedienteId = Number(form.id_expediente || id_expediente || 0);
    const idCargaOperacionBanco = Number(form.id_carga_operacion_banco ?? 0);

    return normalizeCargaOperacionBanco(
      {
        ...form,
        id_expediente: expedienteId,
        datos_operacion: normalizeDatosOperacion(
          form.datos_operacion,
          expedienteId,
          idCargaOperacionBanco,
        ),
        antecedentes_comprador: normalizeAntecedentesComprador(
          form.antecedentes_comprador,
          expedienteId,
          idCargaOperacionBanco,
        ).map(stripCamposNoAplicablesComprador),
        antecedentes_vendedor: normalizeAntecedentesVendedor(
          form.antecedentes_vendedor,
          expedienteId,
          idCargaOperacionBanco,
        ).map(stripCamposNoAplicablesVendedor),
        antecedente_credito: normalizeAntecedenteCredito(
          form.antecedente_credito,
          expedienteId,
          idCargaOperacionBanco,
        ),
        datos_comercial: normalizeDatosComercial(
          form.datos_comercial,
          expedienteId,
          idCargaOperacionBanco,
        ),
      },
      expedienteId,
    );
  };

  const handleGuardar = async () => {
    // Limpia los resaltados de la validación anterior antes de volver a validar.
    clearFieldErrors();

    const validation = validateForm();

    if (validation) {
      toast.current?.show({
        severity: 'warn',
        summary: 'Validación',
        detail: validation.message,
        life: 3000,
      });
      focusFieldByKey(validation.fieldKey);

      if (validation.filaInvalida?.tipo === 'comprador') {
        setCompradorInvalidoFocus(validation.filaInvalida.row);
      } else if (validation.filaInvalida?.tipo === 'vendedor') {
        setVendedorInvalidoFocus(validation.filaInvalida.row);
      }
      return;
    }

    try {
      setIsBusy(true);

      const payload = buildPayload();
      const guardarKey = crypto.randomUUID();

      const response = await saveMutation.mutateAsync({
        payload,
        idempotencyKey: guardarKey,
      });

      if (response.status) {
        const savedEntity = normalizeCargaOperacionBanco(
          response.detail ?? payload,
          payload.id_expediente,
        );

        setForm(savedEntity);
        setIsDisabled(true);
        setCanAdvance(true);
        hasHydratedRef.current = true;

        toast.current?.show({
          severity: 'success',
          summary: 'Éxito',
          detail: 'Carga Operación Banco guardada correctamente.',
          life: 3000,
        });
      } else {
        toast.current?.show({
          severity: 'warn',
          summary: 'Atención',
          detail: response.message || 'No se pudo guardar.',
          life: 3000,
        });
      }
    } catch (error) {
      toast.current?.show({
        severity: 'error',
        summary: 'Error',
        detail: getErrorMessage(error),
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleAvanzar = async () => {
    if (saveMutation.isPending || avanzarMutation.isPending) {
      return;
    }

    // Limpia los resaltados de la validación anterior antes de volver a validar.
    clearFieldErrors();

    const validation = validateForm();

    if (validation) {
      toast.current?.show({
        severity: 'warn',
        summary: 'Validación',
        detail: validation.message,
        life: 3000,
      });
      focusFieldByKey(validation.fieldKey);

      if (validation.filaInvalida?.tipo === 'comprador') {
        setCompradorInvalidoFocus(validation.filaInvalida.row);
      } else if (validation.filaInvalida?.tipo === 'vendedor') {
        setVendedorInvalidoFocus(validation.filaInvalida.row);
      }
      return;
    }

    if (idemKeyRef.current === null) {
      idemKeyRef.current = crypto.randomUUID();
    }
    const currentIdemKey = idemKeyRef.current;

    try {
      setIsBusy(true);

      const payload = buildPayload();

      const saveResponse = await saveMutation.mutateAsync({
        payload,
        idempotencyKey: currentIdemKey,
      });

      if (!saveResponse.status) {
        toast.current?.show({
          severity: 'warn',
          summary: 'Atención',
          detail: saveResponse.message || 'No se pudo guardar antes de avanzar.',
          life: 3000,
        });
        return;
      }

      const savedEntity = normalizeCargaOperacionBanco(
        saveResponse.detail ?? payload,
        payload.id_expediente,
      );

      setForm(savedEntity);

      const expedienteId = Number(savedEntity.id_expediente ?? 0);

      if (!expedienteId || expedienteId <= 0) {
        toast.current?.show({
          severity: 'warn',
          summary: 'Validación',
          detail: 'No existe un id_expediente válido para avanzar.',
          life: 3000,
        });
        return;
      }

      const response = await avanzarMutation.mutateAsync(expedienteId);

      if (response.status) {
        idemKeyRef.current = null;

        toast.current?.show({
          severity: 'success',
          summary: 'Éxito',
          detail: 'Actividad avanzada correctamente.',
          life: 2000,
        });

        navigate('/home/bandeja');
      } else {
        toast.current?.show({
          severity: 'warn',
          summary: 'Atención',
          detail: response.message || 'No se pudo avanzar la actividad.',
          life: 3000,
        });
      }
    } catch (error) {
      toast.current?.show({
        severity: 'error',
        summary: 'Error',
        detail: getErrorMessage(error),
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleSalir = () => {
    navigate('/home/bandeja');
  };

  const canEditAntecedentesComprador = !isDisabled && !isBusy;
  const canEditAntecedentesVendedor = !isDisabled && !isBusy;

  // RN-V-02: el vendedor solo es obligatorio cuando se informó N° Piloto.
  const nroPilotoVendedor = form.datos_operacion?.nro_piloto;
  const requiereAlMenosUnVendedor =
    nroPilotoVendedor !== null && nroPilotoVendedor !== undefined;

  return (
    <>
      <Toast ref={toast} />

      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Carga Operación Banco
      </h2>

      <Accordion activeIndex={[0, 2]} multiple>
        <AccordionTab
          disabled={!id_expediente || id_expediente <= 0}
          header="Información del Expediente"
        >
          <EncabezadoActividad
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            activityID={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab
          header="Funciones Transversales"
          disabled={!id_expediente || id_expediente <= 0}
        >
          <FuncionesTransversales
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            idActividad={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header="Carga Operación Banco">
          <Card className="w-full shadow-md card-presto-form mb-6">
            <p className="mb-5 text-sm text-gray-600">
              Los campos marcados con <RequiredMark /> son obligatorios.
            </p>

            {isLoading && id_expediente > 0 && (
              <div className="mb-4 text-sm text-blue-600">
                Cargando información...
              </div>
            )}

            <div className="mb-5">
              <h3 className="text-lg font-semibold text-gray-800">
                Sección: Datos de la Operación
              </h3>
            </div>

            <DatosOperacionSection
              value={
                form.datos_operacion ??
                buildDatosOperacionInitialState(form.id_expediente)
              }
              disabled={isDisabled || isBusy}
              catalogos={catalogos}
              loadingCatalogos={isLoadingCatalogos}
              nroPilotoObligatorio={nroPilotoObligatorio}
              onChange={updateDatosOperacionField}
            />

            <div className="my-8 border-t border-gray-200" />

            <AntecedentesCompradorSection
              key={`antecedentes-comprador-${canEditAntecedentesComprador ? 'edit' : 'view'}`}
              value={form.antecedentes_comprador ?? []}
              idExpediente={Number(form.id_expediente || id_expediente || 0)}
              idCargaOperacionBanco={Number(form.id_carga_operacion_banco ?? 0)}
              disabled={isDisabled || isBusy}
              canEdit={canEditAntecedentesComprador}
              controles={controlesComprador}
              loadingControles={isLoadingControlesComprador}
              requiereDireccion={Boolean(form.datos_operacion?.inmobiliaria)}
              onChange={updateAntecedentesComprador}
              rowToFocus={compradorInvalidoFocus}
              onRowToFocusHandled={() => setCompradorInvalidoFocus(null)}
              onWarn={(message) =>
                toast.current?.show({
                  severity: 'warn',
                  summary: 'Validación',
                  detail: message,
                  life: 3000,
                })
              }
            />

            <div className="my-8 border-t border-gray-200" />

            <AntecedentesVendedorSection
              key={`antecedentes-vendedor-${canEditAntecedentesVendedor ? 'edit' : 'view'}`}
              value={form.antecedentes_vendedor ?? []}
              idExpediente={Number(form.id_expediente || id_expediente || 0)}
              idCargaOperacionBanco={Number(form.id_carga_operacion_banco ?? 0)}
              disabled={isDisabled || isBusy}
              canEdit={canEditAntecedentesVendedor}
              controles={controlesVendedor}
              loadingControles={isLoadingControlesVendedor}
              requiereDireccion={Boolean(form.datos_operacion?.inmobiliaria)}
              requiereAlMenosUno={requiereAlMenosUnVendedor}
              onChange={updateAntecedentesVendedor}
              rowToFocus={vendedorInvalidoFocus}
              onRowToFocusHandled={() => setVendedorInvalidoFocus(null)}
              onWarn={(message) =>
                toast.current?.show({
                  severity: 'warn',
                  summary: 'Validación',
                  detail: message,
                  life: 3000,
                })
              }
            />


            <div className="my-8 border-t border-gray-200" />

            <div className="mb-5">
              <h3 className="text-lg font-semibold text-gray-800">
                Sección: Antecedentes del Crédito
              </h3>
            </div>

            <AntecedenteCreditoSection
              value={
                form.antecedente_credito ??
                buildAntecedenteCreditoInitialState(
                  form.id_expediente,
                  form.id_carga_operacion_banco,
                )
              }
              disabled={isDisabled || isBusy}
              controles={controlesCredito}
              loadingControles={isLoadingControlesCredito}
              onChange={updateAntecedenteCreditoField}
            />

            <div className="my-8 border-t border-gray-200" />

            <div className="mb-5">
              <h3 className="text-lg font-semibold text-gray-800">
                Sección: Datos Comercial
              </h3>
            </div>

            <DatosComercialSection
              value={
                form.datos_comercial ??
                buildDatosComercialInitialState(
                  form.id_expediente,
                  form.id_carga_operacion_banco,
                )
              }
              disabled={isDisabled || isBusy}
              controles={controlesComercial}
              loadingControles={isLoadingControlesComercial}
              onChange={updateDatosComercialField}
            />

            <ActivityActionBar
              from_tracking={fromTracking}
              is_busy={isBusy}
              is_disabled={isDisabled}
              can_advance={canAdvance}
              is_saving={saveMutation.isPending}
              is_advancing={avanzarMutation.isPending}
              on_edit={handleEditar}
              on_save={handleGuardar}
              on_advance={handleAvanzar}
              on_exit={handleSalir}
            />
          </Card>
        </AccordionTab>
      </Accordion>
    </>
  );
}