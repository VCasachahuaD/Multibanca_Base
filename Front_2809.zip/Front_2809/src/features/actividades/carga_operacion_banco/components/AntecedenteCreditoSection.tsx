import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import { InputText } from 'primereact/inputtext';

import type { ControlesAntecedenteCredito } from '../models/catalogo';
import type { CargaOperacionBancoAntecedenteCredito } from '../models/carga_operacion_banco';
import { limitOf } from '../models/fieldLimits';
import RequiredMark from '@/shared/components/RequiredMark';

interface AntecedenteCreditoSectionProps {
  value: CargaOperacionBancoAntecedenteCredito;
  disabled: boolean;
  controles: ControlesAntecedenteCredito;
  loadingControles?: boolean;
  onChange: <K extends keyof CargaOperacionBancoAntecedenteCredito>(
    field: K,
    value: CargaOperacionBancoAntecedenteCredito[K],
  ) => void;
}

const emptyMessage = 'Sin resultados';

const toDate = (value?: string | null): Date | null => {
  if (!value) return null;

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const toIsoDate = (value: Date | null | undefined): string | null => {
  if (!value) return null;
  return value.toISOString();
};

export default function AntecedenteCreditoSection({
  value,
  disabled,
  controles,
  loadingControles = false,
  onChange,
}: AntecedenteCreditoSectionProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
      <div className="flex flex-col gap-1" data-field="tipo_prestamo">
        <label className="font-semibold text-sm">Tipo Préstamo<RequiredMark /></label>
        <Dropdown
          value={value.tipo_prestamo ?? null}
          options={controles.tipo_prestamo}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('tipo_prestamo', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
          filter
        />
      </div>

      <div className="flex flex-col gap-1" data-field="factor_conversion_uf">
        <label className="font-semibold text-sm">Factor Conversión UF<RequiredMark /></label>
        <InputNumber
          value={value.factor_conversion_uf ?? null}
          onValueChange={(e) => onChange('factor_conversion_uf', e.value ?? null)}
          maxLength={limitOf('factor_conversion_uf')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={6}
          placeholder="Ingrese factor"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="destino_credito">
        <label className="font-semibold text-sm">Destino Crédito<RequiredMark /></label>
        <Dropdown
          value={value.destino_credito ?? null}
          options={controles.destino_credito}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('destino_credito', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
          filter
        />
      </div>

      <div className="flex flex-col gap-1" data-field="monto_solicitado">
        <label className="font-semibold text-sm">Monto Solicitado<RequiredMark /></label>
        <InputNumber
          value={value.monto_solicitado ?? null}
          onValueChange={(e) => onChange('monto_solicitado', e.value ?? null)}
          maxLength={limitOf('monto_solicitado')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese monto"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="tipo_tasa">
        <label className="font-semibold text-sm">Tipo Tasa<RequiredMark /></label>
        <Dropdown
          value={value.tipo_tasa ?? null}
          options={controles.tipo_tasa}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('tipo_tasa', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
        />
      </div>

      <div className="flex flex-col gap-1" data-field="tasa">
        <label className="font-semibold text-sm">Tasa<RequiredMark /></label>
        <InputNumber
          value={value.tasa ?? null}
          onValueChange={(e) => onChange('tasa', e.value ?? null)}
          maxLength={limitOf('tasa')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={6}
          placeholder="Ingrese tasa"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="plazo">
        <label className="font-semibold text-sm">Plazo<RequiredMark /></label>
        <InputNumber
          value={value.plazo ?? null}
          onValueChange={(e) => onChange('plazo', e.value ?? null)}
          maxLength={limitOf('plazo')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese plazo"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="fecha_inicio">
        <label className="font-semibold text-sm">Fecha Inicio<RequiredMark /></label>
        <Calendar
          value={toDate(value.fecha_inicio)}
          onChange={(e) => onChange('fecha_inicio', toIsoDate(e.value as Date | null))}
          className="calendar-presto"
          disabled={disabled}
          dateFormat="dd/mm/yy"
          showIcon
          placeholder="Seleccione fecha"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="monto_nominal">
        <label className="font-semibold text-sm">Monto Nominal<RequiredMark /></label>
        <InputNumber
          value={value.monto_nominal ?? null}
          onValueChange={(e) => onChange('monto_nominal', e.value ?? null)}
          maxLength={limitOf('monto_nominal')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese monto nominal"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="monto_residual">
        <label className="font-semibold text-sm">Monto Residual<RequiredMark /></label>
        <InputNumber
          value={value.monto_residual ?? null}
          onValueChange={(e) => onChange('monto_residual', e.value ?? null)}
          maxLength={limitOf('monto_residual')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese monto residual"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="plazo_primer_periodo">
        <label className="font-semibold text-sm">Plazo Primer Periodo<RequiredMark /></label>
        <InputNumber
          value={value.plazo_primer_periodo ?? null}
          onValueChange={(e) => onChange('plazo_primer_periodo', e.value ?? null)}
          maxLength={limitOf('plazo_primer_periodo')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese plazo"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="periodo_gracia">
        <label className="font-semibold text-sm">Periodo Gracia<RequiredMark /></label>
        <InputNumber
          value={value.periodo_gracia ?? null}
          onValueChange={(e) => onChange('periodo_gracia', e.value ?? null)}
          maxLength={limitOf('periodo_gracia')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese periodo"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="comision">
        <label className="font-semibold text-sm">Comisión<RequiredMark /></label>
        <InputNumber
          value={value.comision ?? null}
          onValueChange={(e) => onChange('comision', e.value ?? null)}
          maxLength={limitOf('comision')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese comisión"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="plazo_segundo_periodo">
        <label className="font-semibold text-sm">Plazo Segundo Periodo<RequiredMark /></label>
        <InputNumber
          value={value.plazo_segundo_periodo ?? null}
          onValueChange={(e) => onChange('plazo_segundo_periodo', e.value ?? null)}
          maxLength={limitOf('plazo_segundo_periodo')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese plazo"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="tasa_primer_periodo">
        <label className="font-semibold text-sm">Tasa Primer Periodo<RequiredMark /></label>
        <InputNumber
          value={value.tasa_primer_periodo ?? null}
          onValueChange={(e) => onChange('tasa_primer_periodo', e.value ?? null)}
          maxLength={limitOf('tasa_primer_periodo')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={6}
          placeholder="Ingrese tasa"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="meses_sabaticos">
        <label className="font-semibold text-sm">Meses Sabáticos<RequiredMark /></label>
        <InputNumber
          value={value.meses_sabaticos ?? null}
          onValueChange={(e) => onChange('meses_sabaticos', e.value ?? null)}
          maxLength={limitOf('meses_sabaticos')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese meses"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="variabilidad_tasa">
        <label className="font-semibold text-sm">Variabilidad Tasa<RequiredMark /></label>
        <InputText
          value={value.variabilidad_tasa ?? ''}
          onChange={(e) => onChange('variabilidad_tasa', e.target.value)}
          maxLength={limitOf('variabilidad_tasa')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese variabilidad"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="tasa_segundo_periodo">
        <label className="font-semibold text-sm">Tasa Segundo Periodo<RequiredMark /></label>
        <InputNumber
          value={value.tasa_segundo_periodo ?? null}
          onValueChange={(e) => onChange('tasa_segundo_periodo', e.value ?? null)}
          maxLength={limitOf('tasa_segundo_periodo')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={6}
          placeholder="Ingrese tasa"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="moneda">
        <label className="font-semibold text-sm">Moneda<RequiredMark /></label>
        <Dropdown
          value={value.moneda ?? null}
          options={controles.moneda}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('moneda', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
        />
      </div>

      <div className="flex flex-col gap-1" data-field="tipo_tasa_mixta_prod_com">
        <label className="font-semibold text-sm">Tipo Tasa Mixta Prod. Com.<RequiredMark /></label>
        <InputText
          value={value.tipo_tasa_mixta_prod_com ?? ''}
          onChange={(e) => onChange('tipo_tasa_mixta_prod_com', e.target.value)}
          maxLength={limitOf('tipo_tasa_mixta_prod_com')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese tipo tasa mixta"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="tasa_maxima">
        <label className="font-semibold text-sm">Tasa Máxima<RequiredMark /></label>
        <InputNumber
          value={value.tasa_maxima ?? null}
          onValueChange={(e) => onChange('tasa_maxima', e.value ?? null)}
          maxLength={limitOf('tasa_maxima')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={6}
          placeholder="Ingrese tasa máxima"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="codigo_producto_cartera">
        <label className="font-semibold text-sm">Código Producto Cartera<RequiredMark /></label>
        <InputText
          value={value.codigo_producto_cartera ?? ''}
          onChange={(e) => onChange('codigo_producto_cartera', e.target.value)}
          maxLength={limitOf('codigo_producto_cartera')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese código"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="indicador_segunda_vivienda">
        <label className="font-semibold text-sm">Indicador Segunda Vivienda<RequiredMark /></label>
        <InputText
          value={value.indicador_segunda_vivienda ?? ''}
          onChange={(e) => onChange('indicador_segunda_vivienda', e.target.value)}
          maxLength={limitOf('indicador_segunda_vivienda')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese indicador"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="tipo_financiamiento">
        <label className="font-semibold text-sm">Tipo Financiamiento<RequiredMark /></label>
        <Dropdown
          value={value.tipo_financiamiento ?? null}
          options={controles.tipo_financiamiento}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('tipo_financiamiento', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
          filter
        />
      </div>

      <div className="flex flex-col gap-1" data-field="precio_venta_pesos">
        <label className="font-semibold text-sm">Precio Venta Pesos<RequiredMark /></label>
        <InputNumber
          value={value.precio_venta_pesos ?? null}
          onValueChange={(e) => onChange('precio_venta_pesos', e.value ?? null)}
          maxLength={limitOf('precio_venta_pesos')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese precio"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="precio_venta_moneda_original">
        <label className="font-semibold text-sm">Precio Venta Moneda Original<RequiredMark /></label>
        <InputNumber
          value={value.precio_venta_moneda_original ?? null}
          onValueChange={(e) => onChange('precio_venta_moneda_original', e.value ?? null)}
          maxLength={limitOf('precio_venta_moneda_original')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese precio"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="cantidad_meses_sin_vencimiento">
        <label className="font-semibold text-sm">Cantidad Meses Sin Vencimiento<RequiredMark /></label>
        <InputNumber
          value={value.cantidad_meses_sin_vencimiento ?? null}
          onValueChange={(e) => onChange('cantidad_meses_sin_vencimiento', e.value ?? null)}
          maxLength={limitOf('cantidad_meses_sin_vencimiento')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese cantidad"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="indicador_cred_comp">
        <label className="font-semibold text-sm">Indicador Cred. Comp.<RequiredMark /></label>
        <InputNumber
          value={value.indicador_cred_comp ?? null}
          onValueChange={(e) => onChange('indicador_cred_comp', e.value ?? null)}
          maxLength={limitOf('indicador_cred_comp')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese indicador"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="indicador_pac">
        <label className="font-semibold text-sm">Indicador PAC<RequiredMark /></label>
        <InputText
          value={value.indicador_pac ?? ''}
          onChange={(e) => onChange('indicador_pac', e.target.value)}
          maxLength={limitOf('indicador_pac')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese indicador PAC"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="tipo_tasa_aplic_contab">
        <label className="font-semibold text-sm">Tipo Tasa Aplic. Contab.<RequiredMark /></label>
        <InputText
          value={value.tipo_tasa_aplic_contab ?? ''}
          onChange={(e) => onChange('tipo_tasa_aplic_contab', e.target.value)}
          maxLength={limitOf('tipo_tasa_aplic_contab')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese tipo tasa"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="numero_cuenta_gastos">
        <label className="font-semibold text-sm">N° Cuenta Gastos</label>
        <InputNumber
          value={value.numero_cuenta_gastos ?? null}
          onValueChange={(e) => onChange('numero_cuenta_gastos', e.value ?? null)}
          maxLength={limitOf('numero_cuenta_gastos')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese cuenta"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="prestamo_maximo">
        <label className="font-semibold text-sm">Préstamo Máximo</label>
        <InputNumber
          value={value.prestamo_maximo ?? null}
          onValueChange={(e) => onChange('prestamo_maximo', e.value ?? null)}
          maxLength={limitOf('prestamo_maximo')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          disabled={disabled}
          minFractionDigits={0}
          maxFractionDigits={2}
          placeholder="Ingrese préstamo máximo"
        />
      </div>
    </div>
  );
}
