import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import { InputText } from 'primereact/inputtext';

import type { ControlesDatosComercial } from '../models/catalogo';
import type { CargaOperacionBancoDatosComercial } from '../models/carga_operacion_banco';
import { limitOf } from '../models/fieldLimits';
import RequiredMark from '@/shared/components/RequiredMark';
import { formatRutSinPuntos } from '@/shared/utils/rut';

interface DatosComercialSectionProps {
  value: CargaOperacionBancoDatosComercial;
  disabled: boolean;
  controles: ControlesDatosComercial;
  loadingControles?: boolean;
  onChange: <K extends keyof CargaOperacionBancoDatosComercial>(
    field: K,
    value: CargaOperacionBancoDatosComercial[K],
  ) => void;
}

const emptyMessage = 'Sin resultados';

export default function DatosComercialSection({
  value,
  disabled,
  controles,
  loadingControles = false,
  onChange,
}: DatosComercialSectionProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
      <div className="flex flex-col gap-1" data-field="codigo_ejecutivo">
        <label className="font-semibold text-sm">Código Ejecutivo</label>
        <InputNumber
          value={value.codigo_ejecutivo ?? null}
          onValueChange={(e) => onChange('codigo_ejecutivo', e.value ?? null)}
          maxLength={limitOf('codigo_ejecutivo')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese código"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="login_ejecutivo">
        <label className="font-semibold text-sm">Login Ejecutivo</label>
        <InputText
          value={value.login_ejecutivo ?? ''}
          onChange={(e) => onChange('login_ejecutivo', e.target.value)}
          maxLength={limitOf('login_ejecutivo')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese login"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="nombre_ejecutivo">
        <label className="font-semibold text-sm">Nombre Ejecutivo</label>
        <InputText
          value={value.nombre_ejecutivo ?? ''}
          onChange={(e) => onChange('nombre_ejecutivo', e.target.value)}
          maxLength={limitOf('nombre_ejecutivo')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese nombre"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="rut_ejecutivo">
        <label className="font-semibold text-sm">RUT Ejecutivo</label>
        <InputText
          value={value.rut_ejecutivo ?? ''}
          onChange={(e) => onChange('rut_ejecutivo', formatRutSinPuntos(e.target.value))}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="12345678-9"
          maxLength={limitOf('rut_ejecutivo')}
        />
      </div>

      <div className="flex flex-col gap-1" data-field="codigo_oficina">
        <label className="font-semibold text-sm">Código Oficina</label>
        <InputNumber
          value={value.codigo_oficina ?? null}
          onValueChange={(e) => onChange('codigo_oficina', e.value ?? null)}
          maxLength={limitOf('codigo_oficina')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese código"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="nombre_oficina">
        <label className="font-semibold text-sm">Nombre Oficina</label>
        <InputText
          value={value.nombre_oficina ?? ''}
          onChange={(e) => onChange('nombre_oficina', e.target.value)}
          maxLength={limitOf('nombre_oficina')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese oficina"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="codigo_curse">
        <label className="font-semibold text-sm">Código Curse</label>
        <InputNumber
          value={value.codigo_curse ?? null}
          onValueChange={(e) => onChange('codigo_curse', e.value ?? null)}
          maxLength={limitOf('codigo_curse')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese código"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="glosa_curse">
        <label className="font-semibold text-sm">Glosa Curse</label>
        <InputText
          value={value.glosa_curse ?? ''}
          onChange={(e) => onChange('glosa_curse', e.target.value)}
          maxLength={limitOf('glosa_curse')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese glosa"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="codigo_ejecutivo_curse">
        <label className="font-semibold text-sm">Código Ejecutivo Curse</label>
        <InputNumber
          value={value.codigo_ejecutivo_curse ?? null}
          onValueChange={(e) => onChange('codigo_ejecutivo_curse', e.value ?? null)}
          maxLength={limitOf('codigo_ejecutivo_curse')}
          className="w-full"
          inputClassName="w-full form-input-presto"
          useGrouping={false}
          disabled={disabled}
          placeholder="Ingrese código"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="login_ejecutivo_curse">
        <label className="font-semibold text-sm">Login Ejecutivo Curse</label>
        <InputText
          value={value.login_ejecutivo_curse ?? ''}
          onChange={(e) => onChange('login_ejecutivo_curse', e.target.value)}
          maxLength={limitOf('login_ejecutivo_curse')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese login"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="nombre_ejecutivo_curse">
        <label className="font-semibold text-sm">Nombre Ejecutivo Curse</label>
        <InputText
          value={value.nombre_ejecutivo_curse ?? ''}
          onChange={(e) => onChange('nombre_ejecutivo_curse', e.target.value)}
          maxLength={limitOf('nombre_ejecutivo_curse')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese nombre"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="rut_ejecutivo_curse">
        <label className="font-semibold text-sm">RUT Ejecutivo Curse</label>
        <InputText
          value={value.rut_ejecutivo_curse ?? ''}
          onChange={(e) => onChange('rut_ejecutivo_curse', formatRutSinPuntos(e.target.value))}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="12345678-9"
          maxLength={limitOf('rut_ejecutivo_curse')}
        />
      </div>

      <div className="flex flex-col gap-1" data-field="rut_banco">
        <label className="font-semibold text-sm">RUT Banco</label>
        <InputText
          value={value.rut_banco ?? ''}
          onChange={(e) => onChange('rut_banco', formatRutSinPuntos(e.target.value))}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="12345678-9"
          maxLength={limitOf('rut_banco')}
        />
      </div>

      <div className="flex flex-col gap-1" data-field="renovacion_urbana">
        <label className="font-semibold text-sm">Renovación Urbana</label>
        <InputText
          value={value.renovacion_urbana ?? ''}
          onChange={(e) => onChange('renovacion_urbana', e.target.value)}
          maxLength={limitOf('renovacion_urbana')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese renovación urbana"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="nombre_banco">
        <label className="font-semibold text-sm">Nombre Banco<RequiredMark /></label>
        <InputText
          value={value.nombre_banco ?? ''}
          onChange={(e) => onChange('nombre_banco', e.target.value)}
          maxLength={limitOf('nombre_banco')}
          className="form-input-presto w-full"
          disabled={disabled}
          placeholder="Ingrese banco"
        />
      </div>

      <div className="flex flex-col gap-1" data-field="tipo_hipoteca">
        <label className="font-semibold text-sm">Tipo Hipoteca<RequiredMark /></label>
        <Dropdown
          value={value.tipo_hipoteca ?? null}
          options={controles.tipo_hipoteca}
          optionLabel="description"
          optionValue="code"
          onChange={(e) => onChange('tipo_hipoteca', e.value ?? null)}
          className="form-dropdown-presto w-full"
          disabled={disabled}
          loading={loadingControles}
          placeholder="Seleccione"
          emptyMessage={emptyMessage}
          showClear
          filter
        />
      </div>
    </div>
  );
}
