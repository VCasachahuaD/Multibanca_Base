import type { ReactNode } from 'react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { Column } from 'primereact/column';
import { DataTable } from 'primereact/datatable';
import { Dialog } from 'primereact/dialog';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';

import type { ControlesAntecedenteVendedor } from '../models/catalogo';
import type { CargaOperacionBancoAntecedenteVendedor } from '../models/carga_operacion_banco';
import { limitOf } from '../models/fieldLimits';
import { telefonoFijoDigitos, telefonoFijoPlaceholder } from '@/shared/utils/fieldLimits';
import RequiredMark from '@/shared/components/RequiredMark';
import {
  describeFechaNacimientoError,
  maxFechaNacimiento,
  minFechaNacimiento,
  viewDateNacimiento,
  yearRangeNacimiento,
} from '@/shared/utils/dateCoherence';
import {
  clearFieldErrors,
  focusFieldByKey,
} from '@/features/actividades/datos_operacion/utils/fieldFocus';
import {
  formatRutSinPuntos,
  isValidRutSinPuntos,
  describeRutError,
  rutComparableKey,
} from '@/shared/utils/rut';
import { describeEmailError, EMAIL_PLACEHOLDER, sanitizePhone } from '@/shared/utils/chileanValidators';
import {
  describeDireccionError,
  describeNombrePersonaError,
  describeRazonSocialError,
  DIRECCION_HINT,
  NOMBRE_PERSONA_HINT,
  RAZON_SOCIAL_HINT,
  sanitizeDireccion,
  sanitizeNombrePersona,
  sanitizeRazonSocial,
} from '@/shared/utils/textValidators';

interface AntecedentesVendedorSectionProps {
  value: CargaOperacionBancoAntecedenteVendedor[];
  idExpediente: number;
  idCargaOperacionBanco: number;
  disabled: boolean;
  /**
   * Control explícito para habilitar acciones de la grilla.
   * Ver detalle siempre está habilitado.
   * Editar / eliminar / agregar solo se habilitan cuando canEdit = true.
   */
  canEdit?: boolean;
  controles: ControlesAntecedenteVendedor;
  loadingControles?: boolean;
  /** RN-V-06: true si se seleccionó una Inmobiliaria (Dirección/Región/Comuna obligatorias). */
  requiereDireccion?: boolean;
  /** RN-V-02: true si se informó N° Piloto → se exige al menos un vendedor. */
  requiereAlMenosUno?: boolean;
  onChange: (value: CargaOperacionBancoAntecedenteVendedor[]) => void;
  onWarn?: (message: string) => void;
  /** UX-001: fila guardada que quedó con obligatorios pendientes (viene de la página). */
  rowToFocus?: CargaOperacionBancoAntecedenteVendedor | null;
  /** Avisa a la página que `rowToFocus` ya fue procesado. */
  onRowToFocusHandled?: () => void;
}

const renderResponsiveCell = (value: ReactNode, titulo: string) => <div data-titulo={titulo}>{value ?? ""}</div>;

type DialogMode = 'view' | 'edit' | 'create';

const emptyMessage = 'Sin registros';

const now = () => new Date().toISOString();

const emptyVendedor = (
  idExpediente: number,
  idCargaOperacionBanco: number,
): CargaOperacionBancoAntecedenteVendedor => ({
  id_carga_operacion_banco_antecedente_vendedor: 0,
  id_carga_operacion_banco: idCargaOperacionBanco,
  id_expediente: idExpediente,
  rut: '',
  tipo_vendedor: null,
  razon_social: '',
  nombres: '',
  apellido_paterno: '',
  apellido_materno: '',
  fecha_nacimiento: null,
  genero: null,
  estado_civil: null,
  relacion_titular: null,
  direccion: '',
  region: null,
  comuna: null,
  telefono: '',
  email: '',
  nacionalidad: null,
  profesion: '',
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const toDate = (value?: string | null): Date | null => {
  if (!value) return null;

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const toIsoDate = (value: Date | null | undefined): string | null => {
  if (!value) return null;
  return value.toISOString();
};

const getOptionDescription = (
  options: { code?: string | null; description?: string | null }[],
  code?: string | null,
) => options.find((option) => option.code === code)?.description ?? code ?? '';

/**
 * Grupo propio del ConfirmDialog.
 *
 * `confirmDialog()` emite el evento 'confirm-dialog' por el OverlayService y
 * TODAS las instancias de <ConfirmDialog /> montadas lo reciben: sin `group`,
 * el diálogo se mostraría duplicado (uno por cada instancia de la página) y la
 * acción se ejecutaría dos veces. Con `group`, solo responde la instancia que
 * lo declara.
 */
const CONFIRM_GROUP = 'antecedentes-vendedor';

/**
 * Compara la fila de la grilla con la que se está editando o eliminando.
 *
 * Se usa identidad en lugar del índice de la grilla porque la grilla muestra
 * únicamente las filas activas (`row_status !== false`): su índice NO coincide
 * con la posición real dentro de `value` cuando hay filas eliminadas
 * lógicamente (borrado lógico con id > 0).
 * - Filas persistidas: se comparan por id.
 * - Filas nuevas (aún sin guardar, id = 0): por referencia.
 */
const esMismoVendedor = (
  item: CargaOperacionBancoAntecedenteVendedor,
  target: CargaOperacionBancoAntecedenteVendedor,
): boolean =>
  target.id_carga_operacion_banco_antecedente_vendedor > 0
    ? item.id_carga_operacion_banco_antecedente_vendedor ===
      target.id_carga_operacion_banco_antecedente_vendedor
    : item === target;

// NA.2: Código de área telefónico según Región/Comuna (patrón de datos_operacion/DatosOperacionPersonaGrid).
const getAreaCode = (
  regionCode: string | null | undefined,
  comunaCode: string | null | undefined,
): string | null => {
  if (!regionCode) return null;
  const r = String(regionCode).trim();
  const c = String(comunaCode ?? '').trim();

  switch (r) {
    case '07': return '2';    // Metropolitana
    case '08': return '72';   // O'Higgins
    case '10': return '42';   // Ñuble
    case '12': return '45';   // Araucanía
    case '13': return '63';   // Los Ríos
    case '15': return '67';   // Aysén
    case '16': return '61';   // Magallanes
    case '06':
      if (c === '06-18' || c === '06-32') return '34';
      if (c === '06-23' || c === '06-26') return '33';
      return null;
    case '09':
      if (c === '09-10' || c === '09-01') return '73';
      if (c === '09-06' || c === '09-26') return '75';
      return null;
    case '11':
      if (c === '11-07') return '41';
      return null;
    case '14':
      if (c === '14-16') return '64';
      if (c === '14-13') return '65';
      return null;
    default: return null;
  }
};

const AREA_CODES_KNOWN = [
  '2', '33', '34', '41', '42', '45', '61', '63', '64', '65', '67', '72', '73', '75',
];

/**
 * Devuelve la llave (data-field) del primer campo obligatorio faltante del
 * vendedor en el diálogo, para poder enfocarlo con focusFieldByKey.
 * (RN-V-04: Razón Social si jurídico / Nombres + Ap. Paterno si natural;
 *  UX-004: Fecha de nacimiento si no es coherente, futura, menor de edad o
 *  año imposible;
 *  RN-V-06: Dirección/Región/Comuna si inmobiliaria.)
 */
export const getMissingVendedorFieldKey = (
  draft: CargaOperacionBancoAntecedenteVendedor,
  requiereDireccion: boolean,
): string | null => {
  if (!isValidRutSinPuntos(draft.rut)) return 'rut';
  if (!draft.tipo_vendedor) return 'tipo_vendedor';

  const tipo = draft.tipo_vendedor?.toString().toUpperCase();

  if (tipo === 'JURIDICO' || tipo === 'JURÍDICO' || tipo === '02') {
    if (!draft.razon_social?.trim()) return 'razon_social';
    if (describeRazonSocialError(draft.razon_social)) return 'razon_social';
  } else {
    if (!draft.nombres?.trim()) return 'nombres';
    if (describeNombrePersonaError(draft.nombres)) return 'nombres';
    if (!draft.apellido_paterno?.trim()) return 'apellido_paterno';
    if (describeNombrePersonaError(draft.apellido_paterno)) return 'apellido_paterno';
  }

  if (describeFechaNacimientoError(draft.fecha_nacimiento)) return 'fecha_nacimiento';

  if (describeDireccionError(draft.direccion)) return 'direccion';

  if (requiereDireccion) {
    if (!draft.direccion?.trim()) return 'direccion';
    if (!draft.region) return 'region';
    if (!draft.comuna) return 'comuna';
  }

  // UX-007: el email es opcional, pero si se ingresa debe tener formato válido.
  if (describeEmailError(draft.email)) return 'email';

  return null;
};

export default function AntecedentesVendedorSection({
  value,
  idExpediente,
  idCargaOperacionBanco,
  disabled,
  canEdit,
  controles,
  loadingControles = false,
  requiereDireccion = false,
  requiereAlMenosUno = false,
  onChange,
  onWarn,
  rowToFocus = null,
  onRowToFocusHandled,
}: AntecedentesVendedorSectionProps) {
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogMode, setDialogMode] = useState<DialogMode>('view');
  /*
   * Identidad de la fila en edición, NO un índice: la grilla muestra solo las
   * filas activas (row_status !== false), así que un índice de grilla no
   * coincide con la posición real dentro de `value` cuando hay filas eliminadas
   * lógicamente.
   */
  const [editingRow, setEditingRow] =
    useState<CargaOperacionBancoAntecedenteVendedor | null>(null);
  const [draft, setDraft] = useState<CargaOperacionBancoAntecedenteVendedor>(
    emptyVendedor(idExpediente, idCargaOperacionBanco),
  );
  /** UX-001: true cuando el diálogo se abrió desde la validación de la página. */
  const [focusPending, setFocusPending] = useState(false);

  const dialogContentRef = useRef<HTMLDivElement>(null);

  /*
   * Modo de edición de acciones de grilla.
   *
   * IMPORTANTE:
   * La habilitación del lápiz y tacho NO debe depender del render inicial
   * de PrimeReact DataTable. Por eso usamos una variable explícita y luego
   * forzamos el key de la grilla/columna acciones.
   *
   * - Ver detalle siempre habilitado.
   * - Editar / eliminar / agregar solo si el botón general Editar activó canEdit.
   */
  const canModifyRows = typeof canEdit === 'boolean' ? canEdit : !disabled;

  const gridModeKey = canModifyRows ? 'edit' : 'view';

  const isDialogReadOnly = dialogMode === 'view' || !canModifyRows;

  // RN-V-04: campos condicionales según el tipo de vendedor (Natural/Jurídico)
  const tipoVendedorActual = draft.tipo_vendedor?.toString().toUpperCase();
  const esJuridico =
    tipoVendedorActual === 'JURIDICO' ||
    tipoVendedorActual === 'JURÍDICO' ||
    tipoVendedorActual === '02';
  const esNatural = !!draft.tipo_vendedor && !esJuridico;
  const disabledCamposNatural = isDialogReadOnly || !esNatural;
  const disabledRazonSocial = isDialogReadOnly || !esJuridico;

  // NA.1: filtra las comunas según la región seleccionada (formato "{region}-{comuna}")
  const filteredComunaOptions = useMemo(() => {
    const regionCode = String(draft.region ?? '').trim();
    if (!regionCode) return controles.comuna;
    return controles.comuna.filter((c) => {
      const code = String(c.code ?? '');
      return code === regionCode || code.startsWith(regionCode + '-');
    });
  }, [controles.comuna, draft.region]);

  // NA.1: al cambiar la región, limpia la comuna si no le corresponde (solo en el control)
  useEffect(() => {
    if (isDialogReadOnly) return;
    const regionCode = String(draft.region ?? '').trim();
    if (!regionCode) return;
    const comunaVal = String(draft.comuna ?? '').trim();
    if (comunaVal && !comunaVal.startsWith(regionCode + '-') && comunaVal !== regionCode) {
      updateDraft('comuna', null);
    }
  }, [draft.region, isDialogReadOnly]);

  // NA.2: autocompleta el teléfono con el código de área según región/comuna
  useEffect(() => {
    if (isDialogReadOnly) return;
    const areaCode = getAreaCode(draft.region, draft.comuna);
    if (!areaCode) return;
    const current = String(draft.telefono ?? '').trim();
    if (current === areaCode) return;

    let newValue = areaCode;
    if (current) {
      const matchedCode = AREA_CODES_KNOWN.find((code) => current.startsWith(code));
      if (matchedCode) {
        newValue = areaCode + current.slice(matchedCode.length);
      } else if (current.length <= 3) {
        newValue = areaCode;
      } else {
        return;
      }
    }

    if (newValue !== current) {
      updateDraft('telefono', newValue);
    }
  }, [draft.region, draft.comuna, isDialogReadOnly]);

  const rows = useMemo(
    () => (value ?? []).filter((vendedor) => vendedor.row_status !== false),
    [value],
  );

  const openNew = () => {
    if (!canModifyRows) return;

    setEditingRow(null);
    setDialogMode('create');
    setDraft(emptyVendedor(idExpediente, idCargaOperacionBanco));
    setDialogVisible(true);
  };

  const openView = (rowData: CargaOperacionBancoAntecedenteVendedor) => {
    setEditingRow(null);
    setDialogMode('view');
    setDraft({
      ...emptyVendedor(idExpediente, idCargaOperacionBanco),
      ...rowData,
      id_expediente: rowData.id_expediente || idExpediente,
      id_carga_operacion_banco:
        rowData.id_carga_operacion_banco || idCargaOperacionBanco,
    });
    setDialogVisible(true);
  };

  const openEdit = (rowData: CargaOperacionBancoAntecedenteVendedor) => {
    if (!canModifyRows) return;

    setEditingRow(rowData);
    setDialogMode('edit');
    setDraft({
      ...emptyVendedor(idExpediente, idCargaOperacionBanco),
      ...rowData,
      id_expediente: rowData.id_expediente || idExpediente,
      id_carga_operacion_banco:
        rowData.id_carga_operacion_banco || idCargaOperacionBanco,
    });
    setDialogVisible(true);
  };

  /**
   * UX-001 (navegación al input): cuando la página detecta que una fila guardada
   * quedó con obligatorios pendientes, abre el diálogo de ESA fila en modo
   * edición y enfoca el primer campo faltante.
   */
  useEffect(() => {
    if (!rowToFocus || !canModifyRows) return;

    setFocusPending(true);
    openEdit(rowToFocus);
    onRowToFocusHandled?.();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rowToFocus, canModifyRows]);

  useEffect(() => {
    if (!focusPending) return;

    setFocusPending(false);
    clearFieldErrors();
    /*
     * 450 ms: hay que esperar a que el diálogo TERMINE su animación de entrada.
     * El Calendar de PrimeReact abre su panel al recibir el foco; si el foco
     * llega a mitad de la animación, el panel queda en un estado inconsistente
     * (se ve pero no responde hasta que se vuelve a hacer clic en el campo).
     */
    focusFieldByKey(
      getMissingVendedorFieldKey(draft, requiereDireccion),
      dialogContentRef.current,
      450,
    );
  }, [focusPending, draft, requiereDireccion]);

  const updateDraft = <K extends keyof CargaOperacionBancoAntecedenteVendedor>(
    field: K,
    fieldValue: CargaOperacionBancoAntecedenteVendedor[K],
  ) => {
    if (isDialogReadOnly) return;

    setDraft((prev) => ({
      ...prev,
      [field]: fieldValue,
    }));
  };

  // RN-V-04: al cambiar el tipo se CONSERVAN los valores ya ingresados en el
  // draft (así se restauran si el usuario vuelve al tipo anterior). Los campos
  // que no aplican al tipo se excluyen del payload al Guardar/Avanzar.
  const handleTipoVendedorChange = (value: string | null) => {
    if (isDialogReadOnly) return;

    setDraft((prev) => ({
      ...prev,
      tipo_vendedor: value,
    }));
  };

  /**
   * Busca OTRA fila activa con el mismo RUT (comparado sin puntos ni guiones).
   * Excluye la fila que se está editando. Evita registrar dos veces al mismo
   * vendedor, que hoy es posible porque ni el backend ni la BD lo impiden.
   */
  const buscarRutDuplicado = () =>
    (value ?? []).find(
      (item) =>
        item.row_status !== false &&
        (!editingRow || !esMismoVendedor(item, editingRow)) &&
        rutComparableKey(item.rut) !== '' &&
        rutComparableKey(item.rut) === rutComparableKey(draft.rut),
    );

  const validateDraft = () => {
    if (!draft.rut?.trim()) return 'Debe ingresar RUT del vendedor.';
    const rutError = describeRutError(draft.rut);
    if (rutError) return `RUT del vendedor. ${rutError}`;
    if (buscarRutDuplicado()) {
      return `Ya existe un vendedor registrado con el RUT ${draft.rut}.`;
    }
    if (!draft.tipo_vendedor) return 'Debe seleccionar Tipo de Vendedor.';

    const tipo = draft.tipo_vendedor?.toString().toUpperCase();

    if (tipo === 'JURIDICO' || tipo === 'JURÍDICO' || tipo === '02') {
      if (!draft.razon_social?.trim()) {
        return 'Debe ingresar Razón Social del vendedor jurídico.';
      }
      const razonSocialError = describeRazonSocialError(
        draft.razon_social,
        'Razón Social del vendedor. ',
      );
      if (razonSocialError) return razonSocialError;
    } else {
      if (!draft.nombres?.trim()) return 'Debe ingresar Nombres del vendedor.';
      const nombresError = describeNombrePersonaError(
        draft.nombres,
        'Nombres del vendedor. ',
      );
      if (nombresError) return nombresError;

      if (!draft.apellido_paterno?.trim()) {
        return 'Debe ingresar Apellido Paterno del vendedor.';
      }
      const apellidoPaternoError = describeNombrePersonaError(
        draft.apellido_paterno,
        'Apellido Paterno del vendedor. ',
      );
      if (apellidoPaternoError) return apellidoPaternoError;
    }

    const direccionError = describeDireccionError(
      draft.direccion,
      'Dirección del vendedor. ',
    );
    if (direccionError) return direccionError;

    const fechaNacimientoError = describeFechaNacimientoError(draft.fecha_nacimiento);
    if (fechaNacimientoError) {
      return `Fecha de nacimiento del vendedor. ${fechaNacimientoError}`;
    }

    if (requiereDireccion) {
      if (!draft.direccion?.trim()) {
        return 'Debe ingresar Dirección del vendedor.';
      }
      if (!draft.region) {
        return 'Debe seleccionar Región del vendedor.';
      }
      if (!draft.comuna) {
        return 'Debe seleccionar Comuna del vendedor.';
      }
    }

    const emailError = describeEmailError(draft.email);
    if (emailError) {
      return `Email del vendedor. ${emailError}`;
    }

    return '';
  };

  const saveDraft = () => {
    if (isDialogReadOnly) return;

    const validationMessage = validateDraft();

    if (validationMessage) {
      onWarn?.(validationMessage);
      clearFieldErrors();
      focusFieldByKey(
        buscarRutDuplicado()
          ? 'rut'
          : getMissingVendedorFieldKey(draft, requiereDireccion),
        dialogContentRef.current,
        80,
      );
      return;
    }

    const normalizedDraft: CargaOperacionBancoAntecedenteVendedor = {
      ...draft,
      id_expediente: idExpediente || draft.id_expediente,
      id_carga_operacion_banco:
        idCargaOperacionBanco || draft.id_carga_operacion_banco,
      is_active: draft.is_active ?? true,
      row_status: draft.row_status ?? true,
      created_date: draft.created_date ?? now(),
    };

    if (dialogMode === 'create') {
      onChange([...(value ?? []), normalizedDraft]);
    } else if (editingRow) {
      onChange(
        (value ?? []).map((item) =>
          esMismoVendedor(item, editingRow) ? normalizedDraft : item,
        ),
      );
    }

    setDialogVisible(false);
  };

  const executeRemoveRow = (rowData: CargaOperacionBancoAntecedenteVendedor) => {
    // Fila persistida: borrado lógico (permanece en el array con row_status=false).
    if (rowData.id_carga_operacion_banco_antecedente_vendedor > 0) {
      onChange(
        (value ?? []).map((item) =>
          esMismoVendedor(item, rowData)
            ? {
                ...item,
                row_status: false,
                is_active: false,
              }
            : item,
        ),
      );
      return;
    }

    // Fila nueva (aún sin guardar): se quita del state.
    onChange((value ?? []).filter((item) => !esMismoVendedor(item, rowData)));
  };

  const confirmRemoveRow = (rowData: CargaOperacionBancoAntecedenteVendedor) => {
    if (!canModifyRows) return;

    const vendedorLabel =
      nombreVendedorBodyTemplate(rowData) || rowData.rut || 'este registro';

    confirmDialog({
      group: CONFIRM_GROUP,
      header: 'Confirmar eliminación',
      message: `¿Está seguro de querer eliminar ${vendedorLabel}?`,
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: 'Sí, eliminar',
      rejectLabel: 'Cancelar',
      acceptClassName: 'p-button-danger',
      accept: () => executeRemoveRow(rowData),
    });
  };

  const actionBodyTemplate = (
    rowData: CargaOperacionBancoAntecedenteVendedor,
  ) => (
    <div className="flex gap-2 justify-center">
      <Button
        type="button"
        icon="pi pi-eye"
        severity="secondary"
        outlined
        size="small"
        onClick={() => openView(rowData)}
        tooltip="Ver detalle"
      />
      <Button
        key={`editar-${gridModeKey}`}
        type="button"
        icon="pi pi-pencil"
        severity="info"
        outlined
        size="small"
        disabled={canModifyRows ? false : true}
        onClick={() => openEdit(rowData)}
        tooltip="Editar"
      />
      <Button
        key={`eliminar-${gridModeKey}`}
        type="button"
        icon="pi pi-trash"
        severity="danger"
        outlined
        size="small"
        disabled={canModifyRows ? false : true}
        onClick={() => confirmRemoveRow(rowData)}
        tooltip="Eliminar"
      />
    </div>
  );

  const tipoVendedorBodyTemplate = (
    rowData: CargaOperacionBancoAntecedenteVendedor,
  ) => getOptionDescription(controles.tipo_vendedor, rowData.tipo_vendedor);

  const nombreVendedorBodyTemplate = (
    rowData: CargaOperacionBancoAntecedenteVendedor,
  ) => {
    if (rowData.razon_social?.trim()) return rowData.razon_social;

    return [rowData.nombres, rowData.apellido_paterno, rowData.apellido_materno]
      .filter(Boolean)
      .join(' ');
  };

  const getDialogTitle = () => {
    if (dialogMode === 'view') return 'Detalle del Vendedor';
    if (dialogMode === 'edit') return 'Editar Vendedor';
    return 'Agregar Vendedor';
  };

  const dialogFooter =
    dialogMode === 'view' ? (
      <div className="flex justify-end gap-2">
        <Button
          type="button"
          label="Cerrar"
          icon="pi pi-times"
          severity="secondary"
          outlined
          onClick={() => setDialogVisible(false)}
        />
      </div>
    ) : (
      <div className="flex justify-end gap-2">
        <Button
          type="button"
          label="Cancelar"
          icon="pi pi-times"
          severity="secondary"
          outlined
          onClick={() => setDialogVisible(false)}
        />
        <Button
          type="button"
          label="Aceptar"
          icon="pi pi-check"
          severity="success"
          onClick={saveDraft}
          disabled={!canModifyRows}
        />
      </div>
    );

  return (
    <div
      className="flex flex-col gap-4 section-error"
      data-field="antecedentes-vendedor"
    >
      <ConfirmDialog group={CONFIRM_GROUP} />
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">
            Sección: Antecedentes del Vendedor
          </h3>
          <p className="text-sm text-gray-500">
            Agregue uno o más vendedores asociados a la operación.
          </p>
          {requiereAlMenosUno && (
            <p className="mt-1 text-sm font-semibold text-amber-700">
              Obligatorio: registre al menos un vendedor porque se informó N° Piloto.
            </p>
          )}
        </div>

        <Button
          type="button"
          label="Agregar Vendedor"
          icon="pi pi-plus"
          severity="success"
          outlined
          onClick={openNew}
          disabled={!canModifyRows}
          className="btn-responsive"
        />
      </div>

      <DataTable
        key={`antecedentes-vendedor-grid-${gridModeKey}`}
        value={rows}
        emptyMessage={emptyMessage}
        paginator={rows.length > 5}
        rows={5}
        stripedRows
          size="small"
        className="text-sm datatable-presto"
      >
        <Column field="rut" header="RUT" body={(r) => renderResponsiveCell(r.rut, "RUT: ")} />
        <Column
          field="tipo_vendedor"
          header="Tipo"
          body={(r) => renderResponsiveCell(tipoVendedorBodyTemplate(r), "Tipo: ")}
        />
        <Column header="Vendedor" body={(r) => renderResponsiveCell(nombreVendedorBodyTemplate(r), "Vendedor: ")} />
        <Column field="telefono" header="Teléfono" body={(r) => renderResponsiveCell(r.telefono, "Teléfono: ")} />
        <Column field="email" header="Email" body={(r) => renderResponsiveCell(r.email, "Email: ")} />
        <Column
          key={`acciones-${gridModeKey}`}
          header="Acciones"
          body={(r) => renderResponsiveCell(actionBodyTemplate(r), "Acciones: ")}
          style={{ width: '170px' }}
        />
      </DataTable>

      <Dialog
        header={getDialogTitle()}
        visible={dialogVisible}
        onHide={() => setDialogVisible(false)}
        footer={dialogFooter}
        modal
        className="w-full md:w-10/12 lg:w-8/12"
      >
        <div ref={dialogContentRef}>
        <p className="mb-4 text-sm text-gray-600">
          Los campos marcados con <RequiredMark /> son obligatorios.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="flex flex-col gap-1" data-field="rut">
            <label className="font-semibold text-sm">RUT<RequiredMark /></label>
            <InputText
              value={draft.rut ?? ''}
              onChange={(e) => updateDraft('rut', formatRutSinPuntos(e.target.value))}
              disabled={isDialogReadOnly}
              className="form-input-presto w-full"
              placeholder="12345678-9"
              maxLength={limitOf('rut')}
            />
          </div>

          <div className="flex flex-col gap-1" data-field="tipo_vendedor">
            <label className="font-semibold text-sm">Tipo Vendedor<RequiredMark /></label>
            <Dropdown
              value={draft.tipo_vendedor ?? null}
              options={controles.tipo_vendedor}
              optionLabel="description"
              optionValue="code"
              onChange={(e) => handleTipoVendedorChange(e.value ?? null)}
              disabled={isDialogReadOnly}
              className="form-dropdown-presto w-full"
              loading={loadingControles}
              placeholder="Seleccione"
              emptyMessage="Sin resultados"
              showClear
            />
          </div>

          {esJuridico && (
            <div className="flex flex-col gap-1" data-field="razon_social">
              <label className="font-semibold text-sm">Razón Social{esJuridico && <RequiredMark />}</label>
              <InputText
                value={draft.razon_social ?? ''}
                onChange={(e) =>
                  updateDraft('razon_social', sanitizeRazonSocial(e.target.value))
                }
                maxLength={limitOf('razon_social')}
                disabled={disabledRazonSocial}
                className="form-input-presto w-full"
                placeholder="Ingrese razón social"
              />
              <small className="text-xs text-gray-500">{RAZON_SOCIAL_HINT}</small>
            </div>
          )}

          {esNatural && (
            <>
              <div className="flex flex-col gap-1" data-field="nombres">
                <label className="font-semibold text-sm">Nombres{esNatural && <RequiredMark />}</label>
                <InputText
                  value={draft.nombres ?? ''}
                  onChange={(e) =>
                    updateDraft('nombres', sanitizeNombrePersona(e.target.value))
                  }
                  maxLength={limitOf('nombres')}
                  disabled={disabledCamposNatural}
                  className="form-input-presto w-full"
                  placeholder="Ingrese nombres"
                />
                <small className="text-xs text-gray-500">{NOMBRE_PERSONA_HINT}</small>
              </div>

              <div className="flex flex-col gap-1" data-field="apellido_paterno">
                <label className="font-semibold text-sm">Apellido Paterno{esNatural && <RequiredMark />}</label>
                <InputText
                  value={draft.apellido_paterno ?? ''}
                  onChange={(e) =>
                    updateDraft('apellido_paterno', sanitizeNombrePersona(e.target.value))
                  }
                  maxLength={limitOf('apellido_paterno')}
                  disabled={disabledCamposNatural}
                  className="form-input-presto w-full"
                  placeholder="Ingrese apellido paterno"
                />
                <small className="text-xs text-gray-500">{NOMBRE_PERSONA_HINT}</small>
              </div>

              <div className="flex flex-col gap-1" data-field="apellido_materno">
                <label className="font-semibold text-sm">Apellido Materno</label>
                <InputText
                  value={draft.apellido_materno ?? ''}
                  onChange={(e) =>
                    updateDraft('apellido_materno', sanitizeNombrePersona(e.target.value))
                  }
                  maxLength={limitOf('apellido_materno')}
                  disabled={disabledCamposNatural}
                  className="form-input-presto w-full"
                  placeholder="Ingrese apellido materno"
                />
                <small className="text-xs text-gray-500">{NOMBRE_PERSONA_HINT}</small>
              </div>

              <div className="flex flex-col gap-1" data-field="fecha_nacimiento">
                <label className="font-semibold text-sm">Fecha Nacimiento</label>
                <Calendar
                  value={toDate(draft.fecha_nacimiento)}
                  onChange={(e) =>
                    updateDraft('fecha_nacimiento', toIsoDate(e.value as Date | null))
                  }
                  disabled={disabledCamposNatural}
                  className="calendar-presto"
                  dateFormat="dd/mm/yy"
                  minDate={minFechaNacimiento()}
                  maxDate={maxFechaNacimiento()}
                  yearRange={yearRangeNacimiento()}
                  viewDate={viewDateNacimiento(draft.fecha_nacimiento)}
                  showIcon
                  placeholder="Seleccione fecha"
                />
              </div>

              <div className="flex flex-col gap-1" data-field="genero">
                <label className="font-semibold text-sm">Género</label>
                <Dropdown
                  value={draft.genero ?? null}
                  options={controles.genero}
                  optionLabel="description"
                  optionValue="code"
                  onChange={(e) => updateDraft('genero', e.value ?? null)}
                  disabled={disabledCamposNatural}
                  className="form-dropdown-presto w-full"
                  loading={loadingControles}
                  placeholder="Seleccione"
                  emptyMessage="Sin resultados"
                  showClear
                />
              </div>

              <div className="flex flex-col gap-1" data-field="estado_civil">
                <label className="font-semibold text-sm">Estado Civil</label>
                <Dropdown
                  value={draft.estado_civil ?? null}
                  options={controles.estado_civil}
                  optionLabel="description"
                  optionValue="code"
                  onChange={(e) => updateDraft('estado_civil', e.value ?? null)}
                  disabled={disabledCamposNatural}
                  className="form-dropdown-presto w-full"
                  loading={loadingControles}
                  placeholder="Seleccione"
                  emptyMessage="Sin resultados"
                  showClear
                />
              </div>
            </>
          )}

          <div className="flex flex-col gap-1" data-field="relacion_titular">
            <label className="font-semibold text-sm">Relación Titular</label>
            <Dropdown
              value={draft.relacion_titular ?? null}
              options={controles.relacion_titular}
              optionLabel="description"
              optionValue="code"
              onChange={(e) => updateDraft('relacion_titular', e.value ?? null)}
              disabled={isDialogReadOnly}
              className="form-dropdown-presto w-full"
              loading={loadingControles}
              placeholder="Seleccione"
              emptyMessage="Sin resultados"
              showClear
            />
          </div>

          <div className="flex flex-col gap-1 md:col-span-2" data-field="direccion">
            <label className="font-semibold text-sm">Dirección{requiereDireccion && <RequiredMark />}</label>
            <InputText
              value={draft.direccion ?? ''}
              onChange={(e) =>
                updateDraft('direccion', sanitizeDireccion(e.target.value))
              }
              maxLength={limitOf('direccion')}
              disabled={isDialogReadOnly}
              className="form-input-presto w-full"
              placeholder="Ingrese dirección"
            />
            <small className="text-xs text-gray-500">{DIRECCION_HINT}</small>
          </div>

          <div className="flex flex-col gap-1" data-field="region">
            <label className="font-semibold text-sm">Región{requiereDireccion && <RequiredMark />}</label>
            <Dropdown
              value={draft.region ?? null}
              options={controles.region}
              optionLabel="description"
              optionValue="code"
              onChange={(e) => updateDraft('region', e.value ?? null)}
              disabled={isDialogReadOnly}
              className="form-dropdown-presto w-full"
              loading={loadingControles}
              placeholder="Seleccione"
              emptyMessage="Sin resultados"
              showClear
              filter
            />
          </div>

          <div className="flex flex-col gap-1" data-field="comuna">
            <label className="font-semibold text-sm">Comuna{requiereDireccion && <RequiredMark />}</label>
            <Dropdown
              value={draft.comuna ?? null}
              options={filteredComunaOptions}
              optionLabel="description"
              optionValue="code"
              onChange={(e) => updateDraft('comuna', e.value ?? null)}
              disabled={isDialogReadOnly}
              className="form-dropdown-presto w-full"
              loading={loadingControles}
              placeholder="Seleccione"
              emptyMessage="Sin resultados"
              showClear
              filter
            />
          </div>

          <div className="flex flex-col gap-1" data-field="telefono">
            <label className="font-semibold text-sm">Teléfono</label>
            {(() => {
              const val = String(draft.telefono ?? '').trim();
              const matchedCode = AREA_CODES_KNOWN.find((c) => val.startsWith(c));
              const regionCode = getAreaCode(draft.region, draft.comuna);
              const code = matchedCode || regionCode;
              const digits = matchedCode
                ? val.slice(matchedCode.length)
                : regionCode
                  ? ''
                  : val;

              return (
                <div className="flex items-center gap-1">
                  {code && <span className="font-bold whitespace-nowrap">({code})</span>}
                  <InputText
                    className="form-input-presto w-full"
                    value={sanitizePhone(digits, telefonoFijoDigitos(code))}
                    disabled={isDialogReadOnly}
                    placeholder={telefonoFijoPlaceholder(code)}
                    maxLength={telefonoFijoDigitos(code)}
                    onChange={(e) =>
                      updateDraft('telefono', (code || '') + sanitizePhone(e.target.value, telefonoFijoDigitos(code)))
                    }
                  />
                </div>
              );
            })()}
          </div>

          <div className="flex flex-col gap-1" data-field="email">
            <label className="font-semibold text-sm">Email</label>
            <InputText
              value={draft.email ?? ''}
              onChange={(e) => updateDraft('email', e.target.value)}
              maxLength={limitOf('email')}
              disabled={isDialogReadOnly}
              className="form-input-presto w-full"
              placeholder={EMAIL_PLACEHOLDER}
            />
          </div>

          {esNatural && (
            <div className="flex flex-col gap-1" data-field="nacionalidad">
              <label className="font-semibold text-sm">Nacionalidad</label>
              <Dropdown
                value={draft.nacionalidad ?? null}
                options={controles.nacionalidad}
                optionLabel="description"
                optionValue="code"
                onChange={(e) => updateDraft('nacionalidad', e.value ?? null)}
                disabled={disabledCamposNatural}
                className="form-dropdown-presto w-full"
                loading={loadingControles}
                placeholder="Seleccione"
                emptyMessage="Sin resultados"
                showClear
                filter
              />
            </div>
          )}

          {esNatural && (
            <div className="flex flex-col gap-1" data-field="profesion">
              <label className="font-semibold text-sm">Profesión</label>
              <InputText
                value={draft.profesion ?? ''}
                onChange={(e) => updateDraft('profesion', e.target.value)}
                maxLength={limitOf('profesion')}
                disabled={disabledCamposNatural}
                className="form-input-presto w-full"
                placeholder="Ingrese profesión"
              />
            </div>
          )}
        </div>
        </div>
      </Dialog>
    </div>
  );
}
