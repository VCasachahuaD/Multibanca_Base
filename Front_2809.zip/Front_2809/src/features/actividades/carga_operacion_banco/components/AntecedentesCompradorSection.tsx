import type { ReactNode } from 'react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { Column } from 'primereact/column';
import { DataTable } from 'primereact/datatable';
import { Dialog } from 'primereact/dialog';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';

import type { ControlesAntecedenteComprador } from '../models/catalogo';
import type { CargaOperacionBancoAntecedenteComprador } from '../models/carga_operacion_banco';
import { limitOf } from '../models/fieldLimits';
import { telefonoFijoDigitos, telefonoFijoPlaceholder } from '@/shared/utils/fieldLimits';
import RequiredMark from '@/shared/components/RequiredMark';
import {
  describeFechaNacimientoError,
  maxFechaNacimiento,
  minFechaNacimiento,
  viewDateNacimiento,
  yearRangeNacimiento,
} from '@/shared/utils/dateCoherence';
import {
  clearFieldErrors,
  focusFieldByKey,
} from '@/features/actividades/datos_operacion/utils/fieldFocus';
import {
  formatRutSinPuntos,
  isValidRutSinPuntos,
  describeRutError,
  rutComparableKey,
} from '@/shared/utils/rut';
import { describeEmailError, EMAIL_PLACEHOLDER, sanitizePhone } from '@/shared/utils/chileanValidators';
import {
  describeDireccionError,
  describeNombrePersonaError,
  describeRazonSocialError,
  DIRECCION_HINT,
  NOMBRE_PERSONA_HINT,
  RAZON_SOCIAL_HINT,
  sanitizeDireccion,
  sanitizeNombrePersona,
  sanitizeRazonSocial,
} from '@/shared/utils/textValidators';

interface AntecedentesCompradorSectionProps {
  value: CargaOperacionBancoAntecedenteComprador[];
  idExpediente: number;
  idCargaOperacionBanco: number;
  disabled: boolean;
  /**
   * Control explícito para habilitar acciones de la grilla.
   * Ver detalle siempre está habilitado.
   * Editar / eliminar / agregar solo se habilitan cuando canEdit = true.
   */
  canEdit?: boolean;
  controles: ControlesAntecedenteComprador;
  loadingControles?: boolean;
  /** RN-C-04: true si se seleccionó una Inmobiliaria (Dirección/Región/Comuna obligatorias). */
  requiereDireccion?: boolean;
  onChange: (value: CargaOperacionBancoAntecedenteComprador[]) => void;
  onWarn?: (message: string) => void;
  /** UX-001: fila guardada que quedó con obligatorios pendientes (viene de la página). */
  rowToFocus?: CargaOperacionBancoAntecedenteComprador | null;
  /** Avisa a la página que `rowToFocus` ya fue procesado. */
  onRowToFocusHandled?: () => void;
}

const renderResponsiveCell = (value: ReactNode, titulo: string) => <div data-titulo={titulo}>{value ?? ""}</div>;

type DialogMode = 'view' | 'edit' | 'create';

const emptyMessage = 'Sin registros';

const now = () => new Date().toISOString();

const emptyComprador = (
  idExpediente: number,
  idCargaOperacionBanco: number,
): CargaOperacionBancoAntecedenteComprador => ({
  id_carga_operacion_banco_antecedente_comprador: 0,
  id_carga_operacion_banco: idCargaOperacionBanco,
  id_expediente: idExpediente,
  rut: '',
  tipo_comprador: null,
  razon_social: '',
  nombres: '',
  apellido_paterno: '',
  apellido_materno: '',
  fecha_nacimiento: null,
  genero: null,
  estado_civil: null,
  relacion_titular: null,
  direccion: '',
  region: null,
  comuna: null,
  telefono: '',
  email: '',
  nacionalidad: null,
  profesion: '',
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: now(),
  modified_by: null,
  modified_date: null,
});

const toDate = (value?: string | null): Date | null => {
  if (!value) return null;

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const toIsoDate = (value: Date | null | undefined): string | null => {
  if (!value) return null;
  return value.toISOString();
};

const getOptionDescription = (
  options: { code?: string | null; description?: string | null }[],
  code?: string | null,
) => options.find((option) => option.code === code)?.description ?? code ?? '';

/**
 * Grupo propio del ConfirmDialog.
 *
 * `confirmDialog()` emite el evento 'confirm-dialog' por el OverlayService y
 * TODAS las instancias de <ConfirmDialog /> montadas lo reciben: sin `group`,
 * el diálogo se mostraría duplicado (uno por cada instancia de la página) y la
 * acción se ejecutaría dos veces. Con `group`, solo responde la instancia que
 * lo declara.
 */
const CONFIRM_GROUP = 'antecedentes-comprador';

/**
 * Compara la fila de la grilla con la que se está editando o eliminando.
 *
 * Se usa identidad en lugar del índice de la grilla porque la grilla muestra
 * únicamente las filas activas (`row_status !== false`): su índice NO coincide
 * con la posición real dentro de `value` cuando hay filas eliminadas
 * lógicamente (borrado lógico con id > 0).
 * - Filas persistidas: se comparan por id.
 * - Filas nuevas (aún sin guardar, id = 0): por referencia.
 */
const esMismoComprador = (
  item: CargaOperacionBancoAntecedenteComprador,
  target: CargaOperacionBancoAntecedenteComprador,
): boolean =>
  target.id_carga_operacion_banco_antecedente_comprador > 0
    ? item.id_carga_operacion_banco_antecedente_comprador ===
      target.id_carga_operacion_banco_antecedente_comprador
    : item === target;

// NA.2: Código de área telefónico según Región/Comuna (patrón de datos_operacion/DatosOperacionPersonaGrid).
const getAreaCode = (
  regionCode: string | null | undefined,
  comunaCode: string | null | undefined,
): string | null => {
  if (!regionCode) return null;
  const r = String(regionCode).trim();
  const c = String(comunaCode ?? '').trim();

  switch (r) {
    case '07': return '2';    // Metropolitana
    case '08': return '72';   // O'Higgins
    case '10': return '42';   // Ñuble
    case '12': return '45';   // Araucanía
    case '13': return '63';   // Los Ríos
    case '15': return '67';   // Aysén
    case '16': return '61';   // Magallanes
    case '06':
      if (c === '06-18' || c === '06-32') return '34';
      if (c === '06-23' || c === '06-26') return '33';
      return null;
    case '09':
      if (c === '09-10' || c === '09-01') return '73';
      if (c === '09-06' || c === '09-26') return '75';
      return null;
    case '11':
      if (c === '11-07') return '41';
      return null;
    case '14':
      if (c === '14-16') return '64';
      if (c === '14-13') return '65';
      return null;
    default: return null;
  }
};

const AREA_CODES_KNOWN = [
  '2', '33', '34', '41', '42', '45', '61', '63', '64', '65', '67', '72', '73', '75',
];

/**
 * Devuelve la llave (data-field) del primer campo obligatorio faltante del
 * comprador en el diálogo, para poder enfocarlo con focusFieldByKey.
 * (RN-C-02: Razón Social si jurídico / Nombres + Apellidos si natural;
 *  UX-004: Fecha de nacimiento si no es coherente, futura, menor de edad o
 *  año imposible;
 *  RN-C-04: Dirección/Región/Comuna si inmobiliaria.)
 */
export const getMissingCompradorFieldKey = (
  draft: CargaOperacionBancoAntecedenteComprador,
  requiereDireccion: boolean,
): string | null => {
  if (!isValidRutSinPuntos(draft.rut)) return 'rut';
  if (!draft.tipo_comprador) return 'tipo_comprador';

  const tipo = draft.tipo_comprador?.toString().toUpperCase();

  if (tipo === 'JURIDICO' || tipo === 'JURÍDICO' || tipo === '02') {
    if (!draft.razon_social?.trim()) return 'razon_social';
    if (describeRazonSocialError(draft.razon_social)) return 'razon_social';
  } else {
    if (!draft.nombres?.trim()) return 'nombres';
    if (describeNombrePersonaError(draft.nombres)) return 'nombres';
    if (!draft.apellido_paterno?.trim()) return 'apellido_paterno';
    if (describeNombrePersonaError(draft.apellido_paterno)) return 'apellido_paterno';
    if (!draft.apellido_materno?.trim()) return 'apellido_materno';
    if (describeNombrePersonaError(draft.apellido_materno)) return 'apellido_materno';
  }

  if (describeFechaNacimientoError(draft.fecha_nacimiento)) return 'fecha_nacimiento';

  if (describeDireccionError(draft.direccion)) return 'direccion';

  if (requiereDireccion) {
    if (!draft.direccion?.trim()) return 'direccion';
    if (!draft.region) return 'region';
    if (!draft.comuna) return 'comuna';
  }

  // UX-007: el email es opcional, pero si se ingresa debe tener formato válido.
  if (describeEmailError(draft.email)) return 'email';

  return null;
};

export default function AntecedentesCompradorSection({
  value,
  idExpediente,
  idCargaOperacionBanco,
  disabled,
  canEdit,
  controles,
  loadingControles = false,
  requiereDireccion = false,
  onChange,
  onWarn,
  rowToFocus = null,
  onRowToFocusHandled,
}: AntecedentesCompradorSectionProps) {
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogMode, setDialogMode] = useState<DialogMode>('view');
  /*
   * Identidad de la fila en edición, NO un índice: la grilla muestra solo las
   * filas activas (row_status !== false), así que un índice de grilla no
   * coincide con la posición real dentro de `value` cuando hay filas eliminadas
   * lógicamente.
   */
  const [editingRow, setEditingRow] =
    useState<CargaOperacionBancoAntecedenteComprador | null>(null);
  const [draft, setDraft] = useState<CargaOperacionBancoAntecedenteComprador>(
    emptyComprador(idExpediente, idCargaOperacionBanco),
  );
  /** UX-001: true cuando el diálogo se abrió desde la validación de la página. */
  const [focusPending, setFocusPending] = useState(false);

  const dialogContentRef = useRef<HTMLDivElement>(null);

  /*
   * Modo de edición de acciones de grilla.
   *
   * IMPORTANTE:
   * La habilitación del lápiz y tacho NO debe depender del render inicial
   * de PrimeReact DataTable. Por eso usamos una variable explícita y luego
   * forzamos el key de la grilla/columna acciones.
   *
   * - Ver detalle siempre habilitado.
   * - Editar / eliminar / agregar solo si el botón general Editar activó canEdit.
   */
  const canModifyRows = typeof canEdit === 'boolean' ? canEdit : !disabled;

  const gridModeKey = canModifyRows ? 'edit' : 'view';

  const isDialogReadOnly = dialogMode === 'view' || !canModifyRows;

  // RN-C-02: campos condicionales según el tipo de comprador (Natural/Jurídico)
  const tipoCompradorActual = draft.tipo_comprador?.toString().toUpperCase();
  const esJuridico =
    tipoCompradorActual === 'JURIDICO' ||
    tipoCompradorActual === 'JURÍDICO' ||
    tipoCompradorActual === '02';
  const esNatural = !!draft.tipo_comprador && !esJuridico;
  const disabledCamposNatural = isDialogReadOnly || !esNatural;
  const disabledRazonSocial = isDialogReadOnly || !esJuridico;

  // NA.1: filtra las comunas según la región seleccionada (formato "{region}-{comuna}")
  const filteredComunaOptions = useMemo(() => {
    const regionCode = String(draft.region ?? '').trim();
    if (!regionCode) return controles.comuna;
    return controles.comuna.filter((c) => {
      const code = String(c.code ?? '');
      return code === regionCode || code.startsWith(regionCode + '-');
    });
  }, [controles.comuna, draft.region]);

  // NA.1: al cambiar la región, limpia la comuna si no le corresponde (solo en el control)
  useEffect(() => {
    if (isDialogReadOnly) return;
    const regionCode = String(draft.region ?? '').trim();
    if (!regionCode) return;
    const comunaVal = String(draft.comuna ?? '').trim();
    if (comunaVal && !comunaVal.startsWith(regionCode + '-') && comunaVal !== regionCode) {
      updateDraft('comuna', null);
    }
  }, [draft.region, isDialogReadOnly]);

  // NA.2: autocompleta el teléfono con el código de área según región/comuna
  useEffect(() => {
    if (isDialogReadOnly) return;
    const areaCode = getAreaCode(draft.region, draft.comuna);
    if (!areaCode) return;
    const current = String(draft.telefono ?? '').trim();
    if (current === areaCode) return;

    let newValue = areaCode;
    if (current) {
      const matchedCode = AREA_CODES_KNOWN.find((code) => current.startsWith(code));
      if (matchedCode) {
        newValue = areaCode + current.slice(matchedCode.length);
      } else if (current.length <= 3) {
        newValue = areaCode;
      } else {
        return;
      }
    }

    if (newValue !== current) {
      updateDraft('telefono', newValue);
    }
  }, [draft.region, draft.comuna, isDialogReadOnly]);

  const rows = useMemo(
    () => (value ?? []).filter((comprador) => comprador.row_status !== false),
    [value],
  );

  const openNew = () => {
    if (!canModifyRows) return;

    setEditingRow(null);
    setDialogMode('create');
    setDraft(emptyComprador(idExpediente, idCargaOperacionBanco));
    setDialogVisible(true);
  };

  const openView = (rowData: CargaOperacionBancoAntecedenteComprador) => {
    setEditingRow(null);
    setDialogMode('view');
    setDraft({
      ...emptyComprador(idExpediente, idCargaOperacionBanco),
      ...rowData,
      id_expediente: rowData.id_expediente || idExpediente,
      id_carga_operacion_banco:
        rowData.id_carga_operacion_banco || idCargaOperacionBanco,
    });
    setDialogVisible(true);
  };

  const openEdit = (rowData: CargaOperacionBancoAntecedenteComprador) => {
    if (!canModifyRows) return;

    setEditingRow(rowData);
    setDialogMode('edit');
    setDraft({
      ...emptyComprador(idExpediente, idCargaOperacionBanco),
      ...rowData,
      id_expediente: rowData.id_expediente || idExpediente,
      id_carga_operacion_banco:
        rowData.id_carga_operacion_banco || idCargaOperacionBanco,
    });
    setDialogVisible(true);
  };

  /**
   * UX-001 (navegación al input): cuando la página detecta que una fila guardada
   * quedó con obligatorios pendientes, abre el diálogo de ESA fila en modo
   * edición y enfoca el primer campo faltante.
   */
  useEffect(() => {
    if (!rowToFocus || !canModifyRows) return;

    setFocusPending(true);
    openEdit(rowToFocus);
    onRowToFocusHandled?.();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rowToFocus, canModifyRows]);

  useEffect(() => {
    if (!focusPending) return;

    setFocusPending(false);
    clearFieldErrors();
    /*
     * 450 ms: hay que esperar a que el diálogo TERMINE su animación de entrada.
     * El Calendar de PrimeReact abre su panel al recibir el foco; si el foco
     * llega a mitad de la animación, el panel queda en un estado inconsistente
     * (se ve pero no responde hasta que se vuelve a hacer clic en el campo).
     */
    focusFieldByKey(
      getMissingCompradorFieldKey(draft, requiereDireccion),
      dialogContentRef.current,
      450,
    );
  }, [focusPending, draft, requiereDireccion]);

  const updateDraft = <K extends keyof CargaOperacionBancoAntecedenteComprador>(
    field: K,
    fieldValue: CargaOperacionBancoAntecedenteComprador[K],
  ) => {
    if (isDialogReadOnly) return;

    setDraft((prev) => ({
      ...prev,
      [field]: fieldValue,
    }));
  };

  // RN-C-02: al cambiar el tipo se CONSERVAN los valores ya ingresados en el
  // draft (así se restauran si el usuario vuelve al tipo anterior). Los campos
  // que no aplican al tipo se excluyen del payload al Guardar/Avanzar.
  const handleTipoCompradorChange = (value: string | null) => {
    if (isDialogReadOnly) return;

    setDraft((prev) => ({
      ...prev,
      tipo_comprador: value,
    }));
  };

  /**
   * Busca OTRA fila activa con el mismo RUT (comparado sin puntos ni guiones).
   * Excluye la fila que se está editando. Evita registrar dos veces al mismo
   * comprador, que hoy es posible porque ni el backend ni la BD lo impiden.
   */
  const buscarRutDuplicado = () =>
    (value ?? []).find(
      (item) =>
        item.row_status !== false &&
        (!editingRow || !esMismoComprador(item, editingRow)) &&
        rutComparableKey(item.rut) !== '' &&
        rutComparableKey(item.rut) === rutComparableKey(draft.rut),
    );

  const validateDraft = () => {
    if (!draft.rut?.trim()) return 'Debe ingresar RUT del comprador.';
    const rutError = describeRutError(draft.rut);
    if (rutError) return `RUT del comprador. ${rutError}`;
    if (buscarRutDuplicado()) {
      return `Ya existe un comprador registrado con el RUT ${draft.rut}.`;
    }
    if (!draft.tipo_comprador) return 'Debe seleccionar Tipo de Comprador.';

    const tipo = draft.tipo_comprador?.toString().toUpperCase();

    if (tipo === 'JURIDICO' || tipo === 'JURÍDICO' || tipo === '02') {
      if (!draft.razon_social?.trim()) {
        return 'Debe ingresar Razón Social del comprador jurídico.';
      }
      const razonSocialError = describeRazonSocialError(
        draft.razon_social,
        'Razón Social del comprador. ',
      );
      if (razonSocialError) return razonSocialError;
    } else {
      if (!draft.nombres?.trim()) return 'Debe ingresar Nombres del comprador.';
      const nombresError = describeNombrePersonaError(
        draft.nombres,
        'Nombres del comprador. ',
      );
      if (nombresError) return nombresError;

      if (!draft.apellido_paterno?.trim()) {
        return 'Debe ingresar Apellido Paterno del comprador.';
      }
      const apellidoPaternoError = describeNombrePersonaError(
        draft.apellido_paterno,
        'Apellido Paterno del comprador. ',
      );
      if (apellidoPaternoError) return apellidoPaternoError;

      if (!draft.apellido_materno?.trim()) {
        return 'Debe ingresar Apellido Materno del comprador.';
      }
      const apellidoMaternoError = describeNombrePersonaError(
        draft.apellido_materno,
        'Apellido Materno del comprador. ',
      );
      if (apellidoMaternoError) return apellidoMaternoError;
    }

    const direccionError = describeDireccionError(
      draft.direccion,
      'Dirección del comprador. ',
    );
    if (direccionError) return direccionError;

    const fechaNacimientoError = describeFechaNacimientoError(draft.fecha_nacimiento);
    if (fechaNacimientoError) {
      return `Fecha de nacimiento del comprador. ${fechaNacimientoError}`;
    }

    if (requiereDireccion) {
      if (!draft.direccion?.trim()) {
        return 'Debe ingresar Dirección del comprador.';
      }
      if (!draft.region) {
        return 'Debe seleccionar Región del comprador.';
      }
      if (!draft.comuna) {
        return 'Debe seleccionar Comuna del comprador.';
      }
    }

    const emailError = describeEmailError(draft.email);
    if (emailError) {
      return `Email del comprador. ${emailError}`;
    }

    return '';
  };

  const saveDraft = () => {
    if (isDialogReadOnly) return;

    const validationMessage = validateDraft();

    if (validationMessage) {
      onWarn?.(validationMessage);
      clearFieldErrors();
      focusFieldByKey(
        buscarRutDuplicado()
          ? 'rut'
          : getMissingCompradorFieldKey(draft, requiereDireccion),
        dialogContentRef.current,
        80,
      );
      return;
    }

    const normalizedDraft: CargaOperacionBancoAntecedenteComprador = {
      ...draft,
      id_expediente: idExpediente || draft.id_expediente,
      id_carga_operacion_banco:
        idCargaOperacionBanco || draft.id_carga_operacion_banco,
      is_active: draft.is_active ?? true,
      row_status: draft.row_status ?? true,
      created_date: draft.created_date ?? now(),
    };

    if (dialogMode === 'create') {
      onChange([...(value ?? []), normalizedDraft]);
    } else if (editingRow) {
      onChange(
        (value ?? []).map((item) =>
          esMismoComprador(item, editingRow) ? normalizedDraft : item,
        ),
      );
    }

    setDialogVisible(false);
  };

  const executeRemoveRow = (rowData: CargaOperacionBancoAntecedenteComprador) => {
    // Fila persistida: borrado lógico (permanece en el array con row_status=false).
    if (rowData.id_carga_operacion_banco_antecedente_comprador > 0) {
      onChange(
        (value ?? []).map((item) =>
          esMismoComprador(item, rowData)
            ? {
                ...item,
                row_status: false,
                is_active: false,
              }
            : item,
        ),
      );
      return;
    }

    // Fila nueva (aún sin guardar): se quita del state.
    onChange((value ?? []).filter((item) => !esMismoComprador(item, rowData)));
  };

  const confirmRemoveRow = (rowData: CargaOperacionBancoAntecedenteComprador) => {
    if (!canModifyRows) return;

    const compradorLabel =
      nombreCompradorBodyTemplate(rowData) || rowData.rut || 'este registro';

    confirmDialog({
      group: CONFIRM_GROUP,
      header: 'Confirmar eliminación',
      message: `¿Está seguro de querer eliminar ${compradorLabel}?`,
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: 'Sí, eliminar',
      rejectLabel: 'Cancelar',
      acceptClassName: 'p-button-danger',
      accept: () => executeRemoveRow(rowData),
    });
  };

  const actionBodyTemplate = (
    rowData: CargaOperacionBancoAntecedenteComprador,
  ) => (
    <div className="flex gap-2 justify-center">
      <Button
        type="button"
        icon="pi pi-eye"
        severity="secondary"
        outlined
        size="small"
        onClick={() => openView(rowData)}
        tooltip="Ver detalle"
      />
      <Button
        key={`editar-${gridModeKey}`}
        type="button"
        icon="pi pi-pencil"
        severity="info"
        outlined
        size="small"
        disabled={canModifyRows ? false : true}
        onClick={() => openEdit(rowData)}
        tooltip="Editar"
      />
      <Button
        key={`eliminar-${gridModeKey}`}
        type="button"
        icon="pi pi-trash"
        severity="danger"
        outlined
        size="small"
        disabled={canModifyRows ? false : true}
        onClick={() => confirmRemoveRow(rowData)}
        tooltip="Eliminar"
      />
    </div>
  );

  const tipoCompradorBodyTemplate = (
    rowData: CargaOperacionBancoAntecedenteComprador,
  ) => getOptionDescription(controles.tipo_comprador, rowData.tipo_comprador);

  const nombreCompradorBodyTemplate = (
    rowData: CargaOperacionBancoAntecedenteComprador,
  ) => {
    if (rowData.razon_social?.trim()) return rowData.razon_social;

    return [rowData.nombres, rowData.apellido_paterno, rowData.apellido_materno]
      .filter(Boolean)
      .join(' ');
  };

  const getDialogTitle = () => {
    if (dialogMode === 'view') return 'Detalle del Comprador';
    if (dialogMode === 'edit') return 'Editar Comprador';
    return 'Agregar Comprador';
  };

  const dialogFooter =
    dialogMode === 'view' ? (
      <div className="flex justify-end gap-2">
        <Button
          type="button"
          label="Cerrar"
          icon="pi pi-times"
          severity="secondary"
          outlined
          onClick={() => setDialogVisible(false)}
        />
      </div>
    ) : (
      <div className="flex justify-end gap-2">
        <Button
          type="button"
          label="Cancelar"
          icon="pi pi-times"
          severity="secondary"
          outlined
          onClick={() => setDialogVisible(false)}
        />
        <Button
          type="button"
          label="Aceptar"
          icon="pi pi-check"
          severity="success"
          onClick={saveDraft}
          disabled={!canModifyRows}
        />
      </div>
    );

  return (
    <div
      className="flex flex-col gap-4 section-error"
      data-field="antecedentes-comprador"
    >
      <ConfirmDialog group={CONFIRM_GROUP} />
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">
            Sección: Antecedentes del Comprador
          </h3>
          <p className="text-sm text-gray-500">
            Agregue uno o más compradores asociados a la operación.
          </p>
        </div>

        <Button
          type="button"
          label="Agregar Comprador"
          icon="pi pi-plus"
          severity="success"
          outlined
          onClick={openNew}
          disabled={!canModifyRows}
          className="btn-responsive"
        />
      </div>

      <DataTable
        key={`antecedentes-comprador-grid-${gridModeKey}`}
        value={rows}
        emptyMessage={emptyMessage}
        paginator={rows.length > 5}
        rows={5}
        stripedRows
          size="small"
        className="text-sm datatable-presto"
      >
        <Column field="rut" header="RUT" body={(r) => renderResponsiveCell(r.rut, "RUT: ")} />
        <Column
          field="tipo_comprador"
          header="Tipo"
          body={(r) => renderResponsiveCell(tipoCompradorBodyTemplate(r), "Tipo: ")}
        />
        <Column header="Comprador" body={(r) => renderResponsiveCell(nombreCompradorBodyTemplate(r), "Comprador: ")} />
        <Column field="telefono" header="Teléfono" body={(r) => renderResponsiveCell(r.telefono, "Teléfono: ")} />
        <Column field="email" header="Email" body={(r) => renderResponsiveCell(r.email, "Email: ")} />
        <Column
          key={`acciones-${gridModeKey}`}
          header="Acciones"
          body={(r) => renderResponsiveCell(actionBodyTemplate(r), "Acciones: ")}
          style={{ width: '170px' }}
        />
      </DataTable>

      <Dialog
        header={getDialogTitle()}
        visible={dialogVisible}
        onHide={() => setDialogVisible(false)}
        footer={dialogFooter}
        modal
        className="w-full md:w-10/12 lg:w-8/12"
      >
        <div ref={dialogContentRef}>
        <p className="mb-4 text-sm text-gray-600">
          Los campos marcados con <RequiredMark /> son obligatorios.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="flex flex-col gap-1" data-field="rut">
            <label className="font-semibold text-sm">RUT<RequiredMark /></label>
            <InputText
              value={draft.rut ?? ''}
              onChange={(e) => updateDraft('rut', formatRutSinPuntos(e.target.value))}
              disabled={isDialogReadOnly}
              className="form-input-presto w-full"
              placeholder="12345678-9"
              maxLength={limitOf('rut')}
            />
          </div>

          <div className="flex flex-col gap-1" data-field="tipo_comprador">
            <label className="font-semibold text-sm">Tipo Comprador<RequiredMark /></label>
            <Dropdown
              value={draft.tipo_comprador ?? null}
              options={controles.tipo_comprador}
              optionLabel="description"
              optionValue="code"
              onChange={(e) => handleTipoCompradorChange(e.value ?? null)}
              disabled={isDialogReadOnly}
              className="form-dropdown-presto w-full"
              loading={loadingControles}
              placeholder="Seleccione"
              emptyMessage="Sin resultados"
              showClear
            />
          </div>

          {esJuridico && (
            <div className="flex flex-col gap-1" data-field="razon_social">
              <label className="font-semibold text-sm">Razón Social{esJuridico && <RequiredMark />}</label>
              <InputText
                value={draft.razon_social ?? ''}
                onChange={(e) =>
                  updateDraft('razon_social', sanitizeRazonSocial(e.target.value))
                }
                maxLength={limitOf('razon_social')}
                disabled={disabledRazonSocial}
                className="form-input-presto w-full"
                placeholder="Ingrese razón social"
              />
              <small className="text-xs text-gray-500">{RAZON_SOCIAL_HINT}</small>
            </div>
          )}

          {esNatural && (
            <>
              <div className="flex flex-col gap-1" data-field="nombres">
                <label className="font-semibold text-sm">Nombres{esNatural && <RequiredMark />}</label>
                <InputText
                  value={draft.nombres ?? ''}
                  onChange={(e) =>
                    updateDraft('nombres', sanitizeNombrePersona(e.target.value))
                  }
                  maxLength={limitOf('nombres')}
                  disabled={disabledCamposNatural}
                  className="form-input-presto w-full"
                  placeholder="Ingrese nombres"
                />
                <small className="text-xs text-gray-500">{NOMBRE_PERSONA_HINT}</small>
              </div>

              <div className="flex flex-col gap-1" data-field="apellido_paterno">
                <label className="font-semibold text-sm">Apellido Paterno{esNatural && <RequiredMark />}</label>
                <InputText
                  value={draft.apellido_paterno ?? ''}
                  onChange={(e) =>
                    updateDraft('apellido_paterno', sanitizeNombrePersona(e.target.value))
                  }
                  maxLength={limitOf('apellido_paterno')}
                  disabled={disabledCamposNatural}
                  className="form-input-presto w-full"
                  placeholder="Ingrese apellido paterno"
                />
                <small className="text-xs text-gray-500">{NOMBRE_PERSONA_HINT}</small>
              </div>

              <div className="flex flex-col gap-1" data-field="apellido_materno">
                <label className="font-semibold text-sm">Apellido Materno{esNatural && <RequiredMark />}</label>
                <InputText
                  value={draft.apellido_materno ?? ''}
                  onChange={(e) =>
                    updateDraft('apellido_materno', sanitizeNombrePersona(e.target.value))
                  }
                  maxLength={limitOf('apellido_materno')}
                  disabled={disabledCamposNatural}
                  className="form-input-presto w-full"
                  placeholder="Ingrese apellido materno"
                />
                <small className="text-xs text-gray-500">{NOMBRE_PERSONA_HINT}</small>
              </div>

              <div className="flex flex-col gap-1" data-field="fecha_nacimiento">
                <label className="font-semibold text-sm">Fecha Nacimiento</label>
                <Calendar
                  value={toDate(draft.fecha_nacimiento)}
                  onChange={(e) =>
                    updateDraft('fecha_nacimiento', toIsoDate(e.value as Date | null))
                  }
                  disabled={disabledCamposNatural}
                  className="calendar-presto"
                  dateFormat="dd/mm/yy"
                  minDate={minFechaNacimiento()}
                  maxDate={maxFechaNacimiento()}
                  yearRange={yearRangeNacimiento()}
                  viewDate={viewDateNacimiento(draft.fecha_nacimiento)}
                  showIcon
                  placeholder="Seleccione fecha"
                />
              </div>

              <div className="flex flex-col gap-1" data-field="genero">
                <label className="font-semibold text-sm">Género</label>
                <Dropdown
                  value={draft.genero ?? null}
                  options={controles.genero}
                  optionLabel="description"
                  optionValue="code"
                  onChange={(e) => updateDraft('genero', e.value ?? null)}
                  disabled={disabledCamposNatural}
                  className="form-dropdown-presto w-full"
                  loading={loadingControles}
                  placeholder="Seleccione"
                  emptyMessage="Sin resultados"
                  showClear
                />
              </div>

              <div className="flex flex-col gap-1" data-field="estado_civil">
                <label className="font-semibold text-sm">Estado Civil</label>
                <Dropdown
                  value={draft.estado_civil ?? null}
                  options={controles.estado_civil}
                  optionLabel="description"
                  optionValue="code"
                  onChange={(e) => updateDraft('estado_civil', e.value ?? null)}
                  disabled={disabledCamposNatural}
                  className="form-dropdown-presto w-full"
                  loading={loadingControles}
                  placeholder="Seleccione"
                  emptyMessage="Sin resultados"
                  showClear
                />
              </div>
            </>
          )}

          <div className="flex flex-col gap-1" data-field="relacion_titular">
            <label className="font-semibold text-sm">Relación Titular</label>
            <Dropdown
              value={draft.relacion_titular ?? null}
              options={controles.relacion_titular}
              optionLabel="description"
              optionValue="code"
              onChange={(e) => updateDraft('relacion_titular', e.value ?? null)}
              disabled={isDialogReadOnly}
              className="form-dropdown-presto w-full"
              loading={loadingControles}
              placeholder="Seleccione"
              emptyMessage="Sin resultados"
              showClear
            />
          </div>

          <div className="flex flex-col gap-1 md:col-span-2" data-field="direccion">
            <label className="font-semibold text-sm">Dirección{requiereDireccion && <RequiredMark />}</label>
            <InputText
              value={draft.direccion ?? ''}
              onChange={(e) =>
                updateDraft('direccion', sanitizeDireccion(e.target.value))
              }
              maxLength={limitOf('direccion')}
              disabled={isDialogReadOnly}
              className="form-input-presto w-full"
              placeholder="Ingrese dirección"
            />
            <small className="text-xs text-gray-500">{DIRECCION_HINT}</small>
          </div>

          <div className="flex flex-col gap-1" data-field="region">
            <label className="font-semibold text-sm">Región{requiereDireccion && <RequiredMark />}</label>
            <Dropdown
              value={draft.region ?? null}
              options={controles.region}
              optionLabel="description"
              optionValue="code"
              onChange={(e) => updateDraft('region', e.value ?? null)}
              disabled={isDialogReadOnly}
              className="form-dropdown-presto w-full"
              loading={loadingControles}
              placeholder="Seleccione"
              emptyMessage="Sin resultados"
              showClear
              filter
            />
          </div>

          <div className="flex flex-col gap-1" data-field="comuna">
            <label className="font-semibold text-sm">Comuna{requiereDireccion && <RequiredMark />}</label>
            <Dropdown
              value={draft.comuna ?? null}
              options={filteredComunaOptions}
              optionLabel="description"
              optionValue="code"
              onChange={(e) => updateDraft('comuna', e.value ?? null)}
              disabled={isDialogReadOnly}
              className="form-dropdown-presto w-full"
              loading={loadingControles}
              placeholder="Seleccione"
              emptyMessage="Sin resultados"
              showClear
              filter
            />
          </div>

          <div className="flex flex-col gap-1" data-field="telefono">
            <label className="font-semibold text-sm">Teléfono</label>
            {(() => {
              const val = String(draft.telefono ?? '').trim();
              const matchedCode = AREA_CODES_KNOWN.find((c) => val.startsWith(c));
              const regionCode = getAreaCode(draft.region, draft.comuna);
              const code = matchedCode || regionCode;
              const digits = matchedCode
                ? val.slice(matchedCode.length)
                : regionCode
                  ? ''
                  : val;

              return (
                <div className="flex items-center gap-1">
                  {code && <span className="font-bold whitespace-nowrap">({code})</span>}
                  <InputText
                    className="form-input-presto w-full"
                    value={sanitizePhone(digits, telefonoFijoDigitos(code))}
                    disabled={isDialogReadOnly}
                    placeholder={telefonoFijoPlaceholder(code)}
                    maxLength={telefonoFijoDigitos(code)}
                    onChange={(e) =>
                      updateDraft('telefono', (code || '') + sanitizePhone(e.target.value, telefonoFijoDigitos(code)))
                    }
                  />
                </div>
              );
            })()}
          </div>

          <div className="flex flex-col gap-1" data-field="email">
            <label className="font-semibold text-sm">Email</label>
            <InputText
              value={draft.email ?? ''}
              onChange={(e) => updateDraft('email', e.target.value)}
              maxLength={limitOf('email')}
              disabled={isDialogReadOnly}
              className="form-input-presto w-full"
              placeholder={EMAIL_PLACEHOLDER}
            />
          </div>

          {esNatural && (
            <div className="flex flex-col gap-1" data-field="nacionalidad">
              <label className="font-semibold text-sm">Nacionalidad</label>
              <Dropdown
                value={draft.nacionalidad ?? null}
                options={controles.nacionalidad}
                optionLabel="description"
                optionValue="code"
                onChange={(e) => updateDraft('nacionalidad', e.value ?? null)}
                disabled={disabledCamposNatural}
                className="form-dropdown-presto w-full"
                loading={loadingControles}
                placeholder="Seleccione"
                emptyMessage="Sin resultados"
                showClear
                filter
              />
            </div>
          )}

          {esNatural && (
            <div className="flex flex-col gap-1" data-field="profesion">
              <label className="font-semibold text-sm">Profesión</label>
              <InputText
                value={draft.profesion ?? ''}
                onChange={(e) => updateDraft('profesion', e.target.value)}
                maxLength={limitOf('profesion')}
                disabled={disabledCamposNatural}
                className="form-input-presto w-full"
                placeholder="Ingrese profesión"
              />
            </div>
          )}
        </div>
        </div>
      </Dialog>
    </div>
  );
}
