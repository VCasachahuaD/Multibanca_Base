import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Accordion, AccordionTab } from "primereact/accordion";
import { Button } from "primereact/button";
import { Calendar } from "primereact/calendar";
import { Card } from "primereact/card";
import { InputText } from "primereact/inputtext";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";

import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";

import type { RectificatoriaLegalFirmaAlzante } from "../models/rectificatoria_legal_firma_alzante";
import { useRectificatoriaLegalFirmaAlzante } from "../hooks/useRectificatoriaLegalFirmaAlzante";
import { useUpsertRectificatoriaLegalFirmaAlzante } from "../hooks/useUpsertRectificatoriaLegalFirmaAlzante";
import { useAvanzarRectificatoriaLegalFirmaAlzante } from "../hooks/useAvanzarRectificatoriaLegalFirmaAlzante";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const ACTIVITY_ID = "_Wk8S_P2aJeaRs3_B2zR1g";

const build_initial_state = (id_expediente: number): RectificatoriaLegalFirmaAlzante => ({
  id_rectificatoria_legal_firma_alzante: 0,
  id_expediente,
  id_usuario_solicitante: 0,
  fecha_firma_alzante: null,
  observaciones: null,
  nombre_banco_alzante: null,
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: new Date().toISOString(),
  modified_by: null,
  modified_date: null,
});

const normalize = (
  source: Partial<RectificatoriaLegalFirmaAlzante> | null | undefined,
  id_expediente_fallback: number,
): RectificatoriaLegalFirmaAlzante => ({
  id_rectificatoria_legal_firma_alzante: Number(source?.id_rectificatoria_legal_firma_alzante ?? 0),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback),
  id_usuario_solicitante: Number(source?.id_usuario_solicitante ?? 0),
  fecha_firma_alzante: source?.fecha_firma_alzante ?? null,
  observaciones: source?.observaciones ?? null,
  nombre_banco_alzante: source?.nombre_banco_alzante ?? null,
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? new Date().toISOString(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

export default function RectificatoriaLegalFirmaAlzantePage() {
  const toast = useRef<Toast>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: id_param } = useParams();
  const { fromTracking = false } = location.state || {};
  const id_expediente = Number(id_param ?? 0);
  const has_valid_expediente = id_expediente > 0;

  const [form, set_form] = useState<RectificatoriaLegalFirmaAlzante>(build_initial_state(id_expediente));
  const [is_disabled, set_is_disabled] = useState(true);
  const [can_advance, set_can_advance] = useState(false);
  const [is_busy, set_is_busy] = useState(false);

  const has_hydrated = useRef(false);
  const current_expediente = useRef(id_expediente);

  const { data, isLoading } = useRectificatoriaLegalFirmaAlzante(id_expediente);
  const save_mutation = useUpsertRectificatoriaLegalFirmaAlzante();
  const avanzar_mutation = useAvanzarRectificatoriaLegalFirmaAlzante();

  useEffect(() => {
    if (current_expediente.current !== id_expediente) {
      current_expediente.current = id_expediente;
      has_hydrated.current = false;
      set_form(build_initial_state(id_expediente));
      set_is_disabled(true);
      set_can_advance(false);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (has_hydrated.current) return;

    if (!has_valid_expediente) {
      set_form(build_initial_state(0));
      set_is_disabled(false);
      set_can_advance(false);
      has_hydrated.current = true;
      return;
    }

    if (data?.status && data.detail) {
      const loaded = normalize(data.detail, id_expediente);
      set_form(loaded);
      set_is_disabled(true);
      set_can_advance(false);
      has_hydrated.current = true;
    }
  }, [data, id_expediente, has_valid_expediente]);

  const handle_editar = () => {
    set_is_disabled(false);
    set_can_advance(false);
  };

  const validate_form = (): string => {
    if (!form.fecha_firma_alzante) {
      return "La fecha de firma del alzante es obligatoria.";
    }
    if (!form.observaciones || !form.observaciones.trim()) {
      return "Las observaciones son obligatorias.";
    }
    return "";
  };

  const handle_guardar = async () => {
    const validation_msg = validate_form();
    if (validation_msg) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: validation_msg,
        life: 3000,
      });
      return;
    }

    set_is_busy(true);
    try {
      const payload = normalize({ ...form, id_expediente }, id_expediente);
      const response = await save_mutation.mutateAsync(payload);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Información guardada correctamente",
          life: 3000,
        });
        const saved = normalize(
          { ...(response.detail ?? payload), nombre_banco_alzante: payload.nombre_banco_alzante },
          payload.id_expediente,
        );
        set_form(saved);
        set_is_disabled(true);
        set_can_advance(!!saved.fecha_firma_alzante);
        has_hydrated.current = true;
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: response.message || "No se pudo guardar",
          life: 3000,
        });
      }
    } catch (error) {
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Ocurrió un error al guardar",
        life: 3000,
      });
    } finally {
      set_is_busy(false);
    }
  };

  const handle_avanzar = async () => {
    if (!has_valid_expediente) {
      const msg = "No existe un id_expediente válido para avanzar.";
      toast.current?.show({ severity: "warn", summary: "Validación", detail: msg, life: 3000 });
      return;
    }

    set_is_busy(true);
    try {
      const response = await avanzar_mutation.mutateAsync(id_expediente);
      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Actividad avanzada correctamente",
          life: 2000,
        });
        navigate("/home/bandeja");
      } else {
        const msg = response.message || "No se pudo avanzar la actividad.";
        toast.current?.show({ severity: "warn", summary: "Atención", detail: msg, life: 3000 });
      }
    } catch (error) {
      const msg = "Ocurrió un error al avanzar.";
      toast.current?.show({ severity: "error", summary: "Error", detail: msg, life: 3000 });
    } finally {
      set_is_busy(false);
    }
  };

  const handle_salir = () => navigate("/home/bandeja");

  const fecha_as_date = form.fecha_firma_alzante ? new Date(form.fecha_firma_alzante) : null;

  return (
    <>
      <Toast ref={toast} />

      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Rectificatoria Legal - Firma Alzante
      </h2>

      <Accordion multiple activeIndex={[2]}>
        <AccordionTab header="Información del Expediente" disabled={!has_valid_expediente}>
          <EncabezadoActividad idExpediente={id_expediente} activityID={ACTIVITY_ID} />
        </AccordionTab>

        <AccordionTab header="Funciones Transversales" disabled={!has_valid_expediente}>
          <FuncionesTransversales idExpediente={id_expediente} idActividad={ACTIVITY_ID} />
        </AccordionTab>

        <AccordionTab header="Rectificatoria Legal - Firma Alzante">
          <Card className="w-full shadow-md card-presto-form mb-6">
            {isLoading && has_valid_expediente && (
              <div className="mb-4 text-sm text-blue-600">Cargando información...</div>
            )}

            <div className="flex flex-col gap-6">
              <div className="reparo-table-container">
                <table className="reparo-table">
                  <thead>
                    <tr className="bg-[#03298e] text-white">
                      <th className="border border-gray-300 px-3 py-2 text-center font-semibold">
                        Nombre Banco Alzante *
                      </th>
                      <th className="border border-gray-300 px-3 py-2 text-center font-semibold">
                        Fecha Firma Alzante *
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 px-3 py-2 align-middle">
                        <InputText
                          value={form.nombre_banco_alzante ?? ""}
                          readOnly
                          disabled
                          className="form-input-presto w-full"
                        />
                      </td>
                      <td className="border border-gray-300 px-3 py-2 align-middle">
                        <Calendar
                          value={fecha_as_date}
                          onChange={(e) => {
                            const val = e.value as Date | null;
                            set_form((prev) => ({
                              ...prev,
                              fecha_firma_alzante: val ? val.toISOString() : null,
                            }));
                          }}
                          dateFormat="dd/mm/yy"
                          showIcon
                          disabled={is_disabled}
                          className="calendar-presto"
                        />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="flex flex-col gap-1">
  <label className="font-semibold text-sm">Observaciones *</label>
  <InputTextarea
    value={form.observaciones ?? ""}
    onChange={(e) =>
      set_form((prev) => ({ ...prev, observaciones: e.target.value }))
    }
    rows={4}
    maxLength={1000}
    className="form-textarea-presto w-full"
    disabled={is_disabled}
    placeholder="Ingrese observaciones (máximo 1000 caracteres)"
    style={{ resize: "none" }}
  />
  <div className="flex justify-end mt-1 text-xs">
    <span className={
      (form.observaciones?.length ?? 0) >= 1000 
        ? "text-red-600" 
        : (form.observaciones?.length ?? 0) >= 900 
          ? "text-orange-500" 
          : "text-gray-500"
    }>
      {form.observaciones?.length ?? 0}
    </span>
    <span className="mx-1 text-gray-500">/</span>
    <span className="text-gray-500">1000</span>
  </div>
</div>
            </div>

            <ActivityActionBar
              from_tracking={fromTracking}
              is_busy={is_busy}
              is_disabled={is_disabled}
              can_advance={can_advance}
              is_saving={save_mutation.isPending}
              is_advancing={avanzar_mutation.isPending}
              on_edit={handle_editar}
              on_save={handle_guardar}
              on_advance={handle_avanzar}
              on_exit={handle_salir}
            />
          </Card>
        </AccordionTab>
      </Accordion>
    </>
  );
}