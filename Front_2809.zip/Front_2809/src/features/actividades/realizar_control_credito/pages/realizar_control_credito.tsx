import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Card } from "primereact/card";
import { Button } from "primereact/button";
import { Checkbox, CheckboxChangeEvent } from "primereact/checkbox";
import { Accordion, AccordionTab } from "primereact/accordion";
import { Toast } from "primereact/toast";

import type { RealizarControlCredito } from "../models/realizar_control_credito";
import { useRealizarControlCredito } from "../hooks/useRealizarControlCredito";
import { useUpsertRealizarControlCredito } from "../hooks/useUpsertRealizarControlCredito";
import { useAvanzarRealizarControlCredito } from "../hooks/useAvanzarRealizarControlCredito";
import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const ACTIVITY_ID = "_Cy5N_R7pUebKd9_G3mL8t";

const buildInitialState = (id_expediente: number): RealizarControlCredito => ({
  id_realizar_control_credito: 0,
  id_expediente,
  id_usuario_solicitante: 0,
  enviar_reparo: false,
  observaciones: "",
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: new Date().toISOString(),
  modified_by: null,
  modified_date: null,
});

const normalizeRealizarControlCredito = (
  source: Partial<RealizarControlCredito> | null | undefined,
  id_expediente_fallback: number,
): RealizarControlCredito => {
  return {
    id_realizar_control_credito: Number(source?.id_realizar_control_credito ?? 0),
    id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    id_usuario_solicitante: Number(source?.id_usuario_solicitante ?? 0),
    enviar_reparo: Boolean(source?.enviar_reparo ?? false),
    observaciones: source?.observaciones ?? "",
    is_active: source?.is_active ?? true,
    row_status: source?.row_status ?? true,
    created_by: Number(source?.created_by ?? 0),
    created_date: source?.created_date ?? new Date().toISOString(),
    modified_by: source?.modified_by ?? null,
    modified_date: source?.modified_date ?? null,
  };
};

export default function RealizarControlCreditoPage() {
  const toast = useRef<Toast>(null);

  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: idExpedienteParam } = useParams();
  const { fromTracking = false } = location.state || {};

  const id_expediente = Number(idExpedienteParam ?? 0);

  const [form, setForm] = useState<RealizarControlCredito>(
    buildInitialState(id_expediente),
  );
  const [isDisabled, setIsDisabled] = useState(true);
  const [canAdvance, setCanAdvance] = useState(false);
  const [isBusy, setIsBusy] = useState(false);

  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef<number>(id_expediente);

  const { data, isLoading } = useRealizarControlCredito(id_expediente);
  const saveMutation = useUpsertRealizarControlCredito();
  const avanzarMutation = useAvanzarRealizarControlCredito();

  useEffect(() => {
    if (currentExpedienteRef.current !== id_expediente) {
      currentExpedienteRef.current = id_expediente;
      hasHydratedRef.current = false;

      setForm(buildInitialState(id_expediente));
      setIsDisabled(true);
      setCanAdvance(false);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (data?.status && data.detail) {
      const loadedEntity = normalizeRealizarControlCredito(
        data.detail,
        id_expediente,
      );

      setForm(loadedEntity);
      setIsDisabled(true);
      setCanAdvance(false);

      hasHydratedRef.current = true;
      return;
    }

    if (!id_expediente || id_expediente <= 0) {
      setForm(buildInitialState(0));
      setIsDisabled(false);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (data) {
      setForm((prev) =>
        normalizeRealizarControlCredito(
          {
            ...prev,
            id_expediente,
          },
          id_expediente,
        ),
      );
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
    }
  }, [data, id_expediente]);

  const updateField = <K extends keyof RealizarControlCredito>(
    field: K,
    value: RealizarControlCredito[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleEditar = () => {
    setIsDisabled(false);
    setCanAdvance(false);
  };

  const validateForm = () => {
    if (form.id_expediente <= 0) {
      return "No existe un id_expediente válido.";
    }

    if (form.enviar_reparo && !form.observaciones?.trim()) {
      return "Debe ingresar observaciones cuando se envía a reparo.";
    }

    return "";
  };

  const handleGuardar = async () => {
    const validationMessage = validateForm();
    if (validationMessage) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: validationMessage,
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);

      const payload: RealizarControlCredito = normalizeRealizarControlCredito(
        {
          ...form,
          id_realizar_control_credito: Number(
            form.id_realizar_control_credito ?? 0,
          ),
          id_expediente: Number(form.id_expediente || id_expediente || 0),
        },
        id_expediente,
      );

      const response = await saveMutation.mutateAsync(payload);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Control de crédito guardado correctamente",
          life: 3000,
        });

        const savedEntity = normalizeRealizarControlCredito(
          response.detail ?? payload,
          payload.id_expediente,
        );

        setForm(savedEntity);
        setIsDisabled(true);
        setCanAdvance(true);
        hasHydratedRef.current = true;
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: response.message || "No se pudo guardar",
          life: 3000,
        });
      }
    } catch (error) {
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Ocurrió un error al guardar",
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleAvanzar = async () => {
    const expedienteId = Number(form.id_expediente ?? 0);

    if (!expedienteId || expedienteId <= 0) {
      const msg = "No existe un id_expediente válido para avanzar.";
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: msg,
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);

      const response = await avanzarMutation.mutateAsync(expedienteId);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Actividad avanzada correctamente",
          life: 2000,
        });

        navigate("/home/bandeja");
      } else {
        const msg = response.message || "No se pudo avanzar la actividad.";
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: msg,
          life: 3000,
        });
      }
    } catch (error) {
      const msg = "Ocurrió un error al avanzar.";

      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: msg,
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleSalir = () => {
    navigate("/home/bandeja");
  };

  return (
    <>
      <Toast ref={toast} />

      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Realizar Control de Crédito
      </h2>

      <Accordion activeIndex={[0, 2]} multiple>
        <AccordionTab
          disabled={!id_expediente || id_expediente <= 0}
          header="Información del Expediente"
        >
          <EncabezadoActividad
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            activityID={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab
          header="Funciones Transversales"
          disabled={!id_expediente || id_expediente <= 0}
        >
          <FuncionesTransversales
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            idActividad={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header="Realizar Control de Crédito">
          <Card className="w-full shadow-md card-presto-form mb-6">
            {isLoading && id_expediente > 0 && (
              <div className="mb-4 text-sm text-blue-600">
                Cargando información...
              </div>
            )}

            <div className="md:col-span-4 mt-2">
              <div className="bg-azul-presto text-white font-bold text-sm px-4 py-2 uppercase rounded mb-4">
                Estatus de la Actividad
              </div>
              <div className="flex items-center gap-3">
                <Checkbox
                  inputId="enviar_reparo"
                  checked={form.enviar_reparo}
                  onChange={(e) => updateField("enviar_reparo", e.checked ?? false)}
                  disabled={isDisabled}
                />
                <label htmlFor="enviar_reparo" className="font-semibold text-sm">
                  ¿Enviar a Reparo?
                </label>
              </div>
            </div>

            <div className="md:col-span-4 mt-2">
              <label className="font-semibold text-sm">Observaciones</label>
              <textarea
                id="observaciones"
                value={form.observaciones ?? ""}
                onChange={(e) => updateField("observaciones", e.target.value)}
                rows={4}
                maxLength={1000}
                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                placeholder="Ingrese observaciones (máximo 1000 caracteres)"
                disabled={isDisabled}
                style={{ resize: "none" }}
              />
              <div className="flex justify-end mt-1 text-xs">
                <span className={
                  (form.observaciones?.length ?? 0) >= 1000 
                    ? "text-red-600" 
                    : (form.observaciones?.length ?? 0) >= 900 
                      ? "text-orange-500" 
                      : "text-gray-500"
                }>
                  {form.observaciones?.length ?? 0}
                </span>
                <span className="mx-1 text-gray-500">/</span>
                <span className="text-gray-500">1000</span>
              </div>
            </div>

            <ActivityActionBar
              from_tracking={fromTracking}
              is_busy={isBusy}
              is_disabled={isDisabled}
              can_advance={canAdvance}
              is_saving={saveMutation.isPending}
              is_advancing={avanzarMutation.isPending}
              on_edit={handleEditar}
              on_save={handleGuardar}
              on_advance={handleAvanzar}
              on_exit={handleSalir}
            />
          </Card>
        </AccordionTab>
      </Accordion>
    </>
  );
}