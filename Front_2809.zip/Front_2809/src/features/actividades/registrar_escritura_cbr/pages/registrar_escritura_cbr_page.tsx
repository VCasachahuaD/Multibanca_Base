import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Accordion, AccordionTab } from "primereact/accordion";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Checkbox, CheckboxChangeEvent } from "primereact/checkbox";
import { InputNumber } from "primereact/inputnumber";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";

import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";
import type { RegistrarEscrituraCbr } from "../models/registrar_escritura_cbr";
import { useAvanzarRegistrarEscrituraCbr } from "../hooks/useAvanzarRegistrarEscrituraCbr";
import { useRegistrarEscrituraCbr } from "../hooks/useRegistrarEscrituraCbr";
import { useUpsertRegistrarEscrituraCbr } from "../hooks/useUpsertRegistrarEscrituraCbr";
import { Dropdown } from "primereact/dropdown";
import { useControlesRegistrarEscrituraCbr } from "../hooks/useControlesRegistrarEscrituraCbr";
import { EMPTY_CONTROLES_REGISTRAR_ESCRITURA_CBR } from "../models/catalogo";
import { InputText } from "primereact/inputtext";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const ACTIVITY_ID = "_Tf7R_N6yIeaQw1_Y2vP9c";

const buildInitialState = (id_expediente: number): RegistrarEscrituraCbr => ({
    id_registrar_escritura_cbr: 0,
    id_expediente,
    conservador: "",
    numero_caratula: "",
    observaciones: "",
    is_active: true,
    row_status: true,
    created_by: 0,
    created_date: new Date().toISOString(),
    modified_by: null,
    modified_date: null,
});

const normalizeRegistrarEscrituraCbr = (
    source: Partial<RegistrarEscrituraCbr> | null | undefined,
    id_expediente_fallback: number,
): RegistrarEscrituraCbr => {
    return {
        id_registrar_escritura_cbr: Number(source?.id_registrar_escritura_cbr ?? 0),
        id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
        conservador: source?.conservador ?? "",
        numero_caratula: source?.numero_caratula ?? "",
        observaciones: source?.observaciones ?? "",
        is_active: source?.is_active ?? true,
        row_status: source?.row_status ?? true,
        created_by: Number(source?.created_by ?? 0),
        created_date: source?.created_date ?? new Date().toISOString(),
        modified_by: source?.modified_by ?? null,
        modified_date: source?.modified_date ?? null,
    };
};

export default function RegistrarEscrituraCbrPage() {
    const toast = useRef<Toast>(null);

    const navigate = useNavigate();
    const location = useLocation();
    const { id_expediente: idExpedienteParam } = useParams();
    const { fromTracking = false } = location.state || {};

    const id_expediente = Number(idExpedienteParam ?? 0);

    const [form, setForm] = useState<RegistrarEscrituraCbr>(
        buildInitialState(id_expediente),
    );
    const [isDisabled, setIsDisabled] = useState(true);
    const [canAdvance, setCanAdvance] = useState(false);
    const [isBusy, setIsBusy] = useState(false);

    const hasHydratedRef = useRef(false);
    const currentExpedienteRef = useRef<number>(id_expediente);

    const { data, isLoading } = useRegistrarEscrituraCbr(id_expediente);
    const saveMutation = useUpsertRegistrarEscrituraCbr();
    const avanzarMutation = useAvanzarRegistrarEscrituraCbr();
    const controlesRegistrarEscrituraCbrQuery = useControlesRegistrarEscrituraCbr();
    
    const controlesRegistrarEscrituraCbr = controlesRegistrarEscrituraCbrQuery.data?.status
        ? controlesRegistrarEscrituraCbrQuery.data.detail ?? EMPTY_CONTROLES_REGISTRAR_ESCRITURA_CBR
        : EMPTY_CONTROLES_REGISTRAR_ESCRITURA_CBR;
    
    useEffect(() => {
        if (currentExpedienteRef.current !== id_expediente) {
            currentExpedienteRef.current = id_expediente;
            hasHydratedRef.current = false;

            setForm(buildInitialState(id_expediente));
            setIsDisabled(true);
            setCanAdvance(false);
        }
    }, [id_expediente]);

    useEffect(() => {
        if (hasHydratedRef.current) return;

        if (data?.status && data.detail) {
            const loadedEntity = normalizeRegistrarEscrituraCbr(
                data.detail,
                id_expediente,
            );

            setForm(loadedEntity);
            setIsDisabled(true);
            setCanAdvance(false);
            hasHydratedRef.current = true;
            return;
        }

        if (!id_expediente || id_expediente <= 0) {
            setForm(buildInitialState(0));
            setIsDisabled(false);
            setCanAdvance(false);
            hasHydratedRef.current = true;
            return;
        }

        if (data) {
            setForm((prev) =>
                normalizeRegistrarEscrituraCbr(
                    {
                        ...prev,
                        id_expediente,
                    },
                    id_expediente,
                ),
            );
            setIsDisabled(true);
            setCanAdvance(false);
            hasHydratedRef.current = true;
        }
    }, [data, id_expediente]);

    const updateField = <K extends keyof RegistrarEscrituraCbr>(
        field: K,
        value: RegistrarEscrituraCbr[K],
    ) => {
        setForm((prev) => ({
            ...prev,
            [field]: value,
        }));
    };

    const handleEditar = () => {
        setIsDisabled(false);
        setCanAdvance(false);
    };

    const validateForm = () => {
        if (!form.id_expediente || form.id_expediente <= 0) {
            return "No existe un id_expediente válido.";
        }

        if (!form.conservador || !form.conservador.trim()) {
            return "Debe seleccionar un Conservador.";
        }

        if (!form.numero_caratula || !form.numero_caratula.trim()) {
            return "Debe ingresar el N° de Carátula.";
        }

        if (!form.observaciones || !form.observaciones.trim()) {
            return "Debe ingresar Observaciones.";
        }

        return "";
    };

    const handleGuardar = async () => {

        const validationMessage = validateForm();
        if (validationMessage) {
            toast.current?.show({
                severity: "warn",
                summary: "Validación",
                detail: validationMessage,
                life: 3000,
            });
            return;
        }

        try {
            setIsBusy(true);

            const payload: RegistrarEscrituraCbr = normalizeRegistrarEscrituraCbr(
                {
                    ...form,
                    id_registrar_escritura_cbr: Number(
                        form.id_registrar_escritura_cbr ?? 0,
                    ),
                    id_expediente: Number(form.id_expediente || id_expediente || 0),
                },
                id_expediente,
            );

            const response = await saveMutation.mutateAsync(payload);

            if (response.status) {
                toast.current?.show({
                    severity: "success",
                    summary: "Éxito",
                    detail: "Actividad Registrar escritura CBR guardada correctamente",
                    life: 3000,
                });

                const savedEntity = normalizeRegistrarEscrituraCbr(
                    response.detail ?? payload,
                    payload.id_expediente,
                );

                setForm(savedEntity);
                setIsDisabled(true);
                setCanAdvance(true);
                hasHydratedRef.current = true;
            } else {
                toast.current?.show({
                    severity: "warn",
                    summary: "Atención",
                    detail: response.message || "No se pudo guardar",
                    life: 3000,
                });
            }
        } catch (error) {

            toast.current?.show({
                severity: "error",
                summary: "Error",
                detail: "Ocurrió un error al guardar",
                life: 3000,
            });
        } finally {
            setIsBusy(false);
        }
    };

    const handleAvanzar = async () => {
        const validationMessage = validateForm();
        if (validationMessage) {
            toast.current?.show({
                severity: "warn",
                summary: "Validación",
                detail: validationMessage,
                life: 3000,
            });
            return;
        }

        if (!canAdvance) {
            toast.current?.show({
                severity: "warn",
                summary: "Validación",
                detail: "Debe guardar los cambios antes de avanzar.",
                life: 3000,
            });
            return;
        }

        try {
            setIsBusy(true);

            const response = await avanzarMutation.mutateAsync(Number(form.id_expediente));

            if (response.status) {
                toast.current?.show({
                    severity: "success",
                    summary: "Éxito",
                    detail: "Actividad avanzada correctamente",
                    life: 2000,
                });

                navigate("/home/bandeja");
            } else {
                const msg = response.message || "No se pudo avanzar la actividad.";

                toast.current?.show({
                    severity: "warn",
                    summary: "Atención",
                    detail: msg,
                    life: 3000,
                });
            }
        } catch (error) {
            const msg = "Ocurrió un error al avanzar.";

            toast.current?.show({
                severity: "error",
                summary: "Error",
                detail: msg,
                life: 3000,
            });
        } finally {
            setIsBusy(false);
        }
    };

    const handleSalir = () => {
        navigate("/home/bandeja");
    };

    return (
        <>
            <Toast ref={toast} />

            <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Registrar escritura CBR
            </h2>

            <Accordion activeIndex={[0, 2]} multiple>
                <AccordionTab
                    disabled={!id_expediente || id_expediente <= 0}
                    header="Información del Expediente"
                >
                    <EncabezadoActividad
                        idExpediente={Number(form.id_expediente || id_expediente || 0)}
                        activityID={ACTIVITY_ID}
                    />
                </AccordionTab>

                <AccordionTab
                    header="Funciones Transversales"
                    disabled={!id_expediente || id_expediente <= 0}
                >
                    <FuncionesTransversales
                        idExpediente={Number(form.id_expediente || id_expediente || 0)}
                        idActividad={ACTIVITY_ID}
                    />
                </AccordionTab>

                <AccordionTab header="Registrar escritura CBR">
                    <Card className="w-full shadow-md card-presto-form mb-6">
                        {isLoading && id_expediente > 0 && (
                            <div className="mb-4 text-sm text-blue-600">
                                Cargando información...
                            </div>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                            <div className="flex flex-col gap-1">
                                <label className="font-semibold text-sm">Conservador *</label>
                                <Dropdown
                                    value={form?.conservador ?? null}
                                    options={controlesRegistrarEscrituraCbr.conservador}
                                    optionLabel="description"
                                    optionValue="code"
                                    disabled={isDisabled}
                                    className="form-dropdown-presto w-full"
                                    placeholder="Seleccione"
                                    onChange={(e) => updateField('conservador', e.value)}
                                    showClear
                                />
                            </div>

                            <div className="flex flex-col gap-1">
                                <label className="font-semibold text-sm">Nro. caratula *</label>
                                <InputText
                                value={form.numero_caratula ?? ""}
                                onChange={(e) => updateField("numero_caratula", e.target.value)}
                                className="form-input-presto w-full"
                                disabled={isDisabled}
                                />
                            </div>
                            <div className="flex flex-col gap-1 md:col-span-3">
                                <label className="font-semibold text-sm">
                                    Observaciones *
                                </label>
                                <InputTextarea
                                    value={form.observaciones ?? ""}
                                    onChange={(e) => updateField("observaciones", e.target.value)}
                                    rows={4}
                                    maxLength={1000}
                                    className="form-textarea-presto w-full"
                                    disabled={isDisabled}
                                    placeholder="Ingrese observaciones (máximo 1000 caracteres)"
                                    style={{ resize: "none" }}
                                />
                                <div className="flex justify-end mt-1 text-xs">
                                    <span className={
                                    (form.observaciones?.length ?? 0) >= 1000 
                                        ? "text-red-600" 
                                        : (form.observaciones?.length ?? 0) >= 900 
                                        ? "text-orange-500" 
                                        : "text-gray-500"
                                    }>
                                    {form.observaciones?.length ?? 0}
                                    </span>
                                    <span className="mx-1 text-gray-500">/</span>
                                    <span className="text-gray-500">1000</span>
                                </div>
                            </div>
                        </div>

                        <ActivityActionBar
                            from_tracking={fromTracking}
                            is_busy={isBusy}
                            is_disabled={isDisabled}
                            can_advance={canAdvance}
                            is_saving={saveMutation.isPending}
                            is_advancing={avanzarMutation.isPending}
                            on_edit={handleEditar}
                            on_save={handleGuardar}
                            on_advance={handleAvanzar}
                            on_exit={handleSalir}
                        />
                    </Card>
                </AccordionTab>
            </Accordion>
        </>
    );
}