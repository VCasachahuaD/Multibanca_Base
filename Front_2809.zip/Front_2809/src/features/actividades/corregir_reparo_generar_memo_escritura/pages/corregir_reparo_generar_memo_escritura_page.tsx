import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Accordion, AccordionTab } from "primereact/accordion";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Checkbox } from "primereact/checkbox";
import { Dialog } from "primereact/dialog";
import { InputTextarea } from "primereact/inputtextarea";
import { TabPanel, TabView } from "primereact/tabview";
import { Toast } from "primereact/toast";

import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";

import type { CorregirReparoGenerarMemoEscritura } from "../models/corregir_reparo_generar_memo_escritura";
import { useCorregirReparoGenerarMemoEscritura } from "../hooks/useCorregirReparoGenerarMemoEscritura";
import { useUpsertCorregirReparoGenerarMemoEscritura } from "../hooks/useUpsertCorregirReparoGenerarMemoEscritura";
import { useAvanzarCorregirReparoGenerarMemoEscritura } from "../hooks/useAvanzarCorregirReparoGenerarMemoEscritura";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
import { InputNumber } from "primereact/inputnumber";
import BancoAcreedorSection from "@/features/actividades/datos_operacion/components/BancoAcreedorSection";
import DatosOperacionPersonaGrid from "@/features/actividades/datos_operacion/components/DatosOperacionPersonaGrid";
import FiadorGaranteSection from "@/features/actividades/datos_operacion/components/FiadorGaranteSection";
import PropiedadSection from "@/features/actividades/datos_operacion/components/PropiedadSection";
import { useControlesBancoAcreedor } from "@/features/actividades/datos_operacion/hooks/useControlesBancoAcreedor";
import { useControlesComprador } from "@/features/actividades/datos_operacion/hooks/useControlesComprador";
import { useControlesFiadorGarante } from "@/features/actividades/datos_operacion/hooks/useControlesFiadorGarante";
import { useControlesPropiedad } from "@/features/actividades/datos_operacion/hooks/useControlesPropiedad";
import { useControlesVendedor } from "@/features/actividades/datos_operacion/hooks/useControlesVendedor";
import {
  buildBancoAcreedorEmpty,
  buildDatosCreditoEmpty,
  buildDatosOperacionEmpty,
  buildPropiedadEmpty,
  type DatosOperacion,
  type DatosOperacionBancoAcreedor,
  type DatosOperacionComprador,
  type DatosOperacionDatosCredito,
  type DatosOperacionFiadorGarante,
  type DatosOperacionPropiedad,
  type DatosOperacionVendedor,
} from "@/features/actividades/datos_operacion/models/datos_operacion";
import {
  EMPTY_CONTROLES_BANCO_ACREEDOR,
  EMPTY_CONTROLES_COMPRADOR,
  EMPTY_CONTROLES_FIADOR_GARANTE,
  EMPTY_CONTROLES_PROPIEDAD,
  EMPTY_CONTROLES_VENDEDOR,
} from "@/features/actividades/datos_operacion/models/catalogo";
import { focusFieldByKey } from "@/features/actividades/datos_operacion/utils/fieldFocus";
import { isValidRut, rutErrorMessage } from "@/shared/utils/chileanValidators";
import {
  getMissingPersonaField,
  getMissingPersonaFieldKey,
  getPersonaRutErrorMessage,
} from "@/features/actividades/datos_operacion/components/DatosOperacionPersonaGrid";
import {
  getMissingFiadorField,
  getMissingFiadorFieldKey,
} from "@/features/actividades/datos_operacion/components/FiadorGaranteSection";
const ACTIVITY_ID = "_N9xFdC1vEenZh4_Z8rL2m";

const build_initial_state = (id_expediente: number): CorregirReparoGenerarMemoEscritura => ({
  id_corregir_reparo_generar_memo_escritura: 0,
  id_expediente,
  id_usuario_solicitante: 0,
  is_subsanar: false,
  observaciones: null,
  solicitante: "",
  observaciones_reparo: "",
  fecha_ingreso: null,
  datos_operacion: null,
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: new Date().toISOString(),
  modified_by: null,
  modified_date: null,
});

const normalize = (
  source: Partial<CorregirReparoGenerarMemoEscritura> | null | undefined,
  id_expediente_fallback: number,
): CorregirReparoGenerarMemoEscritura => ({
  id_corregir_reparo_generar_memo_escritura: Number(
    source?.id_corregir_reparo_generar_memo_escritura ?? 0,
  ),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback),
  id_usuario_solicitante: Number(source?.id_usuario_solicitante ?? 0),
  is_subsanar: Boolean(source?.is_subsanar ?? false),
  observaciones: source?.observaciones ?? null,
  solicitante: source?.solicitante ?? "",
  observaciones_reparo: source?.observaciones_reparo ?? "",
  fecha_ingreso: source?.fecha_ingreso ?? null,
  datos_operacion: source?.datos_operacion ?? null,
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? new Date().toISOString(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const format_date = (value: string | null | undefined): string => {
  if (!value) return "";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleDateString("es-CL", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
};

export default function CorregirReparoGenerarMemoEscrituraPage() {
  const toast = useRef<Toast>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: id_param } = useParams();
  const { fromTracking = false } = location.state || {};

  const id_expediente = Number(id_param ?? 0);
  const has_valid_expediente = id_expediente > 0;

  const [form, set_form] = useState<CorregirReparoGenerarMemoEscritura>(
    build_initial_state(id_expediente),
  );
  const [is_disabled, set_is_disabled] = useState(true);
  const [can_advance, set_can_advance] = useState(false);
  const [is_busy, set_is_busy] = useState(false);
  const [datos_operacion_visible, set_datos_operacion_visible] = useState(false);
  const [datos_operacion_snapshot, set_datos_operacion_snapshot] = useState<DatosOperacion | null>(null);
  const [dialog_tab, set_dialog_tab] = useState(0);
  const has_hydrated = useRef(false);
  const current_expediente = useRef(id_expediente);

  const { data, isLoading } = useCorregirReparoGenerarMemoEscritura(id_expediente);
  const save_mutation = useUpsertCorregirReparoGenerarMemoEscritura();
  const avanzar_mutation = useAvanzarCorregirReparoGenerarMemoEscritura();

  const controlesCompradorQuery = useControlesComprador(has_valid_expediente);
  const controlesVendedorQuery = useControlesVendedor(has_valid_expediente);
  const controlesFiadorGaranteQuery = useControlesFiadorGarante(has_valid_expediente);
  const controlesBancoAcreedorQuery = useControlesBancoAcreedor(has_valid_expediente);
  const controlesPropiedadQuery = useControlesPropiedad(has_valid_expediente);

  const controlesComprador = controlesCompradorQuery.data?.status
    ? controlesCompradorQuery.data.detail ?? EMPTY_CONTROLES_COMPRADOR
    : EMPTY_CONTROLES_COMPRADOR;
  const controlesVendedor = controlesVendedorQuery.data?.status
    ? controlesVendedorQuery.data.detail ?? EMPTY_CONTROLES_VENDEDOR
    : EMPTY_CONTROLES_VENDEDOR;
  const controlesCompradorConTipoPersona = useMemo(
    () => ({ ...controlesComprador, tipo_vendedor: controlesVendedor.tipo_vendedor }),
    [controlesComprador, controlesVendedor.tipo_vendedor],
  );
  const controlesFiadorGarante = controlesFiadorGaranteQuery.data?.status
    ? controlesFiadorGaranteQuery.data.detail ?? EMPTY_CONTROLES_FIADOR_GARANTE
    : EMPTY_CONTROLES_FIADOR_GARANTE;
  const controlesBancoAcreedor = controlesBancoAcreedorQuery.data?.status
    ? controlesBancoAcreedorQuery.data.detail ?? EMPTY_CONTROLES_BANCO_ACREEDOR
    : EMPTY_CONTROLES_BANCO_ACREEDOR;
  const controlesPropiedad = controlesPropiedadQuery.data?.status
    ? controlesPropiedadQuery.data.detail ?? EMPTY_CONTROLES_PROPIEDAD
    : EMPTY_CONTROLES_PROPIEDAD;

  useEffect(() => {
    if (current_expediente.current !== id_expediente) {
      current_expediente.current = id_expediente;
      has_hydrated.current = false;

      set_form(build_initial_state(id_expediente));
      set_is_disabled(true);
      set_can_advance(false);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (has_hydrated.current) return;

    if (data?.status && data.detail) {
      const loaded = normalize(data.detail, id_expediente);

      set_form(loaded);
      set_is_disabled(true);
      set_can_advance(false);
      has_hydrated.current = true;
      return;
    }

    if (!has_valid_expediente) {
      set_form(build_initial_state(0));
      set_is_disabled(false);
      set_can_advance(false);
      has_hydrated.current = true;
      return;
    }

    if (data) {
      set_form(build_initial_state(id_expediente));
      set_is_disabled(true);
      set_can_advance(false);
      has_hydrated.current = true;
    }
  }, [data, id_expediente, has_valid_expediente]);

  const show_toast = (
    severity: "success" | "warn" | "info" | "error",
    summary: string,
    detail: string,
  ) => {
    toast.current?.show({ severity, summary, detail, life: 3500 });
  };

  const toggle_subsanar = (checked: boolean) => {
    set_form((prev) => ({
      ...prev,
      is_subsanar: checked,
    }));

    set_can_advance(false);
  };

  const handle_editar = () => {
    set_is_disabled(false);
    set_can_advance(false);
  };

  const can_edit_sections = !is_disabled && !is_busy;

  const updateDatosCreditoField = <K extends keyof DatosOperacionDatosCredito>(
    field: K,
    value: DatosOperacionDatosCredito[K],
  ) => {
    set_form((prev) => {
      const datos = prev.datos_operacion ?? buildDatosOperacionEmpty(id_expediente);
      return {
        ...prev,
        datos_operacion: {
          ...datos,
          datos_credito: {
            ...(datos.datos_credito ??
              buildDatosCreditoEmpty(id_expediente, datos.id_datos_operacion)),
            [field]: value,
          },
        },
      };
    });
  };

  const updateBancoAcreedorField = <K extends keyof DatosOperacionBancoAcreedor>(
    field: K,
    value: DatosOperacionBancoAcreedor[K],
  ) => {
    set_form((prev) => {
      const datos = prev.datos_operacion ?? buildDatosOperacionEmpty(id_expediente);
      return {
        ...prev,
        datos_operacion: {
          ...datos,
          banco_acreedor: {
            ...(datos.banco_acreedor ??
              buildBancoAcreedorEmpty(id_expediente, datos.id_datos_operacion)),
            [field]: value,
          },
        },
      };
    });
  };

  const updatePropiedadField = <K extends keyof DatosOperacionPropiedad>(
    field: K,
    value: DatosOperacionPropiedad[K],
  ) => {
    set_form((prev) => {
      const datos = prev.datos_operacion ?? buildDatosOperacionEmpty(id_expediente);
      return {
        ...prev,
        datos_operacion: {
          ...datos,
          propiedad: {
            ...(datos.propiedad ??
              buildPropiedadEmpty(id_expediente, datos.id_datos_operacion)),
            [field]: value,
          },
        },
      };
    });
  };

  const updateCompradores = (compradores: DatosOperacionComprador[]) => {
    set_form((prev) => ({
      ...prev,
      datos_operacion: {
        ...(prev.datos_operacion ?? buildDatosOperacionEmpty(id_expediente)),
        compradores,
      },
    }));
  };

  const updateVendedores = (vendedores: DatosOperacionVendedor[]) => {
    set_form((prev) => ({
      ...prev,
      datos_operacion: {
        ...(prev.datos_operacion ?? buildDatosOperacionEmpty(id_expediente)),
        vendedores,
      },
    }));
  };

  const updateFiadoresGarantes = (fiadores_garantes: DatosOperacionFiadorGarante[]) => {
    set_form((prev) => ({
      ...prev,
      datos_operacion: {
        ...(prev.datos_operacion ?? buildDatosOperacionEmpty(id_expediente)),
        fiadores_garantes,
      },
    }));
  };

  const validate_form = (): string => {
    if (!has_valid_expediente) return "No existe un id_expediente válido.";

    if (!form.observaciones || !form.observaciones.trim()) {
      return "Debe ingresar las Observaciones.";
    }

    return "";
  };

  const handle_guardar = async () => {
    const validation_msg = validate_form();
    if (validation_msg) {
      show_toast("warn", "Validación", validation_msg);
      return;
    }

    set_is_busy(true);

    try {
      const payload = normalize({ ...form, id_expediente }, id_expediente);
      const response = await save_mutation.mutateAsync(payload);

      if (response.status) {
        const saved = normalize(response.detail ?? payload, payload.id_expediente);

        set_form(saved);
        set_is_disabled(true);
        set_can_advance(true);
        has_hydrated.current = true;

        show_toast("success", "Éxito", "Información guardada correctamente.");
      } else {
        show_toast("warn", "Atención", response.message || "No se pudo guardar.");
      }
    } catch (error) {
      show_toast("error", "Error", "Ocurrió un error al guardar.");
    } finally {
      set_is_busy(false);
    }
  };

  const handle_avanzar = async () => {
    if (!has_valid_expediente) {
      const msg = "No existe un id_expediente válido para avanzar.";
      show_toast("warn", "Validación", msg);
      return;
    }

    if (!form.is_subsanar) {
      const msg = "Debe marcar Subsanar para avanzar la actividad.";
      show_toast("warn", "Validación", msg);
      return;
    }

    set_is_busy(true);

    try {
      const response = await avanzar_mutation.mutateAsync(id_expediente);

      if (response.status) {
        show_toast(
          "success",
          "Éxito",
          response.message || "Actividad avanzada correctamente.",
        );

        navigate("/home/bandeja");
      } else {
        const msg = response.message || "No se pudo avanzar la actividad.";
        show_toast("warn", "Atención", msg);
      }
    } catch (error) {
      const msg = "Ocurrió un error al avanzar.";
      show_toast("error", "Error", msg);
    } finally {
      set_is_busy(false);
    }
  };

  const handle_salir = () => navigate("/home/bandeja");

  const abrir_datos_operacion = () => {
    set_datos_operacion_snapshot(
      form.datos_operacion ? JSON.parse(JSON.stringify(form.datos_operacion)) : null,
    );
    set_dialog_tab(0);
    set_datos_operacion_visible(true);
  };

  const validar_datos_operacion = (): { tabIndex: number; fieldKey: string; message: string } | null => {
    const datos = form.datos_operacion;

    // El catálogo es necesario para distinguir Natural/Jurídico: el `code` es
    // numérico ('01'/'02'), la distinción está en la descripción.
    const tipoCompradorOptions = controlesComprador.tipo_comprador;
    const tipoVendedorOptions = controlesVendedor.tipo_vendedor;

    const compradores = (datos?.compradores ?? []).filter((c) => c.row_status !== false);
    for (let i = 0; i < compradores.length; i++) {
      const rutMessage = getPersonaRutErrorMessage(compradores[i]);
      if (rutMessage) {
        return {
          tabIndex: 0,
          fieldKey: "rut",
          message: `Comprador, registro ${i + 1}: ${rutMessage}`,
        };
      }

      const label = getMissingPersonaField("comprador", compradores[i], tipoCompradorOptions);
      if (label) {
        return {
          tabIndex: 0,
          fieldKey:
            getMissingPersonaFieldKey("comprador", compradores[i], tipoCompradorOptions) ?? "rut",
          message: `Comprador, registro ${i + 1}: debe completar el campo ${label}.`,
        };
      }
    }

    const vendedores = (datos?.vendedores ?? []).filter((v) => v.row_status !== false);
    for (let i = 0; i < vendedores.length; i++) {
      const rutMessage = getPersonaRutErrorMessage(vendedores[i]);
      if (rutMessage) {
        return {
          tabIndex: 1,
          fieldKey: "rut",
          message: `Vendedor, registro ${i + 1}: ${rutMessage}`,
        };
      }

      const label = getMissingPersonaField("vendedor", vendedores[i], tipoVendedorOptions);
      if (label) {
        return {
          tabIndex: 1,
          fieldKey:
            getMissingPersonaFieldKey("vendedor", vendedores[i], tipoVendedorOptions) ?? "rut",
          message: `Vendedor, registro ${i + 1}: debe completar el campo ${label}.`,
        };
      }
    }

    const fiadores = (datos?.fiadores_garantes ?? []).filter((f) => f.row_status !== false);
    for (let i = 0; i < fiadores.length; i++) {
      const label = getMissingFiadorField(fiadores[i]);
      if (label) {
        return {
          tabIndex: 2,
          fieldKey: getMissingFiadorFieldKey(fiadores[i]) ?? "rut",
          message: `Fiador/Garante, registro ${i + 1}: debe completar el campo ${label}.`,
        };
      }
    }

    const banco = datos?.banco_acreedor;
    if (banco) {
      const banco_checks: [string, string][] = [
        ["cuenta_carta_resguardo", "Cuenta Carta de Resguardo"],
        ["institucion", "Institución"],
        ["rut_banco_acreedor", "RUT Banco Acreedor"],
      ];
      for (const [key, label] of banco_checks) {
        const v = (banco as unknown as Record<string, unknown>)[key];
        if (v === null || v === undefined || (typeof v === "string" && v.trim() === "")) {
          return { tabIndex: 3, fieldKey: key, message: `Debe completar el campo ${label}.` };
        }
      }
      if (!isValidRut(banco.rut_banco_acreedor)) {
        return {
          tabIndex: 3,
          fieldKey: "rut_banco_acreedor",
          message: rutErrorMessage("RUT Banco Acreedor", banco.rut_banco_acreedor, {
            permitirPuntos: true,
          }),
        };
      }
    }

    const prop = datos?.propiedad;
    if (prop) {
      const existe_rol = prop.existe_rol_avaluo === "001";
      const prop_checks: [string, string][] = [
        ["tipo_propiedad", "Tipo Propiedad"],
        ["estado", "Estado"],
        ["tipo_venta", "Tipo Venta"],
        ["tipo_construccion", "Tipo Construcción"],
        ["tipo_direccion", "Tipo Dirección"],
        ["direccion", "Dirección"],
        ["villa_condominio", "Villa / Condominio"],
        ["numero", "Número"],
        ["numero_casa_habitantes", "N° Casa Habitantes"],
        ["conjunto", "Conjunto"],
        ["manzana", "Manzana"],
        ["lote", "Lote"],
        ["region", "Región"],
        ["comuna", "Comuna"],
        ["existe_rol_avaluo", "Existe Rol Avalúo"],
        ...(existe_rol
          ? ([
              ["rol_avaluo_1", "Rol Avalúo 1"],
              ["rol_avaluo_2", "Rol Avalúo 2"],
              ["valor_avaluo_pesos", "Valor Avalúo Pesos"],
            ] as [string, string][])
          : []),
      ];
      for (const [key, label] of prop_checks) {
        const v = (prop as unknown as Record<string, unknown>)[key];
        if (v === null || v === undefined || (typeof v === "string" && v.trim() === "")) {
          return { tabIndex: 4, fieldKey: key, message: `Debe completar el campo ${label}.` };
        }
      }
    }

    const credito = datos?.datos_credito;
    if (credito) {
      const imp_checks: [string, string][] = [
        ["porcentaje_impuesto", "% Impuesto"],
        ["monto_credito_afecto_impuesto", "Monto Crédito Afecto Impuesto"],
        ["impuesto_a_pagar", "Impuesto a Pagar"],
      ];
      for (const [key, label] of imp_checks) {
        const v = (credito as unknown as Record<string, unknown>)[key];
        if (v === null || v === undefined) {
          return { tabIndex: 5, fieldKey: key, message: `Debe completar el campo ${label}.` };
        }
      }
    }

    return null;
  };

  const aceptar_datos_operacion = () => {
    if (is_disabled) {
      set_datos_operacion_visible(false);
      return;
    }
    const error = validar_datos_operacion();
    if (error) {
      set_dialog_tab(error.tabIndex);
      show_toast("warn", "Validación", error.message);
      focusFieldByKey(error.fieldKey, undefined, 250);
      return;
    }
    set_datos_operacion_visible(false);
  };

  const cancelar_datos_operacion = () => {
    if (datos_operacion_snapshot) {
      set_form((prev) => ({ ...prev, datos_operacion: datos_operacion_snapshot }));
    }
    set_datos_operacion_visible(false);
  };

  const dialog_footer = (
    <div className="flex justify-end gap-2">
      <Button
        type="button"
        label="Cancelar"
        icon="pi pi-times"
        severity="secondary"
        outlined
        onClick={cancelar_datos_operacion}
      />
      <Button
        type="button"
        label="Aceptar"
        icon="pi pi-check"
        severity="success"
        onClick={aceptar_datos_operacion}
      />
    </div>
  );

  return (
    <>
      <Toast ref={toast} />

      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Corregir Reparo Generar Memo Escritura
      </h2>

      <Accordion multiple activeIndex={[2]}>
        <AccordionTab header="Información del Expediente" disabled={!has_valid_expediente}>
          <EncabezadoActividad idExpediente={id_expediente} activityID={ACTIVITY_ID} />
        </AccordionTab>

        <AccordionTab header="Funciones Transversales" disabled={!has_valid_expediente}>
          <FuncionesTransversales idExpediente={id_expediente} idActividad={ACTIVITY_ID} />
        </AccordionTab>

        <AccordionTab header="Corregir Reparo Generar Memo Escritura">
          <Card className="w-full shadow-md card-presto-form mb-6">
            {isLoading && has_valid_expediente && (
              <div className="mb-4 text-sm text-blue-600">Cargando información...</div>
            )}

            <div className="flex flex-col gap-6">
              <ReparoTabla
                form={form}
                is_disabled={is_disabled}
                on_toggle_subsanar={toggle_subsanar}
              />

              {/* Datos editables provenientes de la actividad 5.4 (Datos de Operación) */}
              <div className="flex justify-end">
                <Button
                  type="button"
                  label={is_disabled ? "Ver Datos de Operación" : "Editar Datos de Operación"}
                  icon={is_disabled ? "pi pi-eye" : "pi pi-pencil"}
                  severity="info"
                  outlined
                  onClick={abrir_datos_operacion}
                  className="btn-responsive"
                />
              </div>

              <Dialog
                header="Datos a Corregir (5.4 - Datos de Operación)"
                visible={datos_operacion_visible}
                modal
                footer={dialog_footer}
                onHide={cancelar_datos_operacion}
                className="w-full md:w-11/12 lg:w-10/12"
                style={{ maxWidth: "1400px" }}
              >
                <TabView className="mi-tabview" activeIndex={dialog_tab} onTabChange={(e) => set_dialog_tab(e.index)}>
                  <TabPanel header="Comprador">
                    <DatosOperacionPersonaGrid
                      title="Datos del Comprador"
                      type="comprador"
                      value={form.datos_operacion?.compradores ?? []}
                      idExpediente={id_expediente}
                      idDatosOperacion={form.datos_operacion?.id_datos_operacion ?? 0}
                      disabled={is_disabled || is_busy}
                      canEdit={can_edit_sections}
                      controles={controlesCompradorConTipoPersona}
                      loadingControles={controlesCompradorQuery.isLoading || controlesVendedorQuery.isLoading}
                      onChange={updateCompradores}
                      onWarn={(message) => show_toast("warn", "Validación", message)}
                    />
                  </TabPanel>

                  <TabPanel header="Vendedor">
                    <DatosOperacionPersonaGrid
                      title="Datos del Vendedor"
                      type="vendedor"
                      value={form.datos_operacion?.vendedores ?? []}
                      idExpediente={id_expediente}
                      idDatosOperacion={form.datos_operacion?.id_datos_operacion ?? 0}
                      disabled={is_disabled || is_busy}
                      canEdit={can_edit_sections}
                      controles={controlesVendedor}
                      loadingControles={controlesVendedorQuery.isLoading}
                      allowAdd={false}
                      allowDelete={false}
                      onChange={updateVendedores}
                      onWarn={(message) => show_toast("warn", "Validación", message)}
                    />
                  </TabPanel>

                  <TabPanel header="Fiador / Garante">
                    <FiadorGaranteSection
                      value={form.datos_operacion?.fiadores_garantes ?? []}
                      idExpediente={id_expediente}
                      idDatosOperacion={form.datos_operacion?.id_datos_operacion ?? 0}
                      disabled={is_disabled || is_busy}
                      canEdit={can_edit_sections}
                      controles={controlesFiadorGarante}
                      loadingControles={controlesFiadorGaranteQuery.isLoading}
                      allowAdd={false}
                      allowDelete={false}
                      onChange={updateFiadoresGarantes}
                      onWarn={(message) => show_toast("warn", "Validación", message)}
                    />
                  </TabPanel>

                  <TabPanel header="Banco Acreedor">
                    <BancoAcreedorSection
                      value={form.datos_operacion?.banco_acreedor}
                      disabled={is_disabled || is_busy}
                      controles={controlesBancoAcreedor}
                      loadingControles={controlesBancoAcreedorQuery.isLoading}
                      onChange={updateBancoAcreedorField}
                    />
                  </TabPanel>

                  <TabPanel header="Propiedad">
                    <PropiedadSection
                      value={form.datos_operacion?.propiedad}
                      disabled={is_disabled || is_busy}
                      controles={controlesPropiedad}
                      loadingControles={controlesPropiedadQuery.isLoading}
                      onChange={updatePropiedadField}
                    />
                  </TabPanel>

                  <TabPanel header="Impuestos">
                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
                      <div className="flex flex-col gap-1">
                        <label className="font-semibold text-sm text-gray-700">% Impuesto *</label>
                        <InputNumber
                          value={form.datos_operacion?.datos_credito?.porcentaje_impuesto ?? null}
                          disabled={is_disabled || is_busy}
                          className="form-input-presto w-full"
                          inputClassName="w-full"
                          mode="decimal"
                          minFractionDigits={0}
                          maxFractionDigits={6}
                          onValueChange={(e) =>
                            updateDatosCreditoField("porcentaje_impuesto", e.value ?? null)
                          }
                        />
                      </div>

                      <div className="flex flex-col gap-1">
                        <label className="font-semibold text-sm text-gray-700">Monto Crédito Afecto Impuesto *</label>
                        <InputNumber
                          value={form.datos_operacion?.datos_credito?.monto_credito_afecto_impuesto ?? null}
                          disabled={is_disabled || is_busy}
                          className="form-input-presto w-full"
                          inputClassName="w-full"
                          mode="decimal"
                          minFractionDigits={0}
                          maxFractionDigits={6}
                          onValueChange={(e) =>
                            updateDatosCreditoField("monto_credito_afecto_impuesto", e.value ?? null)
                          }
                        />
                      </div>

                      <div className="flex flex-col gap-1">
                        <label className="font-semibold text-sm text-gray-700">Impuesto a Pagar *</label>
                        <InputNumber
                          value={form.datos_operacion?.datos_credito?.impuesto_a_pagar ?? null}
                          disabled={is_disabled || is_busy}
                          className="form-input-presto w-full"
                          inputClassName="w-full"
                          mode="decimal"
                          minFractionDigits={0}
                          maxFractionDigits={6}
                          onValueChange={(e) =>
                            updateDatosCreditoField("impuesto_a_pagar", e.value ?? null)
                          }
                        />
                      </div>
                    </div>
                  </TabPanel>
                </TabView>
              </Dialog>

              <div className="flex flex-col gap-1">
  <label className="font-semibold text-sm">Observaciones *</label>
  <InputTextarea
    value={form.observaciones ?? ""}
    onChange={(e) =>
      set_form((prev) => ({ ...prev, observaciones: e.target.value }))
    }
    rows={4}
    maxLength={1000}
    className="form-textarea-presto w-full"
    disabled={is_disabled}
    placeholder="Ingrese observaciones (máximo 1000 caracteres)"
    style={{ resize: "none" }}
  />
  <div className="flex justify-end mt-1 text-xs">
    <span className={
      (form.observaciones?.length ?? 0) >= 1000 
        ? "text-red-600" 
        : (form.observaciones?.length ?? 0) >= 900 
          ? "text-orange-500" 
          : "text-gray-500"
    }>
      {form.observaciones?.length ?? 0}
    </span>
    <span className="mx-1 text-gray-500">/</span>
    <span className="text-gray-500">1000</span>
  </div>
</div>
            </div>

            <ActivityActionBar
              from_tracking={fromTracking}
              is_busy={is_busy}
              is_disabled={is_disabled}
              can_advance={can_advance}
              is_saving={save_mutation.isPending}
              is_advancing={avanzar_mutation.isPending}
              on_edit={handle_editar}
              on_save={handle_guardar}
              on_advance={handle_avanzar}
              on_exit={handle_salir}
            />
          </Card>
        </AccordionTab>
      </Accordion>
    </>
  );
}

interface ReparoTablaProps {
  form: CorregirReparoGenerarMemoEscritura;
  is_disabled: boolean;
  on_toggle_subsanar: (checked: boolean) => void;
}

function ReparoTabla({
  form,
  is_disabled,
  on_toggle_subsanar,
}: ReparoTablaProps) {
  return (
    <div>
      <div className="bg-azul-presto text-white px-4 py-2 font-semibold text-sm uppercase">
        Detalles del Reparo
      </div>

      <div className="reparo-table-container">
        <table className="reparo-table">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-left w-1/4">
                Solicitante
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-left">
                Observaciones del Reparo
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-center w-32">
                Fecha de Ingreso
              </th>
              <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200 text-center w-24">
                Subsanar
              </th>
            </tr>
          </thead>

          <tbody>
            <tr className="bg-white">
              <td data-label="Solicitante" className="px-3 py-2 text-sm border border-gray-200">
                {form.solicitante || "-"}
              </td>
              <td data-label="Observaciones del Reparo" className="px-3 py-2 text-sm border border-gray-200">
                {form.observaciones_reparo || "-"}
              </td>
              <td data-label="Fecha de Ingreso" className="px-3 py-2 text-sm border border-gray-200 text-center">
                {format_date(form.fecha_ingreso)}
              </td>
              <td data-label="Subsanar" className="px-3 py-2 border border-gray-200 text-center">
                <Checkbox
                  inputId="is_subsanar"
                  className="form-checkbox-presto"
                  checked={form.is_subsanar}
                  onChange={(e) => on_toggle_subsanar(!!e.checked)}
                  disabled={is_disabled}
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}