import { useRef, useState, useMemo, useEffect } from "react";
import type { ReactNode } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";

import { Accordion, AccordionTab } from "primereact/accordion";
import { Card } from "primereact/card";
import { Checkbox } from "primereact/checkbox";
import { Toast } from "primereact/toast";
import ActivityActionBar from "@/shared/components/activity/ActivityActionBar";
import { RadioButton } from "primereact/radiobutton";
import { Dropdown } from "primereact/dropdown";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProgressSpinner } from "primereact/progressspinner";

import EncabezadoActividad from '@/features/encabezado/pages/EncabezadoActividad';
import FuncionesTransversales from '@/features/funciones_transversales/pages/FuncionesTransversales';

import { useControlesGenerarBorradorEscritura } from '../hooks/useControlesGenerarBorradorEscritura';
import { useFiadoresGarantes } from '../hooks/useFiadoresGarantes';
import { useGenerarBorradorEscritura, useSaveGenerarBorradorEscritura, useAvanzarGenerarBorradorEscritura } from '../hooks/useGenerarBorradorEscritura';
import type { CatalogoOption, ControlesGenerarBorradorEscritura } from '../models/catalogo';
import type { FiadorGarante, FiadorGaranteWithSelection } from '../models/generarBorradorEscritura';

const EMPTY_CONTROLES_GENERAR_BORRADOR: ControlesGenerarBorradorEscritura = {
  notaria: [],
  rolcomparecencia: [],
  beneficios: []
};

const determinarRolComparecencia = (fiador: FiadorGarante): number => {
  if (fiador.estado_civil === "002") return 4;

  const nacionalidad = fiador.nacionalidad?.toUpperCase() || "";
  if (nacionalidad !== "CHILENA" && nacionalidad !== "CHILENA EN EL EXTERIOR" && nacionalidad !== "001") {
    return 5;
  }

  const relacionTitular = fiador.relacion_titular?.toUpperCase() || "";
  if (relacionTitular === "COMPRADOR" || relacionTitular === "001") return 1;
  if (relacionTitular === "VENDEDOR") return 2;
  if (relacionTitular === "FIADOR") return 3;

  return 1;
};

type DetalleGuardado = {
  id_datos_operacion_fiador_garante: number;
  id_generar_borrador_escritura_detalle_entity: number;
  id_rol_comparecencia: number;
  requiere_firma: boolean;
};

const normalizeComparecientes = (
  fiadores: FiadorGarante[],
  detallesGuardados: DetalleGuardado[] = []
): FiadorGaranteWithSelection[] => {
  const detallesMap = new Map();
  detallesGuardados.forEach((detalle) => {
    detallesMap.set(detalle.id_datos_operacion_fiador_garante, {
      id_generar_borrador_escritura_detalle_entity: detalle.id_generar_borrador_escritura_detalle_entity,
      id_rol_comparecencia: detalle.id_rol_comparecencia,
      requiere_firma: detalle.requiere_firma,
    });
  });

  return fiadores.map((fiador) => {
    const detalleGuardado = detallesMap.get(fiador.id_datos_operacion_fiador_garante);

    if (detalleGuardado) {
      return {
        ...fiador,
        id_generar_borrador_escritura_detalle_entity: detalleGuardado.id_generar_borrador_escritura_detalle_entity,
        id_rol_comparecencia: detalleGuardado.id_rol_comparecencia,
        requiere_firma: detalleGuardado.requiere_firma,
      };
    }

    return {
      ...fiador,
      id_generar_borrador_escritura_detalle_entity: 0,
      id_rol_comparecencia: determinarRolComparecencia(fiador),
      requiere_firma: false,
    };
  });
};


const renderResponsiveCell = (value: ReactNode, titulo: string) => <div data-titulo={titulo}>{value ?? ""}</div>;

const ACTIVITY_ID = '_Y8tLsN4vEesPc2_X3mR7q';

export default function GenerarBorradorEscrituraPage() {
  const toast = useRef<Toast>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: id } = useParams();
  const { fromTracking = false } = location.state || {};
  const expedienteId = Number(id || 0);
  const hasValidExpediente = expedienteId > 0;

  const [form, setForm] = useState({
    existe_alzamiento: false,
    tiene_seguro_cesantia: false,
    mandatario_judicial: false,
    beneficios: null as string | null,
    id_notaria: null as string | null,
    enviar_reparo: false,
    observaciones: "",
  });

  const [rolComparecenciaFilter, setRolComparecenciaFilter] = useState<number | null>(null);

  const [comparecientes, setComparecientes] = useState<FiadorGaranteWithSelection[]>([]);
  const [isDisabled, setIsDisabled] = useState(true);
  const [canAdvance, setCanAdvance] = useState(false);

  const controlesGenerarBorradorQuery = useControlesGenerarBorradorEscritura();
  const fiadoresGarantesQuery = useFiadoresGarantes(expedienteId, hasValidExpediente);
  const borradorQuery = useGenerarBorradorEscritura(expedienteId, hasValidExpediente);
  const saveMutation = useSaveGenerarBorradorEscritura();
  const avanzarMutation = useAvanzarGenerarBorradorEscritura();

  const catalogos: ControlesGenerarBorradorEscritura = useMemo(() => {
    if (!controlesGenerarBorradorQuery.data?.status) {
      return EMPTY_CONTROLES_GENERAR_BORRADOR;
    }
    return controlesGenerarBorradorQuery.data.detail ?? EMPTY_CONTROLES_GENERAR_BORRADOR;
  }, [controlesGenerarBorradorQuery.data]);

  const notariasOptions = useMemo(() => {
    const notarias = catalogos.notaria || [];
    return notarias.map((notaria: CatalogoOption) => ({
      id: notaria.code,
      descripcion: notaria.description,
    }));
  }, [catalogos.notaria]);

  const rolesComparecenciaOptions = useMemo(() => {
    const roles = catalogos.rolcomparecencia || [];
    return roles.map((rol: CatalogoOption) => ({
      label: rol.description || '',
      value: Number(rol.code),
    }));
  }, [catalogos.rolcomparecencia]);

  const comparecientesFiltrados = useMemo(() => {
    if (rolComparecenciaFilter === null || rolComparecenciaFilter === undefined) {
      return comparecientes;
    }
    return comparecientes.filter(
      (c) => c.id_rol_comparecencia === rolComparecenciaFilter,
    );
  }, [comparecientes, rolComparecenciaFilter]);

  useEffect(() => {
    if (borradorQuery.data?.status && borradorQuery.data.detail) {
      const data = borradorQuery.data.detail;
      queueMicrotask(() => {
        setForm((prev) => ({
          ...prev,
          existe_alzamiento: data.existe_alzamiento,
          tiene_seguro_cesantia: data.seguro_cesantia,
          mandatario_judicial: data.mandato_judicial,
          beneficios: data.beneficios ?? null,
          id_notaria: data.id_notaria ?? null,
          enviar_reparo: data.enviar_reparo || false,
          observaciones: data.observaciones || "",
        }));
      });
    }
  }, [borradorQuery.data]);

  useEffect(() => {
    if (fiadoresGarantesQuery.data?.status && fiadoresGarantesQuery.data.detail) {
      const fiadores = fiadoresGarantesQuery.data.detail;
      const detallesGuardados = borradorQuery.data?.detail?.detalle || [];
      const comparecientesNormalizados = normalizeComparecientes(fiadores, detallesGuardados);
      queueMicrotask(() => setComparecientes(comparecientesNormalizados));
    }
  }, [fiadoresGarantesQuery.data, borradorQuery.data]);

  const isLoading = controlesGenerarBorradorQuery.isLoading ||
    fiadoresGarantesQuery.isLoading ||
    borradorQuery.isLoading;

  const updateField = <K extends keyof typeof form>(field: K, value: typeof form[K]) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleEditar = () => {
    if (!hasValidExpediente) {
      toast.current?.show({
        severity: 'warn',
        summary: 'Validación',
        detail: 'El expediente es obligatorio.',
        life: 3000,
      });
      return;
    }
    setIsDisabled(false);
    setCanAdvance(false);
  };

  const validate_form = (): string => {
    if (!form.observaciones || !form.observaciones.trim()) {
      return "Debe ingresar las Observaciones.";
    }

    if (form.existe_alzamiento === null || form.existe_alzamiento === undefined) {
      return "Debe seleccionar si existe alzamiento.";
    }

    if (form.tiene_seguro_cesantia === null || form.tiene_seguro_cesantia === undefined) {
      return "Debe seleccionar si tiene seguro de cesantía.";
    }

    if (form.mandatario_judicial === null || form.mandatario_judicial === undefined) {
      return "Debe seleccionar si existe mandatario judicial.";
    }

    if (form.beneficios === null || form.beneficios === undefined) {
      return "Debe seleccionar un beneficio.";
    }

    if (!form.id_notaria) {
      return "Debe seleccionar una notaría.";
    }
    return "";
  };

  const handleGuardar = async () => {
    if (!hasValidExpediente) {
      toast.current?.show({
        severity: 'warn',
        summary: 'Validación',
        detail: 'El expediente es obligatorio.',
        life: 3000,
      });
      return;
    }

    const validation_msg = validate_form();
    if (validation_msg) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: validation_msg,
        life: 3000,
      });
      return;
    }

    try {
      const payload = {
        id_generar_borrador_escritura: borradorQuery.data?.detail?.id_generar_borrador_escritura || 0,
        id_expediente: expedienteId,
        existe_alzamiento: form.existe_alzamiento,
        seguro_cesantia: form.tiene_seguro_cesantia,
        mandato_judicial: form.mandatario_judicial,
        beneficios: form.beneficios,
        id_notaria: form.id_notaria ? form.id_notaria : null,
        enviar_reparo: form.enviar_reparo,
        observaciones: form.observaciones,
        is_active: true,
        row_status: true,
        created_by: 0,
        created_date: new Date().toISOString(),
        modified_by: null,
        modified_date: null,
        detalle: comparecientes.map((f) => ({
          id_generar_borrador_escritura_detalle_entity: f.id_generar_borrador_escritura_detalle_entity || 0,
          id_generar_borrador_escritura: borradorQuery.data?.detail?.id_generar_borrador_escritura || 0,
          id_datos_operacion_fiador_garante: f.id_datos_operacion_fiador_garante,
          id_expediente: expedienteId,
          id_rol_comparecencia: f.id_rol_comparecencia || 1,
          requiere_firma: f.requiere_firma,
          is_active: true,
          row_status: true,
          created_by: 0,
          created_date: new Date().toISOString(),
          modified_by: null,
          modified_date: null,
        })),
      };

      const response = await saveMutation.mutateAsync(payload);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Información guardada correctamente",
          life: 3000,
        });

        setIsDisabled(true);
        setCanAdvance(true);
        await borradorQuery.refetch();
      } else {
        toast.current?.show({
          severity: "error",
          summary: "Error",
          detail: response.message || "Error al guardar",
          life: 3000,
        });
      }
    } catch {
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Ocurrió un error al guardar",
        life: 3000,
      });
    }
  };

  const handleAvanzar = async () => {
    if (!hasValidExpediente) {
      toast.current?.show({
        severity: 'warn',
        summary: 'Validación',
        detail: 'El expediente es obligatorio.',
        life: 3000,
      });
      return;
    }

    if (!canAdvance) {
      toast.current?.show({
        severity: 'warn',
        summary: 'Validación',
        detail: 'Debe guardar los cambios antes de avanzar.',
        life: 3000,
      });
      return;
    }

    try {
      const response = await avanzarMutation.mutateAsync(expedienteId);

      if (response.status) {
        toast.current?.show({
          severity: 'success',
          summary: 'Avanzar',
          detail: response.message || 'Actividad avanzada correctamente',
          life: 3000,
        });
        navigate('/home/bandeja');
      } else {
        toast.current?.show({
          severity: 'error',
          summary: 'Error',
          detail: response.message || 'No se pudo avanzar la actividad',
          life: 3000,
        });
      }
    } catch (error) {
      console.error('Error al avanzar:', error);
      toast.current?.show({
        severity: 'error',
        summary: 'Error',
        detail: 'Ocurrió un error al avanzar',
        life: 3000,
      });
    }
  };

  const handleSalir = () => {
    navigate('/home/bandeja');
  };

  const handleFirmaChange = (rowData: FiadorGaranteWithSelection, checked: boolean) => {
    const updated = comparecientes.map((item) => {
      if (item.id_datos_operacion_fiador_garante === rowData.id_datos_operacion_fiador_garante) {
        return { ...item, requiere_firma: checked };
      }
      return item;
    });
    setComparecientes(updated);
  };

  const handleRolChange = (rowData: FiadorGaranteWithSelection, value: number) => {
    const updated = comparecientes.map((item) => {
      if (item.id_datos_operacion_fiador_garante === rowData.id_datos_operacion_fiador_garante) {
        return { ...item, id_rol_comparecencia: value };
      }
      return item;
    });
    setComparecientes(updated);
  };

  const rolComparecenciaBodyTemplate = (rowData: FiadorGaranteWithSelection) => (
    <Dropdown
      value={rowData.id_rol_comparecencia}
      options={rolesComparecenciaOptions}
      optionLabel="label"
      optionValue="value"
      placeholder="Selecciona rol"
      className="form-dropdown-presto w-full"
      onChange={(e) => handleRolChange(rowData, e.value)}
      disabled={isDisabled}
      filter
      showClear
    />
  );

  const requiereFirmaBodyTemplate = (rowData: FiadorGaranteWithSelection) => (
    <Checkbox
      checked={rowData.requiere_firma}
      onChange={(e) => handleFirmaChange(rowData, e.checked ?? false)}
      disabled={isDisabled}
    />
  );

  if (isLoading && hasValidExpediente) {
    return (
      <div className="flex justify-center items-center h-64">
        <ProgressSpinner />
      </div>
    );
  }

  return (
    <div>
      <Toast ref={toast} />

      <Accordion multiple activeIndex={[0, 1, 2]}>
        <AccordionTab header="Información del Expediente" disabled={!hasValidExpediente}>
          <EncabezadoActividad
            idExpediente={expedienteId}
            activityID={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header="Funciones Transversales" disabled={!hasValidExpediente}>
          <FuncionesTransversales
            idExpediente={expedienteId}
            idActividad={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header="Generar Borrador Escritura" disabled={!hasValidExpediente}>
          {!hasValidExpediente ? (
            <Card>
              <div className="text-center text-600">
                No se recibió un expediente válido para esta actividad.
              </div>
            </Card>
          ) : (
            <Card className="w-full shadow-md card-presto-form mb-6">
              {controlesGenerarBorradorQuery.isLoading && (
                <div className="mb-4 text-sm text-blue-600">
                  Cargando catálogos...
                </div>
              )}

              {fiadoresGarantesQuery.error && (
                <div className="mb-4 rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  Error al cargar los fiadores/garantes. Por favor, intente nuevamente.
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
                {/* EXISTE ALZAMIENTO */}
                <div className="flex flex-col gap-2">
                  <label className="font-semibold text-sm">Existe Alzamiento</label>
                  <div className="flex items-center gap-5 h-11">
                    <div className="flex items-center gap-2">
                      <RadioButton
                        inputId="alzamiento_si"
                        name="alzamiento"
                        value={true}
                        checked={form.existe_alzamiento === true}
                        onChange={(e) => updateField("existe_alzamiento", e.value)}
                        disabled={isDisabled}
                      />
                      <label htmlFor="alzamiento_si">Sí</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <RadioButton
                        inputId="alzamiento_no"
                        name="alzamiento"
                        value={false}
                        checked={form.existe_alzamiento === false}
                        onChange={(e) => updateField("existe_alzamiento", e.value)}
                        disabled={isDisabled}
                      />
                      <label htmlFor="alzamiento_no">No</label>
                    </div>
                  </div>
                </div>

                {/* SEGURO CESANTIA */}
                <div className="flex flex-col gap-2">
                  <label className="font-semibold text-sm">Tiene Seguro de Cesantía</label>
                  <div className="flex items-center gap-5 h-11">

                    
                    <div className="flex items-center gap-2">
                      
                      <RadioButton
                        inputId="seguro_si"
                        name="seguro"
                        value={true}
                        checked={form.tiene_seguro_cesantia === true}
                        onChange={(e) => updateField("tiene_seguro_cesantia", e.value)}
                        disabled={isDisabled}
                      />
                      <label htmlFor="seguro_si">Sí</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <RadioButton
                        inputId="seguro_no"
                        name="seguro"
                        value={false}
                        checked={form.tiene_seguro_cesantia === false}
                        onChange={(e) => updateField("tiene_seguro_cesantia", e.value)}
                        disabled={isDisabled}
                      />
                      <label htmlFor="seguro_no">No</label>
                    </div>
                  </div>
                </div>

                {/* MANDATARIO JUDICIAL */}
                <div className="flex flex-col gap-2">
                  <label className="font-semibold text-sm">Mandatario Judicial</label>
                  <div className="flex items-center gap-5 h-11">
                    <div className="flex items-center gap-2">
                      <RadioButton
                        inputId="mandatario_si"
                        name="mandatario"
                        value={true}
                        checked={form.mandatario_judicial === true}
                        onChange={(e) => updateField("mandatario_judicial", e.value)}
                        disabled={isDisabled}
                      />
                      <label htmlFor="mandatario_si">Sí</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <RadioButton
                        inputId="mandatario_no"
                        name="mandatario"
                        value={false}
                        checked={form.mandatario_judicial === false}
                        onChange={(e) => updateField("mandatario_judicial", e.value)}
                        disabled={isDisabled}
                      />
                      <label htmlFor="mandatario_no">No</label>
                    </div>
                  </div>
                </div>

                {/* BENEFICIOS */}
                <div className="flex flex-col gap-2 md:col-span-2">
                  <label className="font-semibold text-sm">Beneficios</label>
                  <div className="flex flex-wrap items-center gap-5 min-h-[44px]">

                    
                                    {(catalogos.beneficios ?? []).map((item) => (
                                        <div key={item.code} className="flex items-center gap-2">
                                            <RadioButton
                                                inputId={`beneficios-${item.code}`}
                                                name="beneficios"
                                                value={item.code}
                                                onChange={(e) => updateField('beneficios', e.value ?? null)}
                                                checked={form.beneficios === item.code}
                                                disabled={isDisabled}
                                                className="form-radio-presto"
                                            />
                                            <label htmlFor={`beneficios-${item.code}`}>
                                                {item.description}
                                            </label>
                                        </div>
                                    ))}
            
                  </div>
                </div>

                {/* ASIGNACION NOTARIA */}
                <div className="flex flex-col gap-1 md:col-span-2">
                  <label className="font-semibold text-sm">Asignación de la Notaría</label>
                  <Dropdown
                    value={form.id_notaria}
                    options={notariasOptions}
                    optionLabel="descripcion"
                    optionValue="id"
                    filter
                    showClear
                    placeholder={notariasOptions.length === 0 ? "Cargando notarias..." : "--- Selecciona ---"}
                    className="form-dropdown-presto w-full"
                    onChange={(e) => updateField("id_notaria", e.value ? e.value : null)}
                    disabled={controlesGenerarBorradorQuery.isLoading || isDisabled}
                  />
                </div>

                {/* FILTRO ROL COMPARECENCIA - filtra la grilla de comparecientes */}
                <div className="flex flex-col gap-1 md:col-span-2">
                  <label className="font-semibold text-sm">Filtrar por Rol Comparecencia</label>
                  <Dropdown
                    value={rolComparecenciaFilter}
                    options={rolesComparecenciaOptions}
                    optionLabel="label"
                    optionValue="value"
                    placeholder={rolesComparecenciaOptions.length === 0 ? "Cargando roles..." : "--- Todos ---"}
                    className="form-dropdown-presto w-full"
                    onChange={(e) => setRolComparecenciaFilter(e.value ?? null)}
                    disabled={controlesGenerarBorradorQuery.isLoading}
                    showClear
                    filter
                  />
                </div>

                {/* TABLA DE COMPARECIENTES/FIADORES - OPTIMIZADA */}
                <div className="md:col-span-4">
                  <DataTable
                    key={isDisabled ? "disabled" : "enabled"}
                    value={comparecientesFiltrados}
                    className="p-datatable-sm datatable-presto"
                    emptyMessage={
                      fiadoresGarantesQuery.isLoading
                        ? "Cargando fiadores..."
                        : rolComparecenciaFilter
                          ? "No hay comparecientes para el rol seleccionado"
                          : "No existen fiadores/garantes registrados"
                    }
                  >
                    <Column
                      header="Rol Comparecencia"
                      body={(r: FiadorGaranteWithSelection) => renderResponsiveCell(rolComparecenciaBodyTemplate(r), "Rol Comparecencia: ")}
                      style={{ width: "200px" }}
                    />
                    <Column header="Rut" body={(r: FiadorGaranteWithSelection) => renderResponsiveCell(r.rut, "Rut: ")} />
                    <Column header="Nombres" body={(r: FiadorGaranteWithSelection) => renderResponsiveCell(r.nombres, "Nombres: ")} />
                    <Column header="Apellido Paterno" body={(r: FiadorGaranteWithSelection) => renderResponsiveCell(r.apellido_paterno, "Apellido Paterno: ")} />
                    <Column header="Apellido Materno" body={(r: FiadorGaranteWithSelection) => renderResponsiveCell(r.apellido_materno, "Apellido Materno: ")} />
                    <Column header="Teléfono" body={(r: FiadorGaranteWithSelection) => renderResponsiveCell(r.telefono_movil, "Teléfono: ")} />
                    <Column header="Email" body={(r: FiadorGaranteWithSelection) => renderResponsiveCell(r.email, "Email: ")} />
                    <Column
                      header="Requiere Firma"
                      body={(r: FiadorGaranteWithSelection) => renderResponsiveCell(requiereFirmaBodyTemplate(r), "Requiere Firma: ")}
                      style={{ width: "120px", textAlign: "center" }}
                    />
                  </DataTable>
                </div>
              </div>

              {/* ESTATUS DE LA ACTIVIDAD */}
              <div className="md:col-span-4 mt-6">
                <div className="bg-azul-presto text-white font-bold text-sm px-4 py-2 uppercase rounded mb-4">
                  Estatus de la Actividad
                </div>
                <div className="flex items-center gap-3 mb-4">
                  <Checkbox
                    inputId="enviar_reparo"
                    checked={form.enviar_reparo}
                    onChange={(e) => updateField("enviar_reparo", e.checked ?? false)}
                    disabled={isDisabled}
                  />
                  <label htmlFor="enviar_reparo" className="font-semibold text-sm">
                    ¿Enviar a Reparo?
                  </label>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-semibold text-sm">Observaciones *</label>
                  <textarea
                    id="observaciones"
                    value={form.observaciones ?? ""}
                    onChange={(e) => updateField("observaciones", e.target.value)}
                    rows={4}
                    maxLength={1000}
                    className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="Ingrese observaciones (máximo 1000 caracteres)"
                    disabled={isDisabled}
                    style={{ resize: "none" }}
                  />
                  <div className="flex justify-end mt-1 text-xs">
                    <span className={
                      (form.observaciones?.length ?? 0) >= 1000 
                        ? "text-red-600" 
                        : (form.observaciones?.length ?? 0) >= 900 
                          ? "text-orange-500" 
                          : "text-gray-500"
                    }>
                      {form.observaciones?.length ?? 0}
                    </span>
                    <span className="mx-1 text-gray-500">/</span>
                    <span className="text-gray-500">1000</span>
                  </div>
                </div>
              </div>
              {/* BOTONES */}
              <ActivityActionBar
                from_tracking={fromTracking}
                is_disabled={isDisabled}
                can_advance={canAdvance}
                is_saving={saveMutation.isPending}
                is_advancing={avanzarMutation.isPending}
                on_edit={handleEditar}
                on_save={handleGuardar}
                on_advance={handleAvanzar}
                on_exit={handleSalir}
              />
            </Card>
          )}
        </AccordionTab>
      </Accordion>
    </div>
  );
}
