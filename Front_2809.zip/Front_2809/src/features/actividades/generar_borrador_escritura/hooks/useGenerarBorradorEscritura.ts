import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { ApiResponse } from '@/core/api/models/ApiResponse';
import type { GenerarBorradorEscritura } from '../models/generarBorradorEscritura';
import { generarBorradorEscrituraService } from '../api/generarBorradorEscrituraService';

export const GENERAR_BORRADOR_QUERY_KEY = 'generar_borrador_escritura';

export function useGenerarBorradorEscritura(id_expediente: number, enabled = true) {
  return useQuery<ApiResponse<GenerarBorradorEscritura | null>>({
    queryKey: [GENERAR_BORRADOR_QUERY_KEY, id_expediente],
    queryFn: () => generarBorradorEscrituraService.getByExpediente(id_expediente),
    enabled: enabled && id_expediente > 0,
    staleTime: 1000 * 60 * 5,
  });
}

export function useSaveGenerarBorradorEscritura() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (payload: GenerarBorradorEscritura) =>
      generarBorradorEscrituraService.save(payload),
    onSuccess: (data, variables) => {
      if (variables.id_expediente) {
        queryClient.invalidateQueries({
          queryKey: [GENERAR_BORRADOR_QUERY_KEY, variables.id_expediente],
        });
      }
    },
  });
}

export function useAvanzarGenerarBorradorEscritura() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id_expediente: number) =>
      generarBorradorEscrituraService.avanzar(id_expediente),
    onSuccess: (_, id_expediente) => {
      queryClient.invalidateQueries({
        queryKey: [GENERAR_BORRADOR_QUERY_KEY, id_expediente],
      });
    },
  });
}