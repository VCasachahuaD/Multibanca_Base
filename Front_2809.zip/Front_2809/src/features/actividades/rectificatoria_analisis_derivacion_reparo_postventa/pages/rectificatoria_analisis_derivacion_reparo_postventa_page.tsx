import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Accordion, AccordionTab } from "primereact/accordion";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { InputNumber } from "primereact/inputnumber";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";

import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";
import type { RectificatoriaAnalisisDerivacionReparoPostventa } from "../models/rectificatoria_analisis_derivacion_reparo_postventa";
import { useAvanzarRectificatoriaAnalisisDerivacionReparoPostventa } from "../hooks/useAvanzarRectificatoriaAnalisisDerivacionReparoPostventa";
import { useRectificatoriaAnalisisDerivacionReparoPostventa } from "../hooks/useRectificatoriaAnalisisDerivacionReparoPostventa";
import { useUpsertRectificatoriaAnalisisDerivacionReparoPostventa } from "../hooks/useUpsertRectificatoriaAnalisisDerivacionReparoPostventa";
import { useControlesRectificatoriaAnalisisDerivacionReparoPostventa } from "../hooks/useControlesRectificatoriaAnalisisDerivacionReparoPostventa";
import { ControlesRectificatoriaAnalisisDerivacionReparoPostventa, EMPTY_CONTROLES_RECTIFICATORIA_ANALIS_DERIVACION_REPARO_POSTVENTA } from "../models/catalogo";
import { RadioButton } from "primereact/radiobutton";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const ACTIVITY_ID = "_Yn6U_R8cLeaTu1_D8bT7j";

const buildInitialState = (id_expediente: number): RectificatoriaAnalisisDerivacionReparoPostventa => ({
    id_rectificatoria_analisis_derivacion_reparo_postventa: 0,
    id_expediente,
    enviar_reparo_a: false,
    observaciones: "",
    is_active: true,
    row_status: true,
    created_by: 0,
    created_date: new Date().toISOString(),
    modified_by: null,
    modified_date: null,
});

const normalizeRectificatoriaAnalisisDerivacionReparoPostventa = (
    source: Partial<RectificatoriaAnalisisDerivacionReparoPostventa> | null | undefined,
    id_expediente_fallback: number,
): RectificatoriaAnalisisDerivacionReparoPostventa => {
    return {
        id_rectificatoria_analisis_derivacion_reparo_postventa: Number(source?.id_rectificatoria_analisis_derivacion_reparo_postventa ?? 0),
        id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
        enviar_reparo_a: Boolean(source?.enviar_reparo_a ?? false),
        observaciones: source?.observaciones ?? "",
        is_active: source?.is_active ?? true,
        row_status: source?.row_status ?? true,
        created_by: Number(source?.created_by ?? 0),
        created_date: source?.created_date ?? new Date().toISOString(),
        modified_by: source?.modified_by ?? null,
        modified_date: source?.modified_date ?? null,
    };
};

export default function RectificatoriaAnalisisDerivacionReparoPostventaPage() {
    const toast = useRef<Toast>(null);

    const navigate = useNavigate();
    const location = useLocation();
    const { id_expediente: idExpedienteParam } = useParams();
    const { fromTracking = false } = location.state || {};

    const id_expediente = Number(idExpedienteParam ?? 0);

    const [form, setForm] = useState<RectificatoriaAnalisisDerivacionReparoPostventa>(
        buildInitialState(id_expediente),
    );
    const [isDisabled, setIsDisabled] = useState(true);
    const [canAdvance, setCanAdvance] = useState(false);
    const [isBusy, setIsBusy] = useState(false);

    const hasHydratedRef = useRef(false);
    const currentExpedienteRef = useRef<number>(id_expediente);

    const { data, isLoading } = useRectificatoriaAnalisisDerivacionReparoPostventa(id_expediente);
    const saveMutation = useUpsertRectificatoriaAnalisisDerivacionReparoPostventa();
    const avanzarMutation = useAvanzarRectificatoriaAnalisisDerivacionReparoPostventa();

    const controlesRectificatoriaAnalisisDerivacionReparoPostventaQuery = useControlesRectificatoriaAnalisisDerivacionReparoPostventa();
    

    const catalogo: ControlesRectificatoriaAnalisisDerivacionReparoPostventa = useMemo(() => {
        if (!controlesRectificatoriaAnalisisDerivacionReparoPostventaQuery.data?.status) {
            return EMPTY_CONTROLES_RECTIFICATORIA_ANALIS_DERIVACION_REPARO_POSTVENTA;
        }

        return (
            controlesRectificatoriaAnalisisDerivacionReparoPostventaQuery.data.detail ??
            EMPTY_CONTROLES_RECTIFICATORIA_ANALIS_DERIVACION_REPARO_POSTVENTA
        );
    }, [controlesRectificatoriaAnalisisDerivacionReparoPostventaQuery.data]);
    useEffect(() => {
        if (currentExpedienteRef.current !== id_expediente) {
            currentExpedienteRef.current = id_expediente;
            hasHydratedRef.current = false;

            setForm(buildInitialState(id_expediente));
            setIsDisabled(true);
            setCanAdvance(false);
        }
    }, [id_expediente]);

    useEffect(() => {
        if (hasHydratedRef.current) return;

        if (data?.status && data.detail) {
            const loadedEntity = normalizeRectificatoriaAnalisisDerivacionReparoPostventa(
                data.detail,
                id_expediente,
            );

            setForm(loadedEntity);
            setIsDisabled(true);
            setCanAdvance(false);
            hasHydratedRef.current = true;
            return;
        }

        if (!id_expediente || id_expediente <= 0) {
            setForm(buildInitialState(0));
            setIsDisabled(false);
            setCanAdvance(false);
            hasHydratedRef.current = true;
            return;
        }

        if (data) {
            setForm((prev) =>
                normalizeRectificatoriaAnalisisDerivacionReparoPostventa(
                    {
                        ...prev,
                        id_expediente,
                    },
                    id_expediente,
                ),
            );
            setIsDisabled(true);
            setCanAdvance(false);
            hasHydratedRef.current = true;
        }
    }, [data, id_expediente]);

    const updateField = <K extends keyof RectificatoriaAnalisisDerivacionReparoPostventa>(
        field: K,
        value: RectificatoriaAnalisisDerivacionReparoPostventa[K],
    ) => {
        setForm((prev) => ({
            ...prev,
            [field]: value,
        }));
    };
    const handleEditar = () => {
        setIsDisabled(false);
        setCanAdvance(false);
    };

    const validateForm = () => {
        if (!form.id_expediente || form.id_expediente <= 0) {
            return "No existe un id_expediente válido.";
        }

        return "";
    };

    const handleGuardar = async () => {

        const validationMessage = validateForm();
        if (validationMessage) {
            toast.current?.show({
                severity: "warn",
                summary: "Validación",
                detail: validationMessage,
                life: 3000,
            });
            return;
        }

        try {
            setIsBusy(true);

            const payload: RectificatoriaAnalisisDerivacionReparoPostventa = normalizeRectificatoriaAnalisisDerivacionReparoPostventa(
                {
                    ...form,
                    id_rectificatoria_analisis_derivacion_reparo_postventa: Number(
                        form.id_rectificatoria_analisis_derivacion_reparo_postventa ?? 0,
                    ),
                    id_expediente: Number(form.id_expediente || id_expediente || 0),
                },
                id_expediente,
            );

            const response = await saveMutation.mutateAsync(payload);

            if (response.status) {
                toast.current?.show({
                    severity: "success",
                    summary: "Éxito",
                    detail: "Actividad Rectificatoria Análisis y derivación reparo Postventa guardada correctamente",
                    life: 3000,
                });

                const savedEntity = normalizeRectificatoriaAnalisisDerivacionReparoPostventa(
                    response.detail ?? payload,
                    payload.id_expediente,
                );

                setForm(savedEntity);
                setIsDisabled(true);
                setCanAdvance(true);
                hasHydratedRef.current = true;
            } else {
                toast.current?.show({
                    severity: "warn",
                    summary: "Atención",
                    detail: response.message || "No se pudo guardar",
                    life: 3000,
                });
            }
        } catch (error) {
            toast.current?.show({
                severity: "error",
                summary: "Error",
                detail: "Ocurrió un error al guardar",
                life: 3000,
            });
        } finally {
            setIsBusy(false);
        }
    };

    const handleAvanzar = async () => {
        const validationMessage = validateForm();
        if (validationMessage) {
            toast.current?.show({
                severity: "warn",
                summary: "Validación",
                detail: validationMessage,
                life: 3000,
            });
            return;
        }

        try {
            setIsBusy(true);

            const response = await avanzarMutation.mutateAsync(Number(form.id_expediente));

            if (response.status) {
                toast.current?.show({
                    severity: "success",
                    summary: "Éxito",
                    detail: "Actividad avanzada correctamente",
                    life: 2000,
                });

                navigate("/home/bandeja");
            } else {
                const msg = response.message || "No se pudo avanzar la actividad.";
                toast.current?.show({
                    severity: "warn",
                    summary: "Atención",
                    detail: msg,
                    life: 3000,
                });
            }
        } catch (error) {
            const msg = "Ocurrió un error al avanzar.";
            toast.current?.show({
                severity: "error",
                summary: "Error",
                detail: msg,
                life: 3000,
            });
        } finally {
            setIsBusy(false);
        }
    };

    const handleSalir = () => {
        navigate("/home/bandeja");
    };

    return (
        <>
            <Toast ref={toast} />

            <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Rectificatoria Análisis y derivación reparo Postventa
            </h2>

            <Accordion activeIndex={[0, 2]} multiple>
                <AccordionTab
                    disabled={!id_expediente || id_expediente <= 0}
                    header="Información del Expediente"
                >
                    <EncabezadoActividad
                        idExpediente={Number(form.id_expediente || id_expediente || 0)}
                        activityID={ACTIVITY_ID}
                    />
                </AccordionTab>

                <AccordionTab
                    header="Funciones Transversales"
                    disabled={!id_expediente || id_expediente <= 0}
                >
                    <FuncionesTransversales
                        idExpediente={Number(form.id_expediente || id_expediente || 0)}
                        idActividad={ACTIVITY_ID}
                    />
                </AccordionTab>

                <AccordionTab header="Rectificatoria Análisis y derivación reparo Postventa">
                    <Card className="w-full shadow-md card-presto-form mb-6">
                        {isLoading && id_expediente > 0 && (
                            <div className="mb-4 text-sm text-blue-600">
                                Cargando información...
                            </div>
                        )}

                        {/* Estatus de la Actividad */}
                        <div className="mb-5">
                            <div className="bg-azul-presto text-white px-4 py-2 font-semibold text-sm uppercase">
                                Estatus de la Actividad
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mt-3 px-4 py-3">
                                <div className="flex flex-col gap-1 md:col-span-3">
                                    <div className="flex items-center gap-4 flex-wrap">
                                        <label className="font-semibold text-sm">Enviar reparo a:</label>

                                        <div className="flex gap-4">
                                            {(catalogo.tiporeparo ?? []).map((item) => (
                                                <div key={item.code} className="flex items-center gap-2">
                                                    <RadioButton
                                                        inputId={`enviar_reparo_a-${item.code}`}
                                                        name="enviar_reparo_a"
                                                        value={item.code}
                                                        onChange={(e) => updateField('enviar_reparo_a', e.value ?? null)}
                                                        checked={form.enviar_reparo_a === item.code}
                                                        disabled={isDisabled}
                                                        className="form-radio-presto"
                                                    />
                                                    <label htmlFor={`enviar_reparo_a-${item.code}`}>
                                                        {item.description}
                                                    </label>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                            <div className="flex flex-col gap-1 md:col-span-3">
                                <label className="font-semibold text-sm">
                                    Observaciones
                                </label>
                                <InputTextarea
                                    value={form.observaciones ?? ""}
                                    onChange={(e) => updateField("observaciones", e.target.value)}
                                    rows={4}
                                    maxLength={1000}
                                    className="form-textarea-presto w-full"
                                    disabled={isDisabled}
                                    placeholder="Ingrese observaciones (máximo 1000 caracteres)"
                                    style={{ resize: "none" }}
                                />
                                <div className="flex justify-end mt-1 text-xs">
                                    <span className={
                                        (form.observaciones?.length ?? 0) >= 1000 
                                            ? "text-red-600" 
                                            : (form.observaciones?.length ?? 0) >= 900 
                                                ? "text-orange-500" 
                                                : "text-gray-500"
                                    }>
                                        {form.observaciones?.length ?? 0}
                                    </span>
                                    <span className="mx-1 text-gray-500">/</span>
                                    <span className="text-gray-500">1000</span>
                                </div>
                            </div>
                        </div>

                        <ActivityActionBar
                            from_tracking={fromTracking}
                            is_busy={isBusy}
                            is_disabled={isDisabled}
                            can_advance={canAdvance}
                            is_saving={saveMutation.isPending}
                            is_advancing={avanzarMutation.isPending}
                            on_edit={handleEditar}
                            on_save={handleGuardar}
                            on_advance={handleAvanzar}
                            on_exit={handleSalir}
                        />
                    </Card>
                </AccordionTab>
            </Accordion>
        </>
    );
}