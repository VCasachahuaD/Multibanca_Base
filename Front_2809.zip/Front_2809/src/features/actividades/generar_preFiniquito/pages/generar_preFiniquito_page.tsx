import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Card } from "primereact/card";
import { Button } from "primereact/button";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";

import type { GenerarPreFiniquito } from "../models/generar_preFiniquito";
import { useGenerarPreFiniquito } from "../hooks/useGenerarPreFiniquito";
import { useUpsertGenerarPreFiniquito } from "../hooks/useUpsertGenerarPreFiniquito";
import { useAvanzarGenerarPreFiniquito } from "../hooks/useAvanzarGenerarPreFiniquito";

import { Accordion, AccordionTab } from "primereact/accordion";
import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const ACTIVITY_ID = '_K1qZdF5uEerMb7_Y9wL3x';

const buildInitialState = (id_expediente: number): GenerarPreFiniquito => ({
  id_generar_prefiniquito: 0,
  id_expediente,
  observaciones: "",
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: new Date().toISOString(),
  modified_by: null,
  modified_date: null,
});

const normalizeGenerarPreFiniquito = (
  source: Partial<GenerarPreFiniquito> | null | undefined,
  id_expediente_fallback: number,
): GenerarPreFiniquito => {
  return {
    id_generar_prefiniquito: Number(source?.id_generar_prefiniquito ?? 0),
    id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    observaciones: source?.observaciones ?? "",
    is_active: source?.is_active ?? true,
    row_status: source?.row_status ?? true,
    created_by: Number(source?.created_by ?? 0),
    created_date: source?.created_date ?? new Date().toISOString(),
    modified_by: source?.modified_by ?? null,
    modified_date: source?.modified_date ?? null,
  };
};

export default function GenerarPreFiniquitoPage() {
  const toast = useRef<Toast>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: idExpedienteParam } = useParams();
  const { fromTracking = false } = location.state || {};
  const id_expediente = Number(idExpedienteParam ?? 0);

  const [form, setForm] = useState<GenerarPreFiniquito>(buildInitialState(id_expediente));
  const [isDisabled, setIsDisabled] = useState(true); 
  const [canAdvance, setCanAdvance] = useState(false);
  const [isBusy, setIsBusy] = useState(false);

  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef<number>(id_expediente);

  const { data, isLoading } = useGenerarPreFiniquito(id_expediente);
  const saveMutation = useUpsertGenerarPreFiniquito();
  const avanzarMutation = useAvanzarGenerarPreFiniquito();

  useEffect(() => {
    if (currentExpedienteRef.current !== id_expediente) {
      currentExpedienteRef.current = id_expediente;
      hasHydratedRef.current = false;
      setForm(buildInitialState(id_expediente));
      setIsDisabled(true);
      setCanAdvance(false);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (data?.status && data.detail) {
      setForm(normalizeGenerarPreFiniquito(data.detail, id_expediente));
      setIsDisabled(true);   
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (!id_expediente || id_expediente <= 0) {
      setForm(buildInitialState(0));
      setIsDisabled(false);  
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (data) {
      setForm((prev) => normalizeGenerarPreFiniquito({ ...prev, id_expediente }, id_expediente));
      setIsDisabled(false);  
      setCanAdvance(false);
      hasHydratedRef.current = true;
    }
  }, [data, id_expediente]);

  const handleEditar = () => {
    setIsDisabled(false);
    setCanAdvance(false);
  };

  const handleGuardar = async () => {
    try {
      setIsBusy(true);
      const payload = normalizeGenerarPreFiniquito(
        { ...form, id_expediente: id_expediente },
        id_expediente,
      );
      const response = await saveMutation.mutateAsync(payload);
      if (response.status) {
        toast.current?.show({ severity: "success", summary: "Éxito", detail: "Pre Finiquito guardado correctamente", life: 3000 });
        setForm(normalizeGenerarPreFiniquito(response.detail ?? payload, payload.id_expediente));
        setIsDisabled(true);
        setCanAdvance(true);
        hasHydratedRef.current = true;
      } else {
        toast.current?.show({ severity: "warn", summary: "Atención", detail: response.message || "No se pudo guardar", life: 3000 });
      }
    } catch {
      toast.current?.show({ severity: "error", summary: "Error", detail: "Ocurrió un error al guardar", life: 3000 });
    } finally {
      setIsBusy(false);
    }
  };

  const handleAvanzar = async () => {
    const expedienteId = Number(form.id_expediente ?? 0);
    if (!expedienteId || expedienteId <= 0) {
      toast.current?.show({ severity: "warn", summary: "Validación", detail: "No existe un id_expediente válido para avanzar.", life: 3000 });
      return;
    }
    try {
      setIsBusy(true);
      const response = await avanzarMutation.mutateAsync(expedienteId);
      if (response.status) {
        toast.current?.show({ severity: "success", summary: "Éxito", detail: "Actividad avanzada correctamente", life: 2000 });
        navigate("/home/bandeja");
      } else {
        toast.current?.show({ severity: "warn", summary: "Atención", detail: response.message || "No se pudo avanzar.", life: 3000 });
      }
    } catch {
      toast.current?.show({ severity: "error", summary: "Error", detail: "Ocurrió un error al avanzar.", life: 3000 });
    } finally {
      setIsBusy(false);
    }
  };

  const handleSalir = () => navigate("/home/bandeja");

  return (
    <>
      <Toast ref={toast} />
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Generar Pre Finiquito</h2>

      <Accordion activeIndex={[0, 2]} multiple>
        <AccordionTab
          disabled={!id_expediente || id_expediente <= 0}
          header="Información del Expediente"
        >
          <EncabezadoActividad
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            activityID={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab
          header="Funciones Transversales"
          disabled={!id_expediente || id_expediente <= 0}
        >
          <FuncionesTransversales
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            idActividad={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header="Generar Pre Finiquito">
          <Card className="w-full shadow-md card-presto-form mb-6">
            {isLoading && id_expediente > 0 && (
              <div className="mb-4 text-sm text-blue-600">Cargando información...</div>
            )}
            <div className="grid grid-cols-1 gap-5">
  <div className="flex flex-col gap-1">
    <label className="font-semibold text-sm">Observaciones</label>
    <InputTextarea
      value={form.observaciones ?? ""}
      onChange={(e) => setForm((prev) => ({ ...prev, observaciones: e.target.value }))}
      rows={4}
      maxLength={1000}
      className="form-textarea-presto w-full"
      disabled={isDisabled}
      placeholder="Ingrese observaciones (máximo 1000 caracteres)"
      style={{ resize: "none" }}
    />
    <div className="flex justify-end mt-1 text-xs">
      <span className={
        (form.observaciones?.length ?? 0) >= 1000 
          ? "text-red-600" 
          : (form.observaciones?.length ?? 0) >= 900 
            ? "text-orange-500" 
            : "text-gray-500"
      }>
        {form.observaciones?.length ?? 0}
      </span>
      <span className="mx-1 text-gray-500">/</span>
      <span className="text-gray-500">1000</span>
    </div>
  </div>
</div>
            <ActivityActionBar
              from_tracking={fromTracking}
              is_busy={isBusy}
              is_disabled={isDisabled}
              can_advance={canAdvance}
              is_saving={saveMutation.isPending}
              is_advancing={avanzarMutation.isPending}
              on_edit={handleEditar}
              on_save={handleGuardar}
              on_advance={handleAvanzar}
              on_exit={handleSalir}
            />
          </Card>
        </AccordionTab>
      </Accordion>
    </>
  );
}