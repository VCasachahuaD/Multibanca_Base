import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Card } from "primereact/card";
import { InputText } from "primereact/inputtext";
import { InputTextarea } from "primereact/inputtextarea";
import { Checkbox } from "primereact/checkbox";
import { Toast } from "primereact/toast";
import { Message } from "primereact/message";
import ActivityActionBar from "@/shared/components/activity/ActivityActionBar";
import { ProgressSpinner } from "primereact/progressspinner";

import type { GenerarFiniquito } from "../models/generar_finiquito";
import { useGenerarFiniquito } from "../hooks/useGenerarFiniquito";
import { useUpsertGenerarFiniquito } from "../hooks/useUpsertGenerarFiniquito";
import { useAvanzarGenerarFiniquito } from "../hooks/useAvanzarGenerarFiniquito";

import { Accordion, AccordionTab } from "primereact/accordion";
import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";

const ACTIVITY_ID = "_Ym6W_T2dNebVw9_D1aU8h";

const buildInitialState = (id_expediente: number): GenerarFiniquito => ({
  id_generar_finiquito: 0,
  id_expediente,
  tipo_tasacion: "",
  fojas_propiedad: "",
  numero_propiedad: "",
  año_propiedad: "",
  fojas_hipoteca: "",
  numero_hipoteca: "",
  año_hipoteca: "",
  fojas_prohibicion: "",
  numero_prohibicion: "",
  año_prohibicion: "",
  fojas_hipoteca_2grado: "",
  numero_hipoteca_2grado: "",
  año_hipoteca_2grado: "",
  observaciones: "",
  tipo_propiedad: "",
  direccion: "",
  comuna: "",
  rol_avaluo: "",
  fecha_informe_tasacion: null,
  fecha_solicitud_tasacion: null,
  fecha_recepcion_tasacion: null,
  display_incompleto: false,
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: new Date().toISOString(),
  modified_by: null,
  modified_date: null,
});

const normalizeGenerarFiniquito = (
  source: Partial<GenerarFiniquito> | null | undefined,
  id_expediente_fallback: number,
): GenerarFiniquito => {
  const isExistingRecord = Number(source?.id_generar_finiquito ?? 0) > 0;
  
  return {
    id_generar_finiquito: Number(source?.id_generar_finiquito ?? 0),
    id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    tipo_tasacion: source?.tipo_tasacion ?? "",
    fojas_propiedad: source?.fojas_propiedad ?? "",
    numero_propiedad: source?.numero_propiedad ?? "",
    año_propiedad: source?.año_propiedad ?? "",
    fojas_hipoteca: source?.fojas_hipoteca ?? "",
    numero_hipoteca: source?.numero_hipoteca ?? "",
    año_hipoteca: source?.año_hipoteca ?? "",
    fojas_prohibicion: source?.fojas_prohibicion ?? "",
    numero_prohibicion: source?.numero_prohibicion ?? "",
    año_prohibicion: source?.año_prohibicion ?? "",
    fojas_hipoteca_2grado: source?.fojas_hipoteca_2grado ?? "",
    numero_hipoteca_2grado: source?.numero_hipoteca_2grado ?? "",
    año_hipoteca_2grado: source?.año_hipoteca_2grado ?? "",
    observaciones: source?.observaciones ?? "",
    tipo_propiedad: source?.tipo_propiedad ?? "",
    direccion: source?.direccion ?? "",
    comuna: source?.comuna ?? "",
    rol_avaluo: source?.rol_avaluo ?? "",
    fecha_informe_tasacion: source?.fecha_informe_tasacion ?? null,
    fecha_solicitud_tasacion: source?.fecha_solicitud_tasacion ?? null,
    fecha_recepcion_tasacion: source?.fecha_recepcion_tasacion ?? null,
    display_incompleto: source?.display_incompleto ?? false,
    is_active: isExistingRecord ? (source?.is_active ?? false) : true,
    row_status: isExistingRecord ? (source?.row_status ?? false) : true,
    created_by: Number(source?.created_by ?? 0),
    created_date: source?.created_date ?? new Date().toISOString(),
    modified_by: source?.modified_by ?? null,
    modified_date: source?.modified_date ?? null,
  };
};

export default function GenerarFiniquitoPage() {
  const toast = useRef<Toast>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: idExpedienteParam } = useParams();
  const { fromTracking = false } = location.state || {};
  const id_expediente = Number(idExpedienteParam ?? 0);
  const hasValidExpediente = id_expediente > 0;

  const [form, setForm] = useState<GenerarFiniquito>(buildInitialState(id_expediente));
  const [isDisabled, setIsDisabled] = useState(true);
  const [canAdvance, setCanAdvance] = useState(false);
  const [isBusy, setIsBusy] = useState(false);
  const [aplicaProhibicion, setAplicaProhibicion] = useState(false);
  const [aplicaHipoteca2Grado, setAplicaHipoteca2Grado] = useState(false);

  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef<number>(id_expediente);
  const isAfterSaveRef = useRef(false);

  const { data, isLoading, refetch } = useGenerarFiniquito(id_expediente);
  const saveMutation = useUpsertGenerarFiniquito();
  const avanzarMutation = useAvanzarGenerarFiniquito();

  useEffect(() => {
    if (currentExpedienteRef.current !== id_expediente) {
      currentExpedienteRef.current = id_expediente;
      hasHydratedRef.current = false;
      setForm(buildInitialState(id_expediente));
      setIsDisabled(true);
      setCanAdvance(false);
      setAplicaProhibicion(false);
      setAplicaHipoteca2Grado(false);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (data?.status && data.detail) {
      const loaded = normalizeGenerarFiniquito(data.detail, id_expediente);
      setForm(loaded);
      setAplicaProhibicion(
        !!(loaded.fojas_prohibicion || loaded.numero_prohibicion || loaded.año_prohibicion),
      );
      setAplicaHipoteca2Grado(
        !!(
          loaded.fojas_hipoteca_2grado ||
          loaded.numero_hipoteca_2grado ||
          loaded.año_hipoteca_2grado
        ),
      );
      setIsDisabled(true);

      if (isAfterSaveRef.current) {
        setCanAdvance(true);
        isAfterSaveRef.current = false;
      } else {
        setCanAdvance(false);
      }
      
      hasHydratedRef.current = true;
      return;
    }

    if (!hasValidExpediente) {
      setForm(buildInitialState(0));
      setIsDisabled(false);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (data) {
      setForm((prev) => normalizeGenerarFiniquito({ ...prev, id_expediente }, id_expediente));
      setIsDisabled(false);
      setCanAdvance(false);
      hasHydratedRef.current = true;
    }
  }, [data, id_expediente, hasValidExpediente]);

  const updateField = (field: keyof GenerarFiniquito, value: GenerarFiniquito[keyof GenerarFiniquito]) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleToggleProhibicion = (checked: boolean) => {
    setAplicaProhibicion(checked);
  };

  const handleToggleHipoteca2Grado = (checked: boolean) => {
    setAplicaHipoteca2Grado(checked);
  };

  const validateFojasNumero = (
    label: string,
    fojas: string | null | undefined,
    numero: string | null | undefined,
  ): string => {
    if (!fojas?.trim()) return `Debe ingresar Fojas de ${label}.`;
    if (fojas.trim().length > 50) return `Fojas de ${label} no debe superar 50 caracteres.`;
    if (!numero?.trim()) return `Debe ingresar Número de ${label}.`;
    if (numero.trim().length > 50) return `Número de ${label} no debe superar 50 caracteres.`;
    return "";
  };

  const validateAño = (label: string, año: string | null | undefined): string => {
    if (!año?.trim()) return `Debe ingresar Año de ${label}.`;
    if (!/^\d{4}$/.test(año.trim())) return `Año de ${label} debe tener 4 dígitos.`;
    const yearNum = Number(año.trim());
    const currentYear = new Date().getFullYear();
    if (yearNum < 1900 || yearNum > currentYear) {
      return `Año de ${label} debe estar entre 1900 y ${currentYear}.`;
    }
    return "";
  };

  const validate_form = (): string => {
    let msg = validateFojasNumero("Propiedad", form.fojas_propiedad, form.numero_propiedad);
    if (msg) return msg;
    msg = validateAño("Propiedad", form.año_propiedad);
    if (msg) return msg;

    msg = validateFojasNumero("Hipoteca 1er Grado", form.fojas_hipoteca, form.numero_hipoteca);
    if (msg) return msg;
    msg = validateAño("Hipoteca 1er Grado", form.año_hipoteca);
    if (msg) return msg;

    if (aplicaProhibicion) {
      msg = validateFojasNumero("Prohibición", form.fojas_prohibicion, form.numero_prohibicion);
      if (msg) return msg;
      msg = validateAño("Prohibición", form.año_prohibicion);
      if (msg) return msg;
    }

    if (aplicaHipoteca2Grado) {
      msg = validateFojasNumero(
        "Hipoteca 2do Grado",
        form.fojas_hipoteca_2grado,
        form.numero_hipoteca_2grado,
      );
      if (msg) return msg;
      msg = validateAño("Hipoteca 2do Grado", form.año_hipoteca_2grado);
      if (msg) return msg;
    }

    if ((form.observaciones?.length ?? 0) > 1000) {
      return "Observaciones no debe superar 1000 caracteres.";
    }

    return "";
  };

  const handleEditar = () => {
    setIsDisabled(false);
    setCanAdvance(false);
  };

  const handleGuardar = async () => {

    const validationMessage = validate_form();
    if (validationMessage) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: validationMessage,
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);
      const normalized = normalizeGenerarFiniquito(
        { ...form, id_expediente: id_expediente },
        id_expediente,
      );
      const payload: GenerarFiniquito = {
        ...normalized,
        fojas_prohibicion: aplicaProhibicion ? normalized.fojas_prohibicion : null,
        numero_prohibicion: aplicaProhibicion ? normalized.numero_prohibicion : null,
        año_prohibicion: aplicaProhibicion ? normalized.año_prohibicion : null,
        fojas_hipoteca_2grado: aplicaHipoteca2Grado ? normalized.fojas_hipoteca_2grado : null,
        numero_hipoteca_2grado: aplicaHipoteca2Grado ? normalized.numero_hipoteca_2grado : null,
        año_hipoteca_2grado: aplicaHipoteca2Grado ? normalized.año_hipoteca_2grado : null,
      };
      const response = await saveMutation.mutateAsync(payload);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Generar Finiquito guardado correctamente",
          life: 3000,
        });

        isAfterSaveRef.current = true;
        
        await refetch();
        hasHydratedRef.current = false;
        
        setIsDisabled(true);
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: response.message || "No se pudo guardar",
          life: 3000,
        });
      }
    } catch (error) {
      console.error("Error al guardar:", error);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Ocurrió un error al guardar",
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleAvanzar = async () => {
    const expedienteId = Number(form.id_expediente ?? 0);
    if (!expedienteId || expedienteId <= 0) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: "No existe un id_expediente válido para avanzar.",
        life: 3000,
      });
      return;
    }

    if (!canAdvance) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: "Debe guardar los cambios antes de avanzar.",
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);
      const response = await avanzarMutation.mutateAsync(expedienteId);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Actividad avanzada correctamente",
          life: 2000,
        });
        navigate("/home/bandeja");
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: response.message || "No se pudo avanzar.",
          life: 3000,
        });
      }
    } catch (error) {
      console.error("Error al avanzar:", error);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Ocurrió un error al avanzar.",
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleSalir = () => {
    navigate("/home/bandeja");
  };

  const formatDate = (dateStr: string | null | undefined): string => {
    if (!dateStr) return "-";
    return new Date(dateStr).toLocaleDateString("es-CL");
  };

  if (isLoading && hasValidExpediente) {
    return (
      <div className="flex justify-center items-center h-64">
        <ProgressSpinner />
      </div>
    );
  }

  return (
    <div>
      <Toast ref={toast} />
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Generar Finiquito</h2>

      <Accordion multiple activeIndex={[0, 1, 2]}>
        <AccordionTab header="Información del Expediente" disabled={!hasValidExpediente}>
          <EncabezadoActividad idExpediente={id_expediente} activityID={ACTIVITY_ID} />
        </AccordionTab>

        <AccordionTab header="Funciones Transversales" disabled={!hasValidExpediente}>
          <FuncionesTransversales idExpediente={id_expediente} idActividad={ACTIVITY_ID} />
        </AccordionTab>

        <AccordionTab header="Generar Finiquito" disabled={!hasValidExpediente}>
          {!hasValidExpediente ? (
            <Card>
              <div className="text-center text-600">
                No se recibió un expediente válido para esta actividad.
              </div>
            </Card>
          ) : (
            <Card className="w-full shadow-md card-presto-form mb-6">
              {form.display_incompleto && (
                <Message
                  severity="info"
                  className="w-full mb-4"
                  text="Algunos datos de propiedad/tasación no están disponibles."
                />
              )}
             <div className="w-full overflow-x-auto generar-finiquito-table-container">
                <table className="w-full border-collapse generar-finiquito-table">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200">Datos Propiedad</th>
                      <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200">Datos Tasación</th>
                      <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200">Propiedad</th>
                      <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200">Hipoteca</th>
                      <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200">Prohibición</th>
                      <th className="px-3 py-2 text-sm font-semibold text-gray-700 border border-gray-200">Hipoteca 2do Grado</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="bg-white align-top">
                      <td className="px-3 py-2 text-sm border border-gray-200" data-label="Datos Propiedad">
                        <div><strong>Tipo:</strong> {form.tipo_propiedad || "No disponible"}</div>
                        <div><strong>Dirección:</strong> {form.direccion || "No disponible"}</div>
                        <div><strong>Rol Avalúo:</strong> {form.rol_avaluo || "No disponible"}</div>
                        <div><strong>Comuna:</strong> {form.comuna || "No disponible"}</div>
                      </td>

                      <td className="px-3 py-2 text-sm border border-gray-200" data-label="Datos Tasación">
                        <div><strong>Tipo Tasación:</strong> {form.tipo_tasacion || "No disponible"}</div>
                        <div><strong>Fecha Informe:</strong> {formatDate(form.fecha_informe_tasacion)}</div>
                        <div><strong>Fecha Solicitud:</strong> {formatDate(form.fecha_solicitud_tasacion)}</div>
                        <div><strong>Fecha Recepción:</strong> {formatDate(form.fecha_recepcion_tasacion)}</div>
                      </td>

                      <td className="px-3 py-2 text-sm border border-gray-200" data-label="Propiedad">
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Fojas</label>
                          <InputText value={form.fojas_propiedad} onChange={(e) => updateField("fojas_propiedad", e.target.value)} disabled={isDisabled} className="form-input-presto w-full mt-1" />
                        </div>
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Número</label>
                          <InputText value={form.numero_propiedad} onChange={(e) => updateField("numero_propiedad", e.target.value)} disabled={isDisabled} className="form-input-presto w-full mt-1" />
                        </div>
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Año</label>
                          <InputText value={form.año_propiedad} onChange={(e) => updateField("año_propiedad", e.target.value)} disabled={isDisabled} className="form-input-presto w-full mt-1" />
                        </div>
                      </td>

                      <td className="px-3 py-2 text-sm border border-gray-200" data-label="Hipoteca">
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Fojas</label>
                          <InputText value={form.fojas_hipoteca} onChange={(e) => updateField("fojas_hipoteca", e.target.value)} disabled={isDisabled} className="form-input-presto w-full mt-1" />
                        </div>
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Número</label>
                          <InputText value={form.numero_hipoteca} onChange={(e) => updateField("numero_hipoteca", e.target.value)} disabled={isDisabled} className="form-input-presto w-full mt-1" />
                        </div>
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Año</label>
                          <InputText value={form.año_hipoteca} onChange={(e) => updateField("año_hipoteca", e.target.value)} disabled={isDisabled} className="form-input-presto w-full mt-1" />
                        </div>
                      </td>

                      <td className="px-3 py-2 text-sm border border-gray-200" data-label="Prohibición">
                        <div className="mb-2 flex items-center gap-2">
                          <Checkbox
                            inputId="aplica_prohibicion"
                            checked={aplicaProhibicion}
                            onChange={(e) => handleToggleProhibicion(!!e.checked)}
                            disabled={isDisabled}
                          />
                          <label htmlFor="aplica_prohibicion" className="font-semibold text-xs">
                            ¿Tiene Prohibición?
                          </label>
                        </div>
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Fojas</label>
                          <InputText value={form.fojas_prohibicion ?? ""} onChange={(e) => updateField("fojas_prohibicion", e.target.value)} disabled={isDisabled || !aplicaProhibicion} className="form-input-presto w-full mt-1" />
                        </div>
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Número</label>
                          <InputText value={form.numero_prohibicion ?? ""} onChange={(e) => updateField("numero_prohibicion", e.target.value)} disabled={isDisabled || !aplicaProhibicion} className="form-input-presto w-full mt-1" />
                        </div>
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Año</label>
                          <InputText value={form.año_prohibicion ?? ""} onChange={(e) => updateField("año_prohibicion", e.target.value)} disabled={isDisabled || !aplicaProhibicion} className="form-input-presto w-full mt-1" />
                        </div>
                      </td>

                      <td className="px-3 py-2 text-sm border border-gray-200" data-label="Hipoteca 2do Grado">
                        <div className="mb-2 flex items-center gap-2">
                          <Checkbox
                            inputId="aplica_hipoteca_2grado"
                            checked={aplicaHipoteca2Grado}
                            onChange={(e) => handleToggleHipoteca2Grado(!!e.checked)}
                            disabled={isDisabled}
                          />
                          <label htmlFor="aplica_hipoteca_2grado" className="font-semibold text-xs">
                            ¿Tiene Hipoteca 2do Grado?
                          </label>
                        </div>
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Fojas</label>
                          <InputText value={form.fojas_hipoteca_2grado ?? ""} onChange={(e) => updateField("fojas_hipoteca_2grado", e.target.value)} disabled={isDisabled || !aplicaHipoteca2Grado} className="form-input-presto w-full mt-1" />
                        </div>
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Número</label>
                          <InputText value={form.numero_hipoteca_2grado ?? ""} onChange={(e) => updateField("numero_hipoteca_2grado", e.target.value)} disabled={isDisabled || !aplicaHipoteca2Grado} className="form-input-presto w-full mt-1" />
                        </div>
                        <div className="mb-2">
                          <label className="font-semibold text-xs">Año</label>
                          <InputText value={form.año_hipoteca_2grado ?? ""} onChange={(e) => updateField("año_hipoteca_2grado", e.target.value)} disabled={isDisabled || !aplicaHipoteca2Grado} className="form-input-presto w-full mt-1" />
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="mt-6">
                <label className="font-semibold text-sm">Observaciones</label>
                <InputTextarea
                  value={form.observaciones ?? ""}
                  onChange={(e) => updateField("observaciones", e.target.value)}
                  rows={4}
                  maxLength={1000}
                  disabled={isDisabled}
                  placeholder="Ingrese observaciones (máximo 1000 caracteres)"
                  className="form-textarea-presto w-full"
                  style={{ resize: "none" }}
                />
                <div className="flex justify-end mt-1 text-xs">
                  <span className={
                    (form.observaciones?.length ?? 0) >= 1000 
                      ? "text-red-600" 
                      : (form.observaciones?.length ?? 0) >= 900 
                        ? "text-orange-500" 
                        : "text-gray-500"
                  }>
                    {form.observaciones?.length ?? 0}
                  </span>
                  <span className="mx-1 text-gray-500">/</span>
                  <span className="text-gray-500">1000</span>
                </div>
              </div>

              <ActivityActionBar
                from_tracking={fromTracking}
                is_busy={isBusy}
                is_disabled={isDisabled}
                can_advance={canAdvance}
                is_saving={saveMutation.isPending}
                is_advancing={avanzarMutation.isPending}
                on_edit={handleEditar}
                on_save={handleGuardar}
                on_advance={handleAvanzar}
                on_exit={handleSalir}
              />
            </Card>
          )}
        </AccordionTab>
      </Accordion>
    </div>
  );
}
