import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { Accordion, AccordionTab } from "primereact/accordion";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Dropdown, DropdownChangeEvent } from "primereact/dropdown";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";

import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";
import { useAsignarEstudioTitulos } from "../hooks/useAsignarEstudioTitulos";
import { useAvanzarAsignarEstudioTitulos } from "../hooks/useAvanzarAsignarEstudioTitulos";
import { useCatalogoAbogado } from "../hooks/useCatalogoAbogado";
import { useUpsertAsignarEstudioTitulos } from "../hooks/useUpsertAsignarEstudioTitulos";
import type { AsignarEstudioTitulos } from "../models/asignar_estudio_titulos";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const ACTIVITY_ID = "_R2kWdF8sEedMu7_Z6pT3x";

const buildInitialState = (id_expediente: number): AsignarEstudioTitulos => ({
  id_asignar_estudio_titulos: 0,
  id_expediente,
  id_actividad: ACTIVITY_ID,
  abogado: "",
  observaciones: "",
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: new Date().toISOString(),
  modified_by: null,
  modified_date: null,
});

const normalizeAsignarEstudioTitulos = (
  source: Partial<AsignarEstudioTitulos> | null | undefined,
  id_expediente_fallback: number,
): AsignarEstudioTitulos => {
  return {
    id_asignar_estudio_titulos: Number(source?.id_asignar_estudio_titulos ?? 0),
    id_expediente: Number(source?.id_expediente ?? id_expediente_fallback ?? 0),
    id_actividad: ACTIVITY_ID,
    abogado: source?.abogado ?? "",
    observaciones: source?.observaciones ?? "",
    is_active: source?.is_active ?? true,
    row_status: source?.row_status ?? true,
    created_by: Number(source?.created_by ?? 0),
    created_date: source?.created_date ?? new Date().toISOString(),
    modified_by: source?.modified_by ?? null,
    modified_date: source?.modified_date ?? null,
  };
};

export default function AsignarEstudioTitulosPage() {
  const toast = useRef<Toast>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: idExpedienteParam } = useParams();
  const { fromTracking = false } = location.state || {};

  const id_expediente = Number(idExpedienteParam ?? 0);

  const [form, setForm] = useState<AsignarEstudioTitulos>(
    buildInitialState(id_expediente),
  );
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [isDisabled, setIsDisabled] = useState(true);
  const [isBusy, setIsBusy] = useState(false);

  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef<number>(id_expediente);

  const { data, isLoading } = useAsignarEstudioTitulos(id_expediente);
  const { data: catalogoAbogadoData } = useCatalogoAbogado();
  const saveMutation = useUpsertAsignarEstudioTitulos();
  const avanzarMutation = useAvanzarAsignarEstudioTitulos();

  const abogadoOptions = useMemo(() => {
    return catalogoAbogadoData?.detail ?? [];
  }, [catalogoAbogadoData]);

  useEffect(() => {
    if (currentExpedienteRef.current !== id_expediente) {
      currentExpedienteRef.current = id_expediente;
      hasHydratedRef.current = false;

      setForm(buildInitialState(id_expediente));
      setErrorMessage("");
      setSuccessMessage("");
      setIsDisabled(true);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (data?.status && data.detail) {
      const loadedEntity = normalizeAsignarEstudioTitulos(data.detail, id_expediente);

      setForm(loadedEntity);
      setIsDisabled(true);
      hasHydratedRef.current = true;
      return;
    }

    if (data) {
      setForm((prev) =>
        normalizeAsignarEstudioTitulos(
          {
            ...prev,
            id_expediente,
          },
          id_expediente,
        ),
      );
      setIsDisabled(true);
      hasHydratedRef.current = true;
    }
  }, [data, id_expediente]);

  const updateField = <K extends keyof AsignarEstudioTitulos>(
    field: K,
    value: AsignarEstudioTitulos[K],
  ) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleEditar = () => {
    setErrorMessage("");
    setSuccessMessage("");
    setIsDisabled(false);
  };

  const validateForm = () => {
    if (!form.id_expediente || form.id_expediente <= 0) {
      return "No existe un id_expediente válido.";
    }

    if (!form.abogado?.trim()) {
      return "Debe seleccionar abogado.";
    }

    if (!form.observaciones?.trim()) {
      return "Debe ingresar observaciones.";
    }

    return "";
  };

  const handleGuardar = async () => {
    setErrorMessage("");
    setSuccessMessage("");

    const validationMessage = validateForm();
    if (validationMessage) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: validationMessage,
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);

      const payload = normalizeAsignarEstudioTitulos(
        {
          ...form,
          id_expediente: Number(form.id_expediente || id_expediente || 0),
          id_actividad: ACTIVITY_ID,
        },
        id_expediente,
      );

      const response = await saveMutation.mutateAsync(payload);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Asignar Estudio de Títulos guardado correctamente",
          life: 3000,
        });

        const savedEntity = normalizeAsignarEstudioTitulos(
          response.detail ?? payload,
          payload.id_expediente,
        );

        setForm(savedEntity);
        setIsDisabled(true);
        hasHydratedRef.current = true;
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: response.message || "No se pudo guardar",
          life: 3000,
        });
      }
    } catch (error) {
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Ocurrió un error al guardar",
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleAvanzar = async () => {
    setErrorMessage("");
    setSuccessMessage("");

    if (!form.id_expediente || form.id_expediente <= 0) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: "No existe un id_expediente válido.",
        life: 3000,
      });
      return;
    }

    if (!form.id_asignar_estudio_titulos || form.id_asignar_estudio_titulos <= 0) {
      toast.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: "Debe guardar la actividad antes de avanzar.",
        life: 3000,
      });
      return;
    }

    try {
      setIsBusy(true);

      const response = await avanzarMutation.mutateAsync(form.id_expediente);

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Actividad avanzada correctamente",
          life: 2000,
        });
        navigate("/home/bandeja");
      } else {
        toast.current?.show({
          severity: "warn",
          summary: "Atención",
          detail: response.message || "No se pudo avanzar la actividad",
          life: 3000,
        });
      }
    } catch (error) {
      console.error("ERROR AVANZAR ASIGNAR ESTUDIO DE TITULOS", error);

      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Ocurrió un error al avanzar la actividad",
        life: 3000,
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleSalir = () => {
    navigate("/home/bandeja");
  };

  return (
    <>
      <Toast ref={toast} />

      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Asignar Estudio de Títulos
      </h2>

      <Accordion activeIndex={[0, 2]} multiple>
        <AccordionTab
          disabled={!id_expediente || id_expediente <= 0}
          header="Información del Expediente"
        >
          <EncabezadoActividad
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            activityID={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab
          header="Funciones Transversales"
          disabled={!id_expediente || id_expediente <= 0}
        >
          <FuncionesTransversales
            idExpediente={Number(form.id_expediente || id_expediente || 0)}
            idActividad={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header="Asignar Estudio de Títulos">
          <Card className="w-full shadow-md card-presto-form mb-6">
            {isLoading && id_expediente > 0 && (
              <div className="mb-4 text-sm text-blue-600">
                Cargando información...
              </div>
            )}

            <fieldset className="border border-gray-200 rounded-md p-4 mb-5">
              <legend className="px-2 text-sm font-semibold text-gray-700">
                ASIGNAR ABOGADO
              </legend>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="flex flex-col gap-1 md:col-span-1">
                  <label className="font-semibold text-sm">Abogado *</label>
                  <Dropdown
                    value={form.abogado}
                    options={abogadoOptions}
                    optionLabel="description"
                    optionValue="description"
                    onChange={(e: DropdownChangeEvent) =>
                      updateField("abogado", e.value)
                    }
                    placeholder="Seleccione abogado"
                    className="form-dropdown-presto w-full"
                    disabled={isDisabled}
                    filter
                    showClear
                  />
                </div>
              </div>
            </fieldset>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="flex flex-col gap-1 md:col-span-3">
                <label className="font-semibold text-sm">Observaciones *</label>
                <InputTextarea
                  value={form.observaciones ?? ""}
                  onChange={(e) => updateField("observaciones", e.target.value)}
                  rows={5}
                  maxLength={1000}
                  className="form-textarea-presto w-full"
                  disabled={isDisabled}
                  placeholder="Ingrese observaciones (máximo 1000 caracteres)"
                  style={{ resize: "none" }}
                />
                <div className="flex justify-end mt-1 text-xs">
                  <span className={
                    (form.observaciones?.length ?? 0) >= 1000 
                      ? "text-red-600" 
                      : (form.observaciones?.length ?? 0) >= 900 
                        ? "text-orange-500" 
                        : "text-gray-500"
                  }>
                    {form.observaciones?.length ?? 0}
                  </span>
                  <span className="mx-1 text-gray-500">/</span>
                  <span className="text-gray-500">1000</span>
                </div>
              </div>
            </div>

            <ActivityActionBar
              from_tracking={fromTracking}
              is_busy={isBusy}
              is_disabled={isDisabled}
              can_advance={true}
              is_saving={saveMutation.isPending}
              is_advancing={avanzarMutation.isPending}
              on_edit={handleEditar}
              on_save={handleGuardar}
              on_advance={handleAvanzar}
              on_exit={handleSalir}
            />
          </Card>
        </AccordionTab>
      </Accordion>
    </>
  );
}