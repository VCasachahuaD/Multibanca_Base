import { useMutation } from "@tanstack/react-query";
import type { ApiResponse } from "@/core/api/models/ApiResponse";
import { asignarEstudioTitulosService } from "../api/asignarEstudioTitulosService";

export function useAvanzarAsignarEstudioTitulos() {
  return useMutation<ApiResponse<boolean>, unknown, number>({
    mutationFn: (id_expediente) =>
      asignarEstudioTitulosService.avanzar(id_expediente),
  });
}
