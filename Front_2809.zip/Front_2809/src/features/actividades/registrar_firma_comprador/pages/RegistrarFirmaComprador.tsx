import type { ReactNode } from 'react';
import { useEffect, useRef, useState } from 'react';

import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import { Column } from 'primereact/column';
import { DataTable } from 'primereact/datatable';
import { InputTextarea } from 'primereact/inputtextarea';
import { Calendar } from 'primereact/calendar';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { Toast } from 'primereact/toast';
import { Accordion, AccordionTab } from 'primereact/accordion';
import EncabezadoActividad from '@/features/encabezado/pages/EncabezadoActividad';
import FuncionesTransversales from '@/features/funciones_transversales/pages/FuncionesTransversales';
import { useRegistrarFirmaComprador } from '../hooks/useRegistrarFirmaComprador';
import { useAvanzarRegistrarFirmaComprador } from '../hooks/useAvanzarRegistrarFirmaComprador';
import { useUpsertRegistrarFirmaComprador } from '../hooks/useUpsertRegistrarFirmaComprador';

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const renderResponsiveCell = (value: ReactNode, titulo: string) => <div data-titulo={titulo}>{value ?? ""}</div>;

type FirmaCompradorSelected = { observaciones: string };
type FirmaCompradorRow = {
  id_firma_comprador_detalle?: number;
  relacionTitular?: string | null;
  rut?: string | null;
  nombres?: string | null;
  apellidoPaterno?: string | null; 
  apellidoMaterno?: string | null;
  estadoCivil?: string | null;
  fechaFirma?: Date | null;
};

const ACTIVITY_ID = '_Ak3L_P8qTebYv7_D2nH5x';

type Props = {
  idExpediente?: number;
  idActividad?: string;
};

export default function RegistrarFirmaCompradorPage({
  idExpediente: idExpedienteProp,
  idActividad = ACTIVITY_ID,
}: Props) {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useRef<Toast>(null);
  const { id_expediente: idParam } = useParams();
  const { fromTracking = false } = location.state || {};

  const idExpediente = Number(idExpedienteProp ?? idParam ?? 0);
  const hasValidExpediente = idExpediente > 0;
  const resolvedActividadId = idActividad || ACTIVITY_ID;
  const [isDisabled, setIsDisabled] = useState(true);
  const [canAdvance, setCanAdvance] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef<number>(idExpediente);

  const avanzarMutation = useAvanzarRegistrarFirmaComprador();
  const {
    data: firmaData,
    isLoading,
  } = useRegistrarFirmaComprador(idExpediente);

  const isBusy = isSaving || isLoading;

  const [selected, setSelected] = useState<FirmaCompradorSelected>({
    observaciones: '',
  });

  const upsertMutation = useUpsertRegistrarFirmaComprador();

  const [rows, setRows] = useState<FirmaCompradorRow[]>([]);

  const showToast = (
    severity: 'success' | 'info' | 'warn' | 'error',
    summary: string,
    detail: string,
  ) => {
    toast.current?.show({
      severity,
      summary,
      detail,
      life: 3500,
    });
  };

  const handleEditar = () => {
    if (!hasValidExpediente) {
      showToast('warn', 'Validación', 'El expediente es obligatorio.');
      return;
    }

    setIsDisabled(false);
    setCanAdvance(false);
  };

  const handleGuardar = async () => {
    if (!hasValidExpediente) {
      showToast('warn', 'Validación', 'El expediente es obligatorio.');
      return;
    }

    if (!selected.observaciones?.trim()) {
      showToast('warn', 'Validación', 'Las observaciones son obligatorias.');
      return;
    }

    const invalidRow = rows.find((r) => !r.fechaFirma);

    if (invalidRow) {
      showToast(
        'warn',
        'Validación',
        'Todos los registros deben tener Fecha de Firma.'
      );
      return;
    }

    try {
      setIsSaving(true);

      const payload = {
        id_firma_comprador: firmaData?.detail?.id_firma_comprador ?? 0,
        id_expediente: idExpediente,
        observaciones: selected.observaciones ?? '',
        is_active: true,
        row_status: true,
        created_by: 1,
        created_date: new Date().toISOString(),

        firma_comprador_detalle: rows.map((r) => ({
          id_firma_comprador_detalle: r.id_firma_comprador_detalle ?? 0,
          id_firma_comprador: firmaData?.detail?.id_firma_comprador ?? 0,
          id_expediente: idExpediente,

          relacion_titular: r.relacionTitular ?? null,
          rut: r.rut,
          nombres: r.nombres,
          apellido_paterno: r.apellidoPaterno,
          apellido_materno: r.apellidoMaterno,
          estado_civil: r.estadoCivil,

          fecha_firma: r.fechaFirma
            ? new Date(
              r.fechaFirma.getFullYear(),
              r.fechaFirma.getMonth(),
              r.fechaFirma.getDate()
            ).toISOString()
            : null,

          is_active: true,
          row_status: true,
          created_by: 1,
          created_date: new Date().toISOString(),
        })),
      };

      await upsertMutation.mutateAsync(payload);

      setCanAdvance(true);
      setIsDisabled(true);

      showToast('success', 'OK', 'Guardado correctamente');
    } catch (error) {
      const message =
        error instanceof Error ? error.message : 'Error inesperado al guardar.';
      showToast('error', 'Error', message);
    } finally {
      setIsSaving(false);
    }
  };

  const handleAvanzar = async () => {
    if (!hasValidExpediente) {
      showToast('warn', 'Validación', 'El expediente es obligatorio.');
      return;
    }

    if (!resolvedActividadId) {
      showToast('warn', 'Validación', 'La actividad no tiene id de workflow válido.');
      return;
    }

    if (!canAdvance) {
      showToast('warn', 'Validación', 'Debe guardar los cambios antes de avanzar.');
      return;
    }

    try {

      const response = await avanzarMutation.mutateAsync(Number(idExpediente));

      if (response.status) {
        toast.current?.show({
          severity: "success",
          summary: "Éxito",
          detail: "Actividad avanzada correctamente",
          life: 2000,
        });

        navigate("/home/bandeja");
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Error inesperado al avanzar.';
      showToast('error', 'Error', message);
    }
  };

  const handleSalir = () => {
    navigate('/home/bandeja');
  };

  const updateField = (field: keyof FirmaCompradorSelected, value: string) => {
    setSelected((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  useEffect(() => {
    if (currentExpedienteRef.current !== idExpediente) {
      currentExpedienteRef.current = idExpediente;
      hasHydratedRef.current = false;
      setIsDisabled(true);
      setCanAdvance(false);
    }
  }, [idExpediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (firmaData?.detail) {
      const d = firmaData.detail;

      setSelected({
        observaciones: d.observaciones ?? '',
      });

      setRows(
        d.firma_comprador_detalle?.map((x) => ({
          id_firma_comprador_detalle: x.id_firma_comprador_detalle,
          relacionTitular: x.relacion_titular,
          rut: x.rut,
          nombres: x.nombres,
          apellidoPaterno: x.apellido_paterno,
          apellidoMaterno: x.apellido_materno,
          estadoCivil: x.estado_civil,
          fechaFirma: x.fecha_firma ? new Date(x.fecha_firma) : null,
        })) ?? []
      );

      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (firmaData) {
      setSelected({ observaciones: '' });
      setRows([]);
      setCanAdvance(false);
      hasHydratedRef.current = true;
    }
  }, [firmaData, idExpediente]);

  return (
    <div>
      <Toast ref={toast} />

      <Accordion multiple activeIndex={[0, 1, 2]}>
        <AccordionTab header="Información del Expediente" disabled={!hasValidExpediente}>
          <EncabezadoActividad idExpediente={idExpediente} activityID={resolvedActividadId} />
        </AccordionTab>

        <AccordionTab header="Funciones Transversales" disabled={!hasValidExpediente}>
          <FuncionesTransversales
            idExpediente={idExpediente}
            idActividad={resolvedActividadId}
          />
        </AccordionTab>

        <AccordionTab header="Registrar Firma Comprador">
          <Card
            title="Registrar Firma Comprador"
            className="shadow-sm border border-gray-200 rounded-xl"
          >
            <DataTable
              key={String(isDisabled)}
              value={rows}
              emptyMessage="No existen registros."
              stripedRows
              rowHover
              size="small"
              className="text-sm datatable-presto"
            >
              <Column field="relacionTitular" header="Relacion Titular" body={(row) => renderResponsiveCell(row.relacionTitular, "Relacion Titular: ")} />
              <Column field="rut" header="RUT" body={(row) => renderResponsiveCell(row.rut, "RUT: ")} />
              <Column field="nombres" header="Nombres" body={(row) => renderResponsiveCell(row.nombres, "Nombres: ")} />
              <Column field="apellidoPaterno" header="Apellido Paterno" body={(row) => renderResponsiveCell(row.apellidoPaterno, "Apellido Paterno: ")} />
              <Column field="apellidoMaterno" header="Apellido Materno" body={(row) => renderResponsiveCell(row.apellidoMaterno, "Apellido Materno: ")} />
              <Column field="estadoCivil" header="Estado Civil" body={(row) => renderResponsiveCell(row.estadoCivil, "Estado Civil: ")} />
              <Column
                header="Fecha de Firma"
                body={(rowData, options) => renderResponsiveCell(
                  <Calendar
                    value={rowData.fechaFirma}
                    onChange={(e) => {
                      const value = e.value ? new Date(e.value) : null;

                      setRows((prev) =>
                        prev.map((row, i) =>
                          i === options.rowIndex
                            ? { ...row, fechaFirma: value }
                            : { ...row }
                        )
                      );
                    }}
                    disabled={isDisabled}
                    showIcon
                    dateFormat="dd/mm/yy"
                    className="calendar-presto"
                  />,
                  "Fecha de Firma: "
                )}
              />
            </DataTable>

            <div className="flex flex-col gap-1 md:col-span-3">
              <label className="font-semibold text-sm">
                Observaciones
              </label>

              <InputTextarea
                rows={4}
                maxLength={1000}
                disabled={isDisabled}
                className="form-textarea-presto w-full"
                value={selected.observaciones ?? ""}
                onChange={(e) =>
                  updateField('observaciones', e.target.value)
                }
                placeholder="Ingrese observaciones (máximo 1000 caracteres)"
                style={{ resize: "none" }}
              />
              <div className="flex justify-end mt-1 text-xs">
                <span className={
                  (selected.observaciones?.length ?? 0) >= 1000 
                    ? "text-red-600" 
                    : (selected.observaciones?.length ?? 0) >= 900 
                      ? "text-orange-500" 
                      : "text-gray-500"
                }>
                  {selected.observaciones?.length ?? 0}
                </span>
                <span className="mx-1 text-gray-500">/</span>
                <span className="text-gray-500">1000</span>
              </div>
            </div>
          </Card>
          <ActivityActionBar
            from_tracking={fromTracking}
            is_busy={isBusy}
            is_disabled={isDisabled}
            can_advance={canAdvance && !!resolvedActividadId}
            is_saving={isSaving}
            is_advancing={avanzarMutation.isPending}
            on_edit={handleEditar}
            on_save={handleGuardar}
            on_advance={handleAvanzar}
            on_exit={handleSalir}
          />
        </AccordionTab>
      </Accordion>
    </div>
  );
}