export interface CalculoGeneracionDocumento {
  id_calculo_generacion_documento: number;
  id_expediente: number;

  // Cálculo y Generación Documento
  revision_rol_propiedad: 'ROL_INCORRECTO' | 'ACEPTAR' | null;
  valor_uf_fecha_hoy: number | null;
  fecha_calculo: string | null;
  valor_uf_fecha_calculo: number | null;
  is_enviar_reparo: boolean;
  observaciones: string | null;

  // Datos de la Propiedad (5.4.6)
  tipo_propiedad: string | null;
  estado: string | null;
  tipo_venta: string | null;
  tipo_construccion: string | null;
  tipo_direccion: string | null;
  direccion: string | null;
  villa_condominio: string | null;
  numero: string | null;
  numero_casa_habitantes: number | null;
  conjunto: string | null;
  manzana: string | null;
  lote: string | null;
  region: string | null;
  comuna: string | null;
  existe_rol_avaluo: string | null;
  rol_avaluo_1: string | null;
  rol_avaluo_2: string | null;
  valor_avaluo_pesos: number | null;

  is_active: boolean;
  row_status: boolean;
  created_by: number;
  created_date: string;
  modified_by: number | null;
  modified_date: string | null;
}
