import { useState, useEffect, useRef } from "react";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";
import { Toast } from "primereact/toast";

import PropiedadSection from "@/features/actividades/datos_operacion/components/PropiedadSection";
import type { CalculoGeneracionDocumento } from "../models/calculo_generacion_documento";
import type { ControlesPropiedad } from "../models/catalogo";
import {
  buildPropiedadEmpty,
  type DatosOperacionPropiedad,
} from "@/features/actividades/datos_operacion/models/datos_operacion";

const formToPropiedad = (form: CalculoGeneracionDocumento): DatosOperacionPropiedad => ({
  ...buildPropiedadEmpty(form.id_expediente),
  tipo_propiedad: form.tipo_propiedad ?? null,
  estado: form.estado ?? null,
  tipo_venta: form.tipo_venta ?? null,
  tipo_construccion: form.tipo_construccion ?? null,
  tipo_direccion: form.tipo_direccion ?? null,
  direccion: form.direccion ?? "",
  villa_condominio: form.villa_condominio ?? "",
  numero: form.numero ?? "",
  numero_casa_habitantes: form.numero_casa_habitantes ?? null,
  conjunto: form.conjunto ?? "",
  manzana: form.manzana ?? "",
  lote: form.lote ?? "",
  region: form.region ?? null,
  comuna: form.comuna ?? null,
  existe_rol_avaluo: form.existe_rol_avaluo ?? null,
  rol_avaluo_1: form.rol_avaluo_1 ?? "",
  rol_avaluo_2: form.rol_avaluo_2 ?? "",
  valor_avaluo_pesos: form.valor_avaluo_pesos ?? null,
});

const propiedadToForm = (
  form: CalculoGeneracionDocumento,
  p: DatosOperacionPropiedad,
): CalculoGeneracionDocumento => ({
  ...form,
  tipo_propiedad: p.tipo_propiedad ?? null,
  estado: p.estado ?? null,
  tipo_venta: p.tipo_venta ?? null,
  tipo_construccion: p.tipo_construccion ?? null,
  tipo_direccion: p.tipo_direccion ?? null,
  direccion: p.direccion ?? null,
  villa_condominio: p.villa_condominio ?? null,
  numero: p.numero ?? null,
  numero_casa_habitantes: p.numero_casa_habitantes ?? null,
  conjunto: p.conjunto ?? null,
  manzana: p.manzana ?? null,
  lote: p.lote ?? null,
  region: p.region ?? null,
  comuna: p.comuna ?? null,
  existe_rol_avaluo: p.existe_rol_avaluo ?? null,
  rol_avaluo_1: p.rol_avaluo_1 ?? null,
  rol_avaluo_2: p.rol_avaluo_2 ?? null,
  valor_avaluo_pesos: p.valor_avaluo_pesos ?? null,
});

interface EditarRolModalProps {
  visible: boolean;
  idExpediente: number;
  form: CalculoGeneracionDocumento;
  controles: ControlesPropiedad;
  onHide: () => void;
  onConfirm: (form: CalculoGeneracionDocumento) => void;
}

export default function EditarRolModal({
  visible,
  idExpediente,
  form,
  controles,
  onHide,
  onConfirm,
}: EditarRolModalProps) {
  const toastRef = useRef<Toast>(null);
  const [draft, setDraft] = useState<DatosOperacionPropiedad>(() =>
    formToPropiedad(form),
  );

  useEffect(() => {
    if (visible) {
      setDraft(formToPropiedad(form));
    }
  }, [visible, form]);

  const handleChange = <K extends keyof DatosOperacionPropiedad>(
    field: K,
    value: DatosOperacionPropiedad[K],
  ) => {
    setDraft((prev) => ({ ...prev, [field]: value }));
  };

  const validateDraft = (): string => {
    if (!draft.tipo_propiedad) return "Tipo de Propiedad es obligatorio.";
    if (!draft.estado) return "Estado es obligatorio.";
    if (!draft.tipo_venta) return "Tipo de Venta es obligatorio.";
    if (!draft.tipo_construccion) return "Tipo de Construcción es obligatorio.";
    if (!draft.tipo_direccion) return "Tipo de Dirección es obligatorio.";
    if (!draft.direccion?.trim()) return "Dirección es obligatoria.";
    if (!draft.villa_condominio?.trim()) return "Villa / Condominio es obligatorio.";
    if (!draft.numero?.trim()) return "Número es obligatorio.";
    if (draft.numero_casa_habitantes == null) return "N° Casa Habitantes es obligatorio.";
    if (!draft.conjunto?.trim()) return "Conjunto es obligatorio.";
    if (!draft.manzana?.trim()) return "Manzana es obligatoria.";
    if (!draft.lote?.trim()) return "Lote es obligatorio.";
    if (!draft.region) return "Región es obligatoria.";
    if (!draft.comuna) return "Comuna es obligatoria.";
    if (!draft.existe_rol_avaluo) return "¿Existe Rol Avalúo? es obligatorio.";

    if (draft.existe_rol_avaluo === "001") {
      if (!draft.rol_avaluo_1?.trim()) return "Rol Avalúo 1 es obligatorio.";
      if (!draft.rol_avaluo_2?.trim()) return "Rol Avalúo 2 es obligatorio.";
      if (
        draft.valor_avaluo_pesos === null ||
        draft.valor_avaluo_pesos === undefined ||
        draft.valor_avaluo_pesos <= 0
      ) {
        return "Valor Avalúo Pesos debe ser mayor a 0.";
      }
    }

    return "";
  };

  const handleAceptar = () => {
    const error = validateDraft();
    if (error) {
      toastRef.current?.show({
        severity: "warn",
        summary: "Validación",
        detail: error,
        life: 3000,
      });
      return;
    }

    onConfirm(propiedadToForm(form, draft));
    onHide();
  };

  const dialogFooter = (
    <div className="flex justify-end gap-2">
      <Button
        type="button"
        label="Cancelar"
        icon="pi pi-times"
        severity="secondary"
        outlined
        onClick={onHide}
      />
      <Button
        type="button"
        label="Aceptar"
        icon="pi pi-check"
        severity="success"
        onClick={handleAceptar}
      />
    </div>
  );

  return (
    <>
      <Toast ref={toastRef} />
      <Dialog
        header="Editar Datos de la Propiedad"
        visible={visible}
        onHide={onHide}
        modal
        dismissableMask={false}
        closeOnEscape={false}
        draggable={false}
        resizable={false}
        className="w-full md:w-10/12 lg:w-9/12"
        footer={dialogFooter}
      >
        <PropiedadSection
          value={draft}
          disabled={false}
          controles={controles}
          onChange={handleChange}
        />
      </Dialog>
    </>
  );
}
