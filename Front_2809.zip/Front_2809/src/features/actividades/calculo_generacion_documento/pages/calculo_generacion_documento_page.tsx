import { useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";

import { Accordion, AccordionTab } from "primereact/accordion";
import { Button } from "primereact/button";
import { Calendar } from "primereact/calendar";
import { Card } from "primereact/card";
import { Checkbox } from "primereact/checkbox";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { InputTextarea } from "primereact/inputtextarea";
import { RadioButton } from "primereact/radiobutton";
import { Toast } from "primereact/toast";

import EncabezadoActividad from "@/features/encabezado/pages/EncabezadoActividad";
import FuncionesTransversales from "@/features/funciones_transversales/pages/FuncionesTransversales";
import EditarRolModal from "../components/EditarRolModal";

import type { CalculoGeneracionDocumento } from "../models/calculo_generacion_documento";
import type { CatalogoOption, ControlesPropiedad } from "../models/catalogo";
import { EMPTY_CONTROLES_PROPIEDAD } from "../models/catalogo";
import { useCalculoGeneracionDocumento } from "../hooks/useCalculoGeneracionDocumento";
import { useControlesPropiedad } from "../hooks/useControlesPropiedad";
import { useUpsertCalculoGeneracionDocumento } from "../hooks/useUpsertCalculoGeneracionDocumento";
import { useAvanzarCalculoGeneracionDocumento } from "../hooks/useAvanzarCalculoGeneracionDocumento";
import { useCalcularUF } from "../hooks/useCalcularUF";
import { calculoGeneracionDocumentoService } from "../api/calculoGeneracionDocumentoService";

import ActivityActionBar from '@/shared/components/activity/ActivityActionBar';
const renderResponsiveCell = (value: ReactNode, titulo: string) => <div data-titulo={titulo}>{value ?? ""}</div>;

const ACTIVITY_ID = "_G2tHwN6yEekRf1_Z3vC8q";

const buildInitialState = (id_expediente: number): CalculoGeneracionDocumento => ({
  id_calculo_generacion_documento: 0,
  id_expediente,
  revision_rol_propiedad: null,
  valor_uf_fecha_hoy: null,
  fecha_calculo: null,
  valor_uf_fecha_calculo: null,
  is_enviar_reparo: false,
  observaciones: null,
  tipo_propiedad: null,
  estado: null,
  tipo_venta: null,
  tipo_construccion: null,
  tipo_direccion: null,
  direccion: null,
  villa_condominio: null,
  numero: null,
  numero_casa_habitantes: null,
  conjunto: null,
  manzana: null,
  lote: null,
  region: null,
  comuna: null,
  existe_rol_avaluo: null,
  rol_avaluo_1: null,
  rol_avaluo_2: null,
  valor_avaluo_pesos: null,
  is_active: true,
  row_status: true,
  created_by: 0,
  created_date: new Date().toISOString(),
  modified_by: null,
  modified_date: null,
});

const normalizeForm = (
  source: Partial<CalculoGeneracionDocumento> | null | undefined,
  id_expediente_fallback: number,
): CalculoGeneracionDocumento => ({
  id_calculo_generacion_documento: Number(source?.id_calculo_generacion_documento ?? 0),
  id_expediente: Number(source?.id_expediente ?? id_expediente_fallback),
  revision_rol_propiedad: source?.revision_rol_propiedad ?? null,
  valor_uf_fecha_hoy: source?.valor_uf_fecha_hoy ?? null,
  fecha_calculo: source?.fecha_calculo ?? null,
  valor_uf_fecha_calculo: source?.valor_uf_fecha_calculo ?? null,
  is_enviar_reparo: Boolean(source?.is_enviar_reparo ?? false),
  observaciones: source?.observaciones ?? null,
  tipo_propiedad: source?.tipo_propiedad ?? null,
  estado: source?.estado ?? null,
  tipo_venta: source?.tipo_venta ?? null,
  tipo_construccion: source?.tipo_construccion ?? null,
  tipo_direccion: source?.tipo_direccion ?? null,
  direccion: source?.direccion ?? null,
  villa_condominio: source?.villa_condominio ?? null,
  numero: source?.numero ?? null,
  numero_casa_habitantes: source?.numero_casa_habitantes ?? null,
  conjunto: source?.conjunto ?? null,
  manzana: source?.manzana ?? null,
  lote: source?.lote ?? null,
  region: source?.region ?? null,
  comuna: source?.comuna ?? null,
  existe_rol_avaluo: source?.existe_rol_avaluo ?? null,
  rol_avaluo_1: source?.rol_avaluo_1 ?? null,
  rol_avaluo_2: source?.rol_avaluo_2 ?? null,
  valor_avaluo_pesos: source?.valor_avaluo_pesos ?? null,
  is_active: source?.is_active ?? true,
  row_status: source?.row_status ?? true,
  created_by: Number(source?.created_by ?? 0),
  created_date: source?.created_date ?? new Date().toISOString(),
  modified_by: source?.modified_by ?? null,
  modified_date: source?.modified_date ?? null,
});

const toDate = (value?: string | null): Date | null => {
  if (!value) return null;

  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    const [y, m, d] = value.split("-").map(Number);
    return new Date(y, m - 1, d);
  }

  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
};

const toDateOnlyString = (value: Date | Date[] | null | undefined): string | null => {
  if (!value || Array.isArray(value)) return null;
  const y = value.getFullYear();
  const m = String(value.getMonth() + 1).padStart(2, "0");
  const d = String(value.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
};

const getTodayDateString = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const resolveLabel = (options: CatalogoOption[], value?: string | null): string => {
  if (!value || !value.trim()) return "-";
  const match = options.find((o) => o.code === value);
  if (match && match.description) return match.description;
  return value;
};

export default function CalculoGeneracionDocumentoPage() {
  const toast = useRef<Toast>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { id_expediente: idParam } = useParams();
  const { fromTracking = false } = location.state || {};

  const id_expediente = Number(idParam ?? 0);

  const [form, setForm] = useState<CalculoGeneracionDocumento>(
    buildInitialState(id_expediente),
  );
  const [isDisabled, setIsDisabled] = useState(true);
  const [canAdvance, setCanAdvance] = useState(false);
  const [isBusy, setIsBusy] = useState(false);
  const [isCalculatingUF, setIsCalculatingUF] = useState(false);
  const [editarRolModalVisible, setEditarRolModalVisible] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const hasHydratedRef = useRef(false);
  const currentExpedienteRef = useRef<number>(id_expediente);

  const { data, isLoading } = useCalculoGeneracionDocumento(id_expediente);
  const saveMutation = useUpsertCalculoGeneracionDocumento();
  const avanzarMutation = useAvanzarCalculoGeneracionDocumento();
  const { data: ufHoyResponse } = useCalcularUF(getTodayDateString());
  const { data: controlesData } = useControlesPropiedad();
  const controles: ControlesPropiedad = controlesData?.detail ?? EMPTY_CONTROLES_PROPIEDAD;

  const showToast = (
    severity: "success" | "info" | "warn" | "error",
    summary: string,
    detail: string,
    life = 3000,
  ) => {
    toast.current?.show({ severity, summary, detail, life });
  };

  useEffect(() => {
    if (currentExpedienteRef.current !== id_expediente) {
      currentExpedienteRef.current = id_expediente;
      hasHydratedRef.current = false;
      setForm(buildInitialState(id_expediente));
      setErrorMessage("");
      setIsDisabled(true);
      setCanAdvance(false);
    }
  }, [id_expediente]);

  useEffect(() => {
    if (hasHydratedRef.current) return;

    if (data?.status && data.detail) {
      setForm(normalizeForm(data.detail, id_expediente));
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
      return;
    }

    if (!id_expediente || id_expediente <= 0) {
      setForm(buildInitialState(0));
      setIsDisabled(false);
      hasHydratedRef.current = true;
      return;
    }

    if (data) {
      setForm((prev) =>
        normalizeForm({ ...prev, id_expediente }, id_expediente),
      );
      setIsDisabled(true);
      setCanAdvance(false);
      hasHydratedRef.current = true;
    }
  }, [data, id_expediente]);

  useEffect(() => {
    if (ufHoyResponse?.status && ufHoyResponse.detail != null) {
      setForm((prev) =>
        prev.valor_uf_fecha_hoy == null
          ? { ...prev, valor_uf_fecha_hoy: ufHoyResponse.detail }
          : prev,
      );
    }
  }, [ufHoyResponse]);

  const updateField = <K extends keyof CalculoGeneracionDocumento>(
    field: K,
    value: CalculoGeneracionDocumento[K],
  ) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleCalcularUF = async () => {
    if (!form.fecha_calculo) {
      showToast("warn", "Validación", "Seleccione una Fecha de Cálculo.");
      return;
    }

    try {
      setIsCalculatingUF(true);
      const response = await calculoGeneracionDocumentoService.calcularUF(
        form.fecha_calculo,
      );

      if (response.status) {
        updateField("valor_uf_fecha_calculo", response.detail);
        showToast(
          "success",
          "UF Calculada",
          `Valor UF: ${response.detail.toLocaleString("es-CL")}`,
        );
      } else {
        showToast("warn", "Atención", response.message || "No se pudo calcular la UF.");
      }
    } catch {
      showToast("error", "Error", "Error al calcular la UF.");
    } finally {
      setIsCalculatingUF(false);
    }
  };

  const handleEditar = () => {
    setIsDisabled(false);
    setCanAdvance(false);
  };

  const handleEnviarReparoChange = (checked: boolean) => {
    setForm((prev) => ({
      ...prev,
      is_enviar_reparo: checked,
      observaciones: checked ? prev.observaciones : "",
    }));
  };

  const validateForm = (): string => {
    if (!id_expediente || id_expediente <= 0)
      return "No existe un id_expediente válido.";
    if (!form.revision_rol_propiedad)
      return "Debe seleccionar la Revisión del Rol de Propiedad.";
    if (!form.fecha_calculo?.trim()) {
      return "Debe ingresar Fecha Calculo.";
    }
    if (!form.observaciones?.trim()) {
      return "Debe ingresar las observaciones.";
    }
    return "";
  };

  const handleGuardar = async () => {
    const msg = validateForm();
    if (msg) {
      showToast("warn", "Validación", msg);
      return;
    }

    try {
      setIsBusy(true);
      const payload = normalizeForm(
        { ...form, id_expediente },
        id_expediente,
      );
      const response = await saveMutation.mutateAsync(payload);

      if (response.status) {
        showToast("success", "Éxito", "Cálculo y Generación Documento guardado correctamente.");
        setForm(normalizeForm(response.detail ?? payload, id_expediente));
        setIsDisabled(true);
        setCanAdvance(true);
        hasHydratedRef.current = true;
      } else {
        showToast("warn", "Atención", response.message || "No se pudo guardar.");
      }
    } catch {
      showToast("error", "Error", "Ocurrió un error al guardar.");
    } finally {
      setIsBusy(false);
    }
  };

  const handleAvanzar = async () => {
    const msg = validateForm();
    if (msg) {
      showToast("warn", "Validación", msg);
      return;
    }

    try {
      setIsBusy(true);
      const response = await avanzarMutation.mutateAsync(id_expediente);

      if (response.status) {
        showToast("success", "Éxito", "Actividad avanzada correctamente.", 2000);
        navigate("/home/bandeja");
      } else {
        const detail = response.message || "No se pudo avanzar.";
        showToast("warn", "Atención", detail);
      }
    } catch {
      const detail = "Ocurrió un error al avanzar.";
      showToast("error", "Error", detail);
    } finally {
      setIsBusy(false);
    }
  };

  const handleSalir = () => navigate("/home/bandeja");

  const handleEditarRolConfirm = (updatedForm: CalculoGeneracionDocumento) => {
    setForm(updatedForm);
  };

  const rolPropiedadRows = [
    {
      tipo_propiedad: resolveLabel(controles.tipo_propiedad, form.tipo_propiedad),
      tipo_direccion: resolveLabel(controles.tipo_direccion, form.tipo_direccion),
      direccion: form.direccion || "—",
      region: resolveLabel(controles.region, form.region),
      comuna: resolveLabel(controles.comuna, form.comuna),
      rol_avaluo:
        [form.rol_avaluo_1, form.rol_avaluo_2]
          .filter(Boolean)
          .join(" ") || "—",
    },
  ];

  return (
    <>
      <Toast ref={toast} />

      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Cálculo y Generación Documento
      </h2>

      <Accordion activeIndex={[0, 2]} multiple>
        <AccordionTab
          header="Información del Expediente"
          disabled={!id_expediente || id_expediente <= 0}
        >
          <EncabezadoActividad
            idExpediente={id_expediente}
            activityID={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab
          header="Funciones Transversales"
          disabled={!id_expediente || id_expediente <= 0}
        >
          <FuncionesTransversales
            idExpediente={id_expediente}
            idActividad={ACTIVITY_ID}
          />
        </AccordionTab>

        <AccordionTab header="Cálculo y Generación Documento">
          <Card className="w-full shadow-md card-presto-form mb-6">
            {isLoading && id_expediente > 0 && (
              <div className="mb-4 text-sm text-blue-600">
                Cargando información...
              </div>
            )}

            <div className="mb-5">
              <div className="bg-azul-presto text-white font-semibold px-3 py-2 text-sm mb-2">
                ROL DE PROPIEDAD
              </div>
              <DataTable
                key={isDisabled ? "readonly" : "editable"}
                value={rolPropiedadRows}
                size="small"
                showGridlines
                className="text-sm datatable-presto"
              >
                <Column header="Tipo de Propiedad" body={(r) => renderResponsiveCell(r.tipo_propiedad, "Tipo de Propiedad: ")} />
                <Column header="Tipo de Dirección" body={(r) => renderResponsiveCell(r.tipo_direccion, "Tipo de Dirección: ")} />
                <Column header="Dirección" body={(r) => renderResponsiveCell(r.direccion, "Dirección: ")} />
                <Column header="Región" body={(r) => renderResponsiveCell(r.region, "Región: ")} />
                <Column header="Comuna" body={(r) => renderResponsiveCell(r.comuna, "Comuna: ")} />
                <Column header="Rol Avalúo" body={(r) => renderResponsiveCell(r.rol_avaluo, "Rol Avalúo: ")} />
                <Column
                  header="Editar"
                  body={() => renderResponsiveCell(
                    <Button
                      label="Editar Rol"
                      size="small"
                      severity="info"
                      outlined
                      disabled={!id_expediente || id_expediente <= 0 || isBusy || isDisabled}
                      onClick={() => setEditarRolModalVisible(true)}
                    />,
                    "Editar: "
                  )}
                  style={{ width: "130px" }}
                />
              </DataTable>
            </div>

            <div className="flex items-center gap-6 mb-5 flex-wrap">
              <span className="font-semibold text-sm">
                Revisión Rol Propiedad:
              </span>
              <div className="flex items-center gap-2">
                <RadioButton
                  inputId="rev_incorrecto"
                  value="ROL_INCORRECTO"
                  checked={form.revision_rol_propiedad === "ROL_INCORRECTO"}
                  onChange={() =>
                    updateField("revision_rol_propiedad", "ROL_INCORRECTO")
                  }
                  disabled={isDisabled}
                />
                <label htmlFor="rev_incorrecto" className="text-sm">
                  Rol Incorrecto
                </label>
              </div>
              <div className="flex items-center gap-2">
                <RadioButton
                  inputId="rev_aceptar"
                  value="ACEPTAR"
                  checked={form.revision_rol_propiedad === "ACEPTAR"}
                  onChange={() =>
                    updateField("revision_rol_propiedad", "ACEPTAR")
                  }
                  disabled={isDisabled}
                />
                <label htmlFor="rev_aceptar" className="text-sm">
                  Aceptar
                </label>
              </div>
            </div>

            <div className="mb-5">
              <div className="bg-azul-presto text-white font-semibold px-3 py-2 text-sm mb-3">
                ANTECEDENTES VARIOS
              </div>
              <div className="grid grid-cols-1 md:grid-cols-[1.2fr_1.4fr_0.95fr_1.2fr] gap-4 items-end md:items-center">
                <div className="flex flex-col gap-1">
                  <span className="font-semibold text-sm">
                    Valor UF Fecha de hoy
                  </span>
                  <span className="text-sm font-medium text-gray-700 h-8 flex items-center">
                    {form.valor_uf_fecha_hoy !== null
                      ? form.valor_uf_fecha_hoy.toLocaleString("es-CL")
                      : "—"}
                  </span>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-semibold text-sm">
                    Fecha de Cálculo
                  </label>
                  <Calendar
                    value={toDate(form.fecha_calculo)}
                    onChange={(e) =>
                      updateField("fecha_calculo", toDateOnlyString(e.value))
                    }
                    dateFormat="dd/mm/yy"
                    showIcon
                    className="calendar-presto"
                    disabled={isDisabled}
                    placeholder="dd/mm/aaaa"
                  />
                </div>

                <div className="flex flex-col gap-1 justify-end md:justify-center">
                  <span className="font-semibold text-sm opacity-0 select-none">
                    Acción
                  </span>
                  <Button
                    label={isCalculatingUF ? "Calculando..." : "Calcular UF"}
                    icon="pi pi-calculator"
                    severity="info"
                    size="small"
                    onClick={handleCalcularUF}
                    disabled={isDisabled || isCalculatingUF || !form.fecha_calculo}
                    className="btn-responsive px-3 whitespace-nowrap calcular-uf-button w-full md:w-auto bg-azul-presto"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <span className="font-semibold text-sm">
                    Valor UF Fecha de Cálculo
                  </span>
                  <span className="text-sm font-medium text-gray-700 h-8 flex items-center">
                    {form.valor_uf_fecha_calculo !== null
                      ? form.valor_uf_fecha_calculo.toLocaleString("es-CL")
                      : "—"}
                  </span>
                </div>
              </div>
            </div>

            <div className="mb-5">
              <div className="bg-azul-presto text-white font-semibold px-3 py-2 text-sm mb-3">
                    Estatus de la Actividad
              </div>

              <div className="flex items-center gap-2 mb-4 h-10">
                <Checkbox
                  inputId="is_enviar_reparo"
                  checked={form.is_enviar_reparo}
                  className="calculo-checkbox-visible"
                  onChange={(e) => handleEnviarReparoChange(Boolean(e.checked))}
                  disabled={isDisabled}
                />
                <label htmlFor="is_enviar_reparo" className="text-sm font-semibold">
                  ¿Enviar a Reparo?
                </label>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-semibold text-sm">
                  Observaciones{form.is_enviar_reparo ? " *" : ""}
                </label>
                <InputTextarea
                  value={form.observaciones ?? ""}
                  onChange={(e) => updateField("observaciones", e.target.value)}
                  rows={4}
                  maxLength={1000}
                  className="form-textarea-presto w-full"
                  disabled={isDisabled}
                  placeholder={
                    form.is_enviar_reparo
                      ? "Ingrese el motivo del reparo (máximo 1000 caracteres)"
                      : "Ingrese observaciones (opcional)"
                  }
                  style={{ resize: "none" }}
                />
                <div className="flex justify-end mt-1 text-xs">
                  <span className={
                    (form.observaciones?.length ?? 0) >= 1000 
                      ? "text-red-600" 
                      : (form.observaciones?.length ?? 0) >= 900 
                        ? "text-orange-500" 
                        : "text-gray-500"
                  }>
                    {form.observaciones?.length ?? 0}
                  </span>
                  <span className="mx-1 text-gray-500">/</span>
                  <span className="text-gray-500">1000</span>
                </div>
              </div>
            </div>

            <ActivityActionBar
              from_tracking={fromTracking}
              is_busy={isBusy}
              is_disabled={isDisabled}
              can_advance={canAdvance}
              is_saving={saveMutation.isPending}
              is_advancing={avanzarMutation.isPending}
              on_edit={handleEditar}
              on_save={handleGuardar}
              on_advance={handleAvanzar}
              on_exit={handleSalir}
            />
          </Card>
        </AccordionTab>
      </Accordion>

      <EditarRolModal
        visible={editarRolModalVisible}
        idExpediente={id_expediente}
        form={form}
        controles={controles}
        onHide={() => setEditarRolModalVisible(false)}
        onConfirm={handleEditarRolConfirm}
      />
    </>
  );
}