# Variables de entorno Frontend

Este proyecto usa Vite, por lo tanto las variables `VITE_*` se resuelven en tiempo de build.

## Modos

- Desarrollo local:
  - Archivo: `.env.development`
  - Comando: `npm run dev`
  - Valor actual: `VITE_API_BASE_URL=https://localhost:44302`

- Docker:
  - Archivo: `.env.docker`
  - Comando: `npm run build:docker`
  - Valor actual: `VITE_API_BASE_URL=` vacío.
  - Motivo: con valor vacío, las llamadas quedan como `/api/...` y NGINX enruta al backend.

- Producción:
  - Archivo: `.env.production`
  - Comando: `npm run build`
  - Valor actual: vacío, pensado para producción con reverse proxy same-origin.
  - Si la API vive en otro dominio, colocar por ejemplo `VITE_API_BASE_URL=https://api.tu-dominio.com`.

## Regla importante

No poner `/api` dentro de `VITE_API_BASE_URL` mientras los servicios ya armen rutas como `/api/Role`.

Correcto para Docker/NGINX:
`VITE_API_BASE_URL=`

Correcto para backend local directo:
`VITE_API_BASE_URL=https://localhost:44302`

Evitar:
`VITE_API_BASE_URL=http://multibanca.local/api`
porque puede generar rutas duplicadas tipo `/api/api/...`.
